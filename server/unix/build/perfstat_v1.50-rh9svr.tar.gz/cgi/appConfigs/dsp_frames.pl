use strict;
package main;
print("<html>\n");

print("	<head>\n");
print("		<meta http-equiv=\"content-type\" content=\"text/html;charset=iso-8859-1\">\n");
print("		<title>PerfStat Tool: Status And Performance Monitor</title>\n");
print("	</head>\n");
print("	\n");
print("	<frameset cols=\"180,*\" frameBorder=\"yes\" frameBorder=\"1\" frameSpacing=\"-1\" border=\"1\">\n");
print("		<frame src=\"navigation/index.pl\" name=\"navigation\">\n");
print("		<frame src=\"home/index.pl\" name=\"content\">\n");
print("	</frameset>\n");
print("	\n");
print("	<noframes>\n");
print("		<body bgcolor=\"#ffffff\">\n");
print("			<p>Sorry: This application requires a frames-enabled browser</p>\n");
print("		</body>\n");
print("	</noframes>\n");

print("</html>\n");
