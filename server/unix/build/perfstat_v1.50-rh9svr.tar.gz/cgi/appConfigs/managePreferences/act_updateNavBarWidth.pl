use strict;
package main;

# INPUT CHECK
$sessionObj->param("userMessage", "");

if ($request->param('navBarWidth') !~ /^\d+$/) {
	# is not a positive integer
	$sessionObj->param("userMessage", "Nav Bar Width must be an integer between 0 and 1000");
}

if ($sessionObj->param("userMessage") eq "") {
	if ($request->param('navBarWidth') < 0 || $request->param('navBarWidth') > 1000) {
		$sessionObj->param("userMessage", "Nav Bar Width must be an integer between 0 and 1000");
	}
}

if ($sessionObj->param("userMessage") eq "") {
	my $dirName = "$perfhome/var/db/users/" . $sessionObj->param('userName') . "/";
	my $fileName = "$dirName/" . $sessionObj->param('userName') . ".ser";
	
	#update user DB
	my $userObj = lock_retrieve($fileName) || die("ERROR: Unable to retrieve from $fileName\n");
	$userObj->setNavBarWidth($request->param('navBarWidth'));
	lock_store($userObj, $fileName) || die("ERROR: Unable to store to $fileName\n");

	#update session object parameter
	$sessionObj->param("navBarWidth", $request->param('navBarWidth'));
	
	# set user message
	$sessionObj->param("userMessage", "Nav Bar Width updated");
}

1;