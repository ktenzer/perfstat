use strict;
package main;

# INPUT CHECK
$sessionObj->param("userMessage", "");

if ($request->param('navBarTextLength') !~ /^\d+$/) {
	# is not a positive integer
	$sessionObj->param("userMessage", "Nav Bar Text Length must be an integer between 0 and 1000");
}

if ($sessionObj->param("userMessage") eq "") {
	if ($request->param('navBarTextLength') < 0 || $request->param('navBarTextLength') > 1000) {
		$sessionObj->param("userMessage", "Nav Bar Text Length must be an integer between 0 and 1000");
	}
}

if ($sessionObj->param("userMessage") eq "") {
	my $dirName = "$perfhome/var/db/users/" . $sessionObj->param('userName') . "/";
	my $fileName = "$dirName/" . $sessionObj->param('userName') . ".ser";
	
	#update user DB
	my $userObj = lock_retrieve($fileName) || die("ERROR: Unable to retrieve from $fileName\n");
	$userObj->setNavBarTextLength($request->param('navBarTextLength'));
	lock_store($userObj, $fileName) || die("ERROR: Unable to store to $fileName\n");

	#update session object parameter
	$sessionObj->param("navBarTextLength", $request->param('navBarTextLength'));
	
	# set user message
	$sessionObj->param("userMessage", "Nav Bar Text Length updated");
}

1;