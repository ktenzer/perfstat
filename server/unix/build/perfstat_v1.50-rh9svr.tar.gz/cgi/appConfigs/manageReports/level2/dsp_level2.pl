use strict;
package main;
print("<html>\n");
print("	<head>\n");
print("		<meta http-equiv=\"content-type\" content=\"text/html;charset=iso-8859-1\">\n");
print("		<title>PerfStat Tool: Perfomance Monitoring & Status Notification</title>\n");
print("		<link rel=\"stylesheet\" type=\"text/css\" href=\"../../../perfStatResources/styleSheets/contentFrame.css\" media=\"screen\">\n");
print("		<link rel=\"stylesheet\" type=\"text/css\" href=\"../../../perfStatResources/styleSheets/forms.css\" media=\"screen\">\n");
print("		<script language=\"javascript\" src=\"../../../perfStatResources/javaScripts/contentFrame.js\"></script>\n");
print("	</head>\n");

print("	<body>\n");
print("		<div class=\"navHeader\">\n");
my $formula1=$adminName;my $formula2=$userName;my $formula3=$itemName;print("			<a href=\"../level1/index.pl?adminName=$formula1&userName=$formula2\">Manage Report Groups</a>: $formula3\n");
print("		</div>\n");
 #if ($reportHashLen != 0) {
print("		<table cellpadding=\"2\" cellspacing=\"1\" border=\"0\" class=\"table1\">\n");
print("			<tr>\n");
print("				<td class=\"tdTop\" nowrap=\"nowrap\" colspan=\"2\" valign=\"middle\" align=\"left\">Add Report</td>\n");
print("			</tr>\n");
print("			<tr>\n");
print("				<th nowrap=\"nowrap\" valign=\"middle\" align=\"left\">Report Name</th>\n");
print("				<th nowrap=\"nowrap\">Actions</th>\n");
print("			</tr>\n");
print("			<tr>\n");
print("				<form action=\"index.pl\" method=\"get\">\n");
print("				<input type=\"hidden\" name=\"action\" value=\"insertItem\">\n");
my $formula1=$adminName;print("				<input type=\"hidden\" name=\"adminName\" value=\"$formula1\">\n");
my $formula1=$userName;print("				<input type=\"hidden\" name=\"userName\" value=\"$formula1\">\n");
my $formula1=$itemID;print("				<input type=\"hidden\" name=\"itemID\" value=\"$formula1\">\n");
print("				<td class=\"liteGray\" align=\"left\" valign=\"middle\"><input type=\"text\" name=\"selectName\" size=\"24\"></td>\n");
print("				</td>\n");
print("				<td class=\"darkGray\" align=\"center\" valign=\"middle\"><input class=\"liteButton\" type=\"submit\" value=\"ENTER\"></td>\n");
print("				</form>\n");
print("			</tr>\n");
print("		</table>\n");
 #}
 if ($reportGroupMemberHashLen != 0) {
print("		<table width=\"100%\" cellpadding=\"2\" cellspacing=\"1\" border=\"0\" class=\"table1\">\n");
print("			<tr>\n");
print("				<td class=\"tdTop\" nowrap=\"nowrap\" colspan=\"3\" valign=\"middle\" align=\"left\">Report List</td>\n");
print("			</tr>\n");
print("			<tr>\n");
print("				<th nowrap=\"nowrap\" width=\"10\">Actions</th>\n");
print("				<th nowrap=\"nowrap\" valign=\"middle\" align=\"left\" colspan=\"2\">Report Name</th>\n");
print("			</tr>\n");
foreach my $reportGroupMemberKey (sort(keys(%$reportGroupMemberHash))) {
my $tempName = $reportGroupMemberKey;
my $tempID = $reportGroupMemberHash->{$reportGroupMemberKey}->[0];
print("			<tr>\n");
print("				<td class=\"liteGray\" align=\"center\" valign=\"middle\" width=\"10\">\n");
print("					<table width=\"100%\" cellpadding=\"1\" cellspacing=\"1\" border=\"0\" class=\"table2\">\n");
print("						<tr>\n");
my $formula1=$adminName;my $formula2=$userName;my $formula3=$itemID;my $formula4=$tempID;my $formula5=$tempName;print("							<th nowrap=\"nowrap\"><a href=\"index.pl?action=deleteItem&adminName=$formula1&userName=$formula2&itemID=$formula3&item2ID=$formula4\" onclick=\"return warnOnClickAnchor('Are you sure you want to delete $formula5');\">Delete</a></th>\n");
print("						</tr>\n");
print("					</table>\n");
print("				</td>\n");
my $formula1=$tempName;print("				<td class=\"liteGray\" align=\"left\" valign=\"top\" colspan=\"2\"><span class=\"table1Text1\">$formula1</span></td>\n");
print("			</tr>\n");
}
print("		</table>\n");
 } else {
print("		<table width=\"100%\" cellpadding=\"2\" cellspacing=\"1\" border=\"0\" class=\"table1\">\n");
print("			<tr>\n");
print("				<td class=\"tdTop\" nowrap=\"nowrap\" colspan=\"3\" valign=\"middle\" align=\"left\">Report List</td>\n");
print("			</tr>\n");
print("			<tr>\n");
print("				<th nowrap=\"nowrap\" valign=\"middle\" align=\"left\" colspan=\"3\">Report Name</th>\n");
print("			</tr>\n");
print("			<tr>\n");
print("				<td class=\"liteGray\" align=\"left\" valign=\"top\" colspan=\"3\"><span class=\"table1Text1\">&nbsp;</span></td>\n");
print("			</tr>\n");
print("		</table>\n");
 }
print("	</body>\n");
print("</html>\n");
