use strict;
package main;
require("lib_inputCheck.pl");
if ($sessionObj->param("userName") eq "perfstat") {
# Login is perfstat admin
	$adminName = $request->param('adminName');
	checkAdminName($adminName);
	$userName = $request->param('userName');
	checkUserName($adminName);
	$itemID = $request->param('itemID');
	$itemName = $request->param('itemName');

	#find array of reports already in reportGroup member array
	my $reportGroupMemberArray = $userIndex->{$adminName}->{$userName}->{reportGroups}->[$itemID]->{memberArray};
	my $reportGroupMemberArrayLen = @$reportGroupMemberArray;

	$reportGroupMemberHash = {};
	# create hash of reportGroupMembers
	for (my $count = 0; $count < $reportGroupMemberArrayLen; $count++) {
		my $reportName = $reportGroupMemberArray->[$count];
		my $tempArray = [];
		$tempArray->[0] = $count;
		$reportGroupMemberHash->{$reportName} = $tempArray;
	}
	
	$reportGroupMemberHashLen = %$reportGroupMemberHash;


} elsif ($sessionObj->param("role") eq "admin") {
# Login is group admin
	$adminName = $sessionObj->param("userName");
	checkAdminName($adminName);
	$userName = $request->param('userName');
	checkUserName($adminName);
	$itemID = $request->param('itemID');
	$itemName = $request->param('itemName');

	#find array of reports already in reportGroup member array
	my $reportGroupMemberArray = $userIndex->{$adminName}->{$userName}->{reportGroups}->[$itemID]->{memberArray};
	my $reportGroupMemberArrayLen = @$reportGroupMemberArray;

	$reportGroupMemberHash = {};
	# create hash of reportGroupMembers
	for (my $count = 0; $count < $reportGroupMemberArrayLen; $count++) {
		my $reportName = $reportGroupMemberArray->[$count];
		my $tempArray = [];
		$tempArray->[0] = $count;
		$reportGroupMemberHash->{$reportName} = $tempArray;
	}
	
	$reportGroupMemberHashLen = %$reportGroupMemberHash;

} else {
# Login is user
	# Login is user
	$adminName = $sessionObj->param("creator");
	checkAdminName($adminName);
	$userName = $sessionObj->param("userName");
	checkUserName($adminName);
	$itemID = $request->param('itemID');
	$itemName = $request->param('itemName');

	#find array of reports already in reportGroup member array
	my $reportGroupMemberArray = $userIndex->{$adminName}->{$userName}->{reportGroups}->[$itemID]->{memberArray};
	my $reportGroupMemberArrayLen = @$reportGroupMemberArray;

	$reportGroupMemberHash = {};
	# create hash of reportGroupMembers
	for (my $count = 0; $count < $reportGroupMemberArrayLen; $count++) {
		my $reportName = $reportGroupMemberArray->[$count];
		my $tempArray = [];
		$tempArray->[0] = $count;
		$reportGroupMemberHash->{$reportName} = $tempArray;
	}
	
	$reportGroupMemberHashLen = %$reportGroupMemberHash;

}

1;