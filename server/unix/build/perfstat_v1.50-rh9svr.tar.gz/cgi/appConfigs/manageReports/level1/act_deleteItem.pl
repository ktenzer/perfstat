use strict;
package main;
require("lib_inputCheck.pl");

# init message variables
$sessionObj->param("userMessage", "");
my $errorMessage = "";

if ($sessionObj->param("userName") eq "perfstat") {
	# Login is perfstat admin
	$adminName = $request->param('adminName');
	checkAdminName($adminName);
	$userName = $request->param('userName');
	checkUserName($userName);
	$itemID = $request->param('itemID');
	deleteItem($userName, $itemID);
	$queryString = "action=clearItem" .
						"&adminName=" . URLEncode($adminName) .
						"&userName=". URLEncode($userName);

} elsif ($sessionObj->param("role") eq "admin") {
	# Login is group admin
	$adminName = $sessionObj->param("userName");
	checkAdminName($adminName);
	$userName = $request->param('userName');
	checkUserName($userName);
	$itemID = $request->param('itemID');
	deleteItem($userName, $itemID);
	$queryString = "action=clearItem" .
						"&adminName=" . URLEncode($adminName) .
						"&userName=". URLEncode($userName);
	
} else {
	# Login is user
	$adminName = $sessionObj->param("creator");
	checkAdminName($adminName);
	$userName = $request->param('userName');
	checkUserName($userName);
	$itemID = $request->param('itemID');
	deleteItem($userName, $itemID);
	$queryString = "action=clearItem" .
						"&adminName=" . URLEncode($adminName) .
						"&userName=". URLEncode($userName);
}

################################################### SUBROUTINES
#DELETE REPORTGROUP
sub deleteItem {
	my ($itemName, $itemID) = @_;
	my $directoryName = "$perfhome/var/db/users/$userName";
	my $fileName = "$directoryName/$userName.ser";
	my $userObj = lock_retrieve($fileName) || die("ERROR: Can't retrieve userObj from $fileName\n");
	die("ERROR: can't define userObj from $fileName\n") unless defined($userObj);
	$userObj->deleteReportGroup($itemID);
	lock_store($userObj, "$fileName") || die("ERROR: can't store userObj in $fileName\n");
}

1;