use strict;
package main;
require("lib_inputCheck.pl");

# init message variables
$sessionObj->param("userMessage", "");
my $errorMessage = "";

if ($sessionObj->param("userName") eq "perfstat") {
	# Login is perfstat admin
	$adminName = $request->param('adminName');
	checkAdminName($adminName);
	$userName = $request->param('userName');
	checkUserName($userName);
	$itemName = trim($request->param('itemName'));
	$errorMessage = checkItemName($itemName);
	$description = trim($request->param('description'));
	if (length($errorMessage) ne 0) {
		$sessionObj->param("userMessage", $errorMessage);
		$queryString = "adminName=". URLEncode($adminName) .
						"&userName=". URLEncode($userName) .
						"&itemName=" . URLEncode($itemName) .
						"&description=" . URLEncode($description);
	} else {
		insertItem($userName, $itemName, $description);
		$queryString = "action=clearItem" .
							"&adminName=" . URLEncode($adminName) .
							"&userName=". URLEncode($userName);
	}

} elsif ($sessionObj->param("role") eq "admin") {
	# Login is group admin
	$adminName = $sessionObj->param("userName");
	checkAdminName($adminName);
	$userName = $request->param('userName');
	checkUserName($userName);
	$itemName = trim($request->param('itemName'));
	$errorMessage = checkItemName($itemName);
	$description = trim($request->param('description'));
	if (length($errorMessage) ne 0) {
		$sessionObj->param("userMessage", $errorMessage);
		$queryString = "adminName=". URLEncode($adminName) .
						"&userName=". URLEncode($userName) .
						"&itemName=" . URLEncode($itemName) .
						"&description=" . URLEncode($description);
	} else {
		insertItem($userName, $itemName, $description);
		$queryString = "action=clearItem" .
							"&adminName=" . URLEncode($adminName) .
							"&userName=". URLEncode($userName);
	}
	
} else {
	# Login is user
	$adminName = $sessionObj->param("creator");
	checkAdminName($adminName);
	$userName = $sessionObj->param("userName");
	checkUserName($userName);
	$itemName = trim($request->param('itemName'));
	$errorMessage = checkItemName($itemName);
	$description = trim($request->param('description'));
	if (length($errorMessage) ne 0) {
		$sessionObj->param("userMessage", $errorMessage);
		$queryString = "adminName=". URLEncode($adminName) .
						"&userName=". URLEncode($userName) .
						"&itemName=" . URLEncode($itemName) .
						"&description=" . URLEncode($description);
	} else {
		insertItem($userName, $itemName, $description);
		$queryString = "action=clearItem" .
							"&adminName=" . URLEncode($adminName) .
							"&userName=". URLEncode($userName);
	}
}

################################################### SUBROUTINES
#INSERT Item
sub insertItem {
	my ($userName, $itemName, $description) = @_;
	my $directoryName = "$perfhome/var/db/users/$userName";
	my $fileName = "$directoryName/$userName.ser";
	my $userObj = lock_retrieve($fileName) || die("ERROR: Can't retrieve userObj from $fileName\n");
	die("ERROR: can't define userObj from $fileName\n") unless defined($userObj);
	# Create report group object
	my $reportGroupObject = HostGroup->new(	name			=> $itemName,
													description 	=> $description);

	$userObj->addReportGroup($reportGroupObject);
	lock_store($userObj, "$fileName") || die("ERROR: can't store userObj in $fileName\n");
}

1;