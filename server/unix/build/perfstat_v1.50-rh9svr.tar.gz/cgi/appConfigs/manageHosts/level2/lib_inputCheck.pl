#  input check functions
sub checkAdminName {
	my ($adminName) = @_;
	if (length($adminName) == 0) {die('Error: missing required value for $adminName');}
	if(!(-d "$perfhome/var/db/users/$adminName")) {die('Error: invalid value for $adminName: no user directory');}
	if(!(-e "$perfhome/var/db/users/$adminName/$adminName.ser")) {die('Error: invalid value for $adminName: no user file');}
	if (!(exists( $userIndex->{$adminName}->{$adminName}))) {die('Error: invalid value for $adminName');}
}

sub securityCheckItemName {
	my ($adminName, $itemName) = @_;
	if (length($itemName) == 0) {die('Error: missing required value for $itemName');}
	if(!(-d "$perfhome/var/db/hosts/$itemName")) {die('Error: invalid value for $itemName: no host directory');}
	if(!(-e "$perfhome/var/db/hosts/$itemName/$itemName.ser")) {die('Error: invalid value for $itemName: no host file');}
	if (!(exists( $hostIndex->{$itemName}))) {die('Error: invalid value for $itemName');}
	if ($adminName ne "perfstat") {
		if ($hostIndex->{$itemName}->getOwner() ne $adminName)  {die('ERROR invalid permissions for $adminName');}
	}
}

sub checkThreshold {
	my ($value, $metricName, $type) =@_;
	#print ("test: $value $metricName $type<br>");
	if (length($value) == 0) {return("Missing required value for $metricName $type");}
	if ($value !~ m/\b\d+\b/) {return("Invalid value for $metricName $type: must be integer");}
}

sub checkUnit {
	my ($value, $metricName, $type) =@_;
	#print ("test: $value $metricName $type <br>");
	if (length($value) == 0) {return("Missing required value for $metricName $type");}
	if ($value =~ m/[0-9]/) {return("Invalid value for $metricName $type: must be non-numeric");}
}
1;