#!/usr/bin/perl -w
use strict;

BEGIN
{
	unshift(@INC, "../../..");
	require("app_globals.pl");
}

use vars qw($action $adminName $itemName $eventHash $serviceHash $serviceName $serviceMetricArray $serviceMetricArrayLen $queryString);

$request = new CGI;
$action = "";
$action = $request->param('action');

if ($action eq "setMetricThresholds")
{
	require("act_updateMetricThresholds.pl");
	metaRedirect(0, "index.pl?$queryString");
}
else #default action is display frame
{

	if ($doParse) {PerfStatCGI::Parser->html2Perl("dsp_level2.html");}
	require("act_initLevel2.pl");
	require("dsp_level2.pl");
}