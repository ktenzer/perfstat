use strict;
package main;
require("lib_inputCheck.pl");
if ($sessionObj->param("userName") eq "perfstat") {
# Login is perfstat admin
	$adminName = $request->param('adminName');
	checkAdminName($adminName);
	$itemName = $request->param('itemName');
	securityCheckItemName($adminName, $itemName);	

} elsif ($sessionObj->param("role") eq "admin") {
# Login is group admin
	$adminName = $sessionObj->param("userName");
	checkAdminName($adminName);
	$itemName = $request->param('itemName');
	securityCheckItemName($adminName, $itemName);

} else {
# Login is user
	# Login is user
	die('ERROR: invalid value for $sessionObj->param("role")')
}

my $hostName=$itemName;
my $serviceName = trim($request->param('serviceName'));
my $errorMessage="";
my $errorCondition="";

#Sort through params and update thresholds
my $tempHostObject = $hostIndex->{$hostName};
my $tempServiceIndex = $tempHostObject->{'serviceIndex'};

my $serviceObject = $tempServiceIndex->{$serviceName};
my $arrayLength = $serviceObject->getMetricArrayLength();

for (my $counter=0; $counter < $arrayLength; $counter++) {
	my $metricObject = $serviceObject->{metricArray}->[$counter];
	my $hasEvents = $metricObject->getHasEvents();          
	my $status = $metricObject->getStatus();

	if ($hasEvents =~ m/-1/) {
		next;
	} elsif ($hasEvents =~ m/0/) {
		my $event="hasEvents_$counter";

		my $tempWarnThreshold=$metricObject->getWarnThreshold();
		my $tempCritThreshold=$metricObject->getCritThreshold();
		my $tempThresholdUnit=$metricObject->getThresholdUnit();
		my $tempHasEvents=trim($request->param($event));

		#Set hasEvents to 0 if not defined or 1
		if (! defined $tempHasEvents) {
			$tempHasEvents="0";
		} else {
			$tempHasEvents="1";
		}

		updateMetricThresholds($tempWarnThreshold,$tempCritThreshold,$tempThresholdUnit,$tempHasEvents,$counter);
	} else {
		my $warn="warnThreshold_$counter";
		my $crit="critThreshold_$counter";
		my $unit="thresholdUnit_$counter";
		my $event="hasEvents_$counter";
		my $tempWarnThreshold=trim($request->param($warn));
		my $tempCritThreshold=trim($request->param($crit));
		my $tempThresholdUnit=trim($request->param($unit));
		my $tempHasEvents=trim($request->param($event));

		#Set hasEvents to 0 if not defined
		if (! defined $tempHasEvents) {
			$tempHasEvents="0";
		} else {
			$tempHasEvents="1";
		}

		#print("$tempWarnThreshold $tempCritThreshold $tempThresholdUnit $tempHasEvents<br>");
		updateMetricThresholds($tempWarnThreshold,$tempCritThreshold,$tempThresholdUnit,$tempHasEvents,$counter);
	}
}

if ($errorCondition == 0)  {
	# Serialize host data to disk (host.ser)
	$serviceObject->lock_store("$perfhome/var/db/hosts/$hostName/$serviceName.ser") or die "ERROR: Can't store $perfhome/var/db/hosts/$hostName/$serviceName.ser\n";

	# ADD SHARED MEMORY (If Appropriate)
	if ($perfdIsUp) {
		# Thaw/Freeze hostObject to Shared Memory
	}

	$sessionObj->param("userMessage", "Metrics Updated");
	$queryString = 	"action=selectMetricConfig" .
					"&adminName=$adminName" .
					"&itemName=$hostName" .
					"&serviceName=$serviceName";
}

################################################### SUBROUTINES
#Update Metric Thresholds
sub updateMetricThresholds {
	my ($tempWarnThreshold, $tempCritThreshold, $tempThresholdUnit,$tempHasEvents,$tempCount) = @_;

	#print ("crit: $tempCritThreshold warn: $tempWarnThreshold unit: $tempThresholdUnit event: $tempHasEvents count: $tempCount<br>");

	my $tempHostObject = $hostIndex->{$hostName};
	my $tempServiceIndex = $tempHostObject->{'serviceIndex'};
	$serviceObject = $tempServiceIndex->{$serviceName};
	my $metricObject = $serviceObject->{metricArray}->[$tempCount];
	my $friendlyName = $metricObject->getFriendlyName();
	my $lowThreshold = $metricObject->getLowThreshold();
	my $highThreshold = $metricObject->getHighThreshold();

	my $typeWarn="Warn";
	my $typeCrit="Crit";
	my $typeUnit="Unit";

	#Input Checking
	if ($tempWarnThreshold >= $tempCritThreshold) {
		$errorMessage="Invalid value for $friendlyName Warn: warn must be less than crit";
		$sessionObj->param("userMessage", $errorMessage);
		$queryString = 	"action=selectMetricConfig" .
				"&adminName=$adminName" .
				"&itemName=$hostName" .
				"&serviceName=$serviceName";

		$errorCondition = 1;
	}

	if ($tempWarnThreshold < $lowThreshold || $tempWarnThreshold > $highThreshold) {
		$errorMessage="Invalid value for $friendlyName Warn: value must be between $lowThreshold and $highThreshold";
		$sessionObj->param("userMessage", $errorMessage);
		$queryString = 	"action=selectMetricConfig" .
				"&adminName=$adminName" .
				"&itemName=$hostName" .
				"&serviceName=$serviceName";

		$errorCondition = 1;
	}

	if ($tempCritThreshold < $lowThreshold || $tempCritThreshold > $highThreshold) {
		$errorMessage="Invalid value for $friendlyName Crit: value must be between $lowThreshold and $highThreshold";
		$sessionObj->param("userMessage", $errorMessage);
		$queryString = 	"action=selectMetricConfig" .
				"&adminName=$adminName" .
				"&itemName=$hostName" .
				"&serviceName=$serviceName";

		$errorCondition = 1;
	}

	$errorMessage=checkThreshold($tempWarnThreshold,$friendlyName,$typeWarn);
	if (length($errorMessage) ne 0)  {
		$sessionObj->param("userMessage", $errorMessage);
		$queryString = 	"action=selectMetricConfig" .
				"&adminName=$adminName" .
				"&itemName=$hostName" .
				"&serviceName=$serviceName";

		$errorCondition = 1;
	}

	$errorMessage=checkThreshold($tempCritThreshold,$friendlyName,$typeCrit);
	if (length($errorMessage) ne 0) {
		$sessionObj->param("userMessage", $errorMessage);
		$queryString = 	"action=selectMetricConfig" .
				"&adminName=$adminName" .
				"&itemName=$hostName" .
				"&serviceName=$serviceName";

		$errorCondition = 1;
	}

	$errorMessage=checkUnit($tempThresholdUnit,$friendlyName,$typeUnit);
	if (length($errorMessage) ne 0)  {
		$sessionObj->param("userMessage", $errorMessage);
		$queryString = 	"action=selectMetricConfig" .
				"&adminName=$adminName" .
				"&itemName=$hostName" .
				"&serviceName=$serviceName";

		$errorCondition = 1;
	}

	#Update metrics
	$metricObject->setCritThreshold($tempCritThreshold);
	$metricObject->setWarnThreshold($tempWarnThreshold);
	$metricObject->setThresholdUnit($tempThresholdUnit);
	$metricObject->setHasEvents($tempHasEvents);
}

1;