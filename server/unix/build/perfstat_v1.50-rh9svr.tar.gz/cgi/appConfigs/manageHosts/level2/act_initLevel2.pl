use strict;
package main;
require("lib_inputCheck.pl");
if ($sessionObj->param("userName") eq "perfstat") {
# Login is perfstat admin
	$adminName = $request->param('adminName');
	checkAdminName($adminName);
	$itemName = $request->param('itemName');
	securityCheckItemName($adminName, $itemName);	

} elsif ($sessionObj->param("role") eq "admin") {
# Login is group admin
	$adminName = $sessionObj->param("userName");
	checkAdminName($adminName);
	$itemName = $request->param('itemName');
	securityCheckItemName($adminName, $itemName);

} else {
# Login is user
	# Login is user
	die('ERROR: invalid value for $sessionObj->param("role")')
}

#make service hash for menu bar
my $serviceHash1 = {};
$eventHash = {};
makeServiceHash1($serviceHash1, $itemName, $eventHash);
$serviceHash = {};
makeServiceHash2($serviceHash1, $serviceHash);

#set service name
$serviceName = $request->param('serviceName');
if (length($serviceName) != 0) {
	$serviceMetricArray = $hostIndex->{$itemName}->{'serviceIndex'}->{$serviceName}->{'metricArray'};
	$serviceMetricArrayLen = @$serviceMetricArray;
}

#foreach my $serviceHashKey (sort(keys(%$serviceHash))) {
#	my $tempServiceHash = $serviceHash->{$serviceHashKey};
#		if ($tempServiceHash->{'hasSubService'} != 1) {
#			print("$serviceHashKey: noSubService<br>");
#		} else {
#			print("$serviceHashKey: hasSubService<br>");
#			my $tempSubServiceHash = $tempServiceHash->{'subServiceHash'};
#			foreach my $tempSubServiceHashKey (sort(keys(%$tempSubServiceHash))) {
#				print("$tempSubServiceHashKey<br>");
#			}
#		}
#}
#foreach my $serviceName (keys(%$eventHash)) {
#		print ("service: $serviceName <br>");
#		print ("value: $eventHash->{$serviceName} <br>");
#}				
###############################################################FUNCTIONS
#----------------------------------------------------------------------------------------------------- makeServiceHash1
sub makeServiceHash1 {
	my ($tempServiceHash, $hostName, $eventHash) = @_;
	my $tempHostObject = $hostIndex->{$hostName};
	my $tempServiceIndex = $tempHostObject->{'serviceIndex'};
	foreach my $service (keys(%$tempServiceIndex)) {
		my $serviceObject = $tempServiceIndex->{$service};
		my $serviceName = $serviceObject->getServiceName();
		my $arrayLength = $serviceObject->getMetricArrayLength();

		for (my $counter=0; $counter < $arrayLength; $counter++) {
			my $metricObject = $serviceObject->{metricArray}->[$counter];
			my $hasEvents = $metricObject->getHasEvents();
			if ($hasEvents == 1) {
				$tempServiceHash->{$service} = "";
				$eventHash->{$service}=1 unless ($service =~ m/conn/);
			}
			if ($hasEvents == 0) {
				$tempServiceHash->{$service} = "";
				$eventHash->{$service}=0 unless ($service =~ m/conn/);
			}
		}
	}
}

#---------------------------------------------------------------------------------------------------- makeServiceHash2
sub makeServiceHash2 {
	my ($oldHash, $newHash) = @_;
	my $previousServicePrefix = "";

	foreach my $fullServiceName (sort(keys(%$oldHash))) {
		my $prefix = $fullServiceName;
		$prefix =~ s/\..*//;
		if ($prefix ne $previousServicePrefix) {
			# new service or subservice
			if ($fullServiceName !~ m/\S+\.\S+/) {
				# if not subservice
				my $tempHash = {};
				$tempHash->{'hasSubService'} = 0;
				$newHash->{$prefix} = $tempHash;
			} else {
				# if is first occurrence of subservice
				my $tempHash = {};
				my $suffix = $fullServiceName;
				$suffix =~ s/.*\.//;
				$tempHash->{'hasSubService'} = 1;
				$tempHash->{'subServiceHash'} = {};
				$tempHash->{'subServiceHash'}->{$suffix} = $oldHash->{$fullServiceName};
				$newHash->{$prefix} = $tempHash;
			}
			$previousServicePrefix = $prefix;
		} else {
			# next occurrence of previously entered subservice in newHash
			my $suffix = $fullServiceName;
			$suffix =~ s/^\w+\.//;
			$newHash->{$prefix}->{'subServiceHash'}->{$suffix} =  $oldHash->{$fullServiceName};
		}
	}
}



1;