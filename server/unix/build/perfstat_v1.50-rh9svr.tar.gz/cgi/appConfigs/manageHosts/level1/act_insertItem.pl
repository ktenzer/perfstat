use strict;
package main;
require("lib_inputCheck.pl");

# init message variables
$sessionObj->param("userMessage", "");
my $errorMessage = "";

if ($sessionObj->param("userName") eq "perfstat") {
	# Login is perfstat admin
	$adminName = $request->param('adminName');
	checkAdminName($adminName);
	$osName = $request->param('osName');
	checkOSName($osName);
	$itemName = trim($request->param('itemName'));
	$errorMessage = checkItemName($itemName);
	if (length($errorMessage) eq 0) {
		$ipAddress = trim($request->param('ipAddress'));
		$errorMessage = checkIPAddress($ipAddress);
	}
	if (length($errorMessage) ne 0) {
		$sessionObj->param("userMessage", $errorMessage);
		$queryString = "adminName=". URLEncode($adminName) .
						"&itemName=" . URLEncode($itemName) .
						"&ipAddress=" . URLEncode($ipAddress) .
						"&osName=$osName";
	} else {
		insertItem($adminName, $itemName, $ipAddress, $osName);
		$queryString = "action=clearItem&adminName=" . URLEncode($adminName);
	}

} elsif ($sessionObj->param("role") eq "admin") {
	# Login is group admin
	$adminName = $sessionObj->param("userName");
	checkAdminName($adminName);
	$osName = $request->param('osName');
	checkOSName($osName);
	$itemName = trim($request->param('itemName'));
	$errorMessage = checkItemName($itemName);
	if (length($errorMessage) eq 0) {
		$ipAddress = trim($request->param('ipAddress'));
		$errorMessage = checkIPAddress($ipAddress);
	}
	if (length($errorMessage) ne 0) {
		$sessionObj->param("userMessage", $errorMessage);
		$queryString = "adminName=". URLEncode($adminName) .
						"&itemName=" . URLEncode($itemName) .
						"&ipAddress=" . URLEncode($ipAddress) .
						"&osName=$osName";
	} else {
		insertItem($adminName, $itemName, $ipAddress, $osName);
		$queryString = "action=clearItem&adminName=" . URLEncode($adminName);
	}
	
} else {
	# Login is user
	die('ERROR: invalid value for $sessionObj->param("role")')
}

################################################### SUBROUTINES
#INSERT HOST
sub insertItem {
	my ($adminName, $hostName, $ipAddress, $osName) = @_;
	
	# ADD PERSISTENT MEMORY
	# Create host object
	my $hostObject = Host->new(	OS		=> $osName,
										IP 		=> $ipAddress,
										Owner	=> $adminName);

	# Create host directory
	if ( ! -d "$perfhome/var/db/hosts/$hostName" ) {
		mkdir("$perfhome/var/db/hosts/$hostName", 0770) or die "ERROR: Cannot mkdir $perfhome/var/db/hosts/$hostName: $!\n";
	}

	# Serialize host data to disk (host.ser)
	$hostObject->lock_store("$perfhome/var/db/hosts/$hostName/$hostName.ser") or die "ERROR: Can't store $perfhome/var/db/hosts/$hostName/$hostName.ser\n";

	# ADD SHARED MEMORY (If Appropriate)
	if ($perfdIsUp) {
		# Thaw/Freeze hostObject to Shared Memory
	}
}

1;