use strict;
package main;
# Slurp in Configuration
my %conf = ();
getConfiguration(\%conf);

# Set Environment Variables from %conf
foreach my $key (keys %conf) {
        $ENV{$key}="$conf{$key}";
}

### Bind to Shared Memory Object and deserialize ###
# Initialize shared memory object
my %shmChild=();
my $shmChild;

# tie to shared memory segment created by parent
tie($shmChild,'IPC::Shareable',$ENV{'SHM_ID'},{	create     => 0,
					       								destroy    => 0,
					       								exclusive  => 0,
					       								mode       => 0644}) 
			or die "WARNING: Couldn't tie host data hash to shared memory: $!\n";

# Thaw hostIndex from frozen parent object (De-serialize/read)
(tied $shmChild)->shlock(LOCK_SH|LOCK_NB);
my %$hostIndex= %{ thaw($shmChild) } or warn "WARNING: Couldn't thaw hostIndex for global data, no hosts defined\n";
(tied $shmChild)->shunlock;
### End of Shared memory bind/deserialize ###

$hostArray = [];
if ($sessionObj->param("creator") eq "perfstat") {
	# Login is root admin
	my $count = 0;
	foreach my $host (sort(keys(%$hostIndex))) {
		my $hostObject = $hostIndex->{$host};
		my $serviceIndex = $hostObject->{serviceIndex};
		
		my $tempArray = [];
		$tempArray->[0] = $host;
		$tempArray->[1] = $hostIndex->{$host}->getIP();
		$tempArray->[2] = $hostIndex->{$host}->getOwner();
		$hostArray->[$count] = $tempArray;
		$count++;
	}
	
} elsif ($sessionObj->param("role") eq "admin") {
	# Login is group admin
	
} else {
	# Login is user
}

1;