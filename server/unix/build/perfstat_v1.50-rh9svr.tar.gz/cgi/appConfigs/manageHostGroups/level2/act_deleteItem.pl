use strict;
package main;
require("lib_inputCheck.pl");

# init message variables
$sessionObj->param("userMessage", "");
my $errorMessage = "";

if ($sessionObj->param("userName") eq "perfstat") {
	# Login is perfstat admin
	$adminName = $request->param('adminName');
	checkAdminName($adminName);
	$userName = $request->param('userName');
	checkUserName($userName);
	$itemID = $request->param('itemID');
	$item2ID = $request->param('item2ID');
	deleteItem($userName, $itemID, $item2ID);
	$queryString = "action=clearItem" .
						"&adminName=" . URLEncode($adminName) .
						"&userName=". URLEncode($userName) .
						"&itemID=". URLEncode($itemID) .
						"&itemName=". URLEncode($itemName);

} elsif ($sessionObj->param("role") eq "admin") {
	# Login is group admin
	$adminName = $sessionObj->param("userName");
	checkAdminName($adminName);
	$userName = $request->param('userName');
	checkUserName($userName);
	$itemID = $request->param('itemID');
	$item2ID = $request->param('item2ID');
	deleteItem($userName, $itemID, $item2ID);
	$queryString = "action=clearItem" .
						"&adminName=" . URLEncode($adminName) .
						"&userName=". URLEncode($userName) .
						"&itemID=". URLEncode($itemID) .
						"&itemName=". URLEncode($itemName);

} else {
	# Login is user
	$adminName = $sessionObj->param("creator");
	checkAdminName($adminName);
	$userName = $sessionObj->param("userName");
	checkUserName($adminName);
	$itemID = $request->param('itemID');
	$item2ID = $request->param('item2ID');
	deleteItem($userName, $itemID, $item2ID);
	$queryString = "action=clearItem" .
						"&adminName=" . URLEncode($adminName) .
						"&userName=". URLEncode($userName) .
						"&itemID=". URLEncode($itemID) .
						"&itemName=". URLEncode($itemName);
}

################################################### SUBROUTINES
#Delete Item
sub deleteItem {
	my ($userName, $itemID, $item2ID) = @_;
	my $directoryName = "$perfhome/var/db/users/$userName";
	my $fileName = "$directoryName/$userName.ser";
	my $userObj = lock_retrieve($fileName) || die("ERROR: Can't retrieve userObj from $fileName\n");
	die("ERROR: can't define userObj from $fileName\n") unless defined($userObj);
	$userObj->{'hostGroups'}->[$itemID]->deleteMember($item2ID);
	lock_store($userObj, "$fileName") || die("ERROR: can't store userObj in $fileName\n");
}

1;