use strict;
package main;
require("lib_inputCheck.pl");

# init message variables
$sessionObj->param("userMessage", "");
my $errorMessage = "";

if ($sessionObj->param("userName") eq "perfstat") {
	# Login is perfstat admin
	$adminName = $request->param('adminName');
	checkAdminName($adminName);
	$userName = $request->param('userName');
	checkUserName($userName);
	$itemID = $request->param('itemID');
	$itemName = trim($request->param('itemName'));
	$errorMessage = checkItemName($itemName);
	$description = trim($request->param('description'));
	if (length($errorMessage) ne 0) {
		$sessionObj->param("userMessage", $errorMessage);
		$queryString = "action=displayUpdateItem" .
						"&adminName=". URLEncode($adminName) .
						"&userName=". URLEncode($userName) .
						"&itemID=". URLEncode($itemID) .
						"&itemName=" . URLEncode($itemName) .
						"&description=" . URLEncode($description);
	} else {
		updateItem($userName, $itemID, $itemName, $description);
		$sessionObj->param("userMessage", "$itemName Updated");
		$queryString = "action=displayUpdateItem" .
						"&adminName=". URLEncode($adminName) .
						"&userName=". URLEncode($userName) .
						"&itemID=". URLEncode($itemID) .
						"&itemName=" . URLEncode($itemName) .
						"&description=" . URLEncode($description);
	}

} elsif ($sessionObj->param("role") eq "admin") {
	# Login is group admin
	$adminName = $sessionObj->param("userName");
	checkAdminName($adminName);
	$userName = $request->param('userName');
	checkUserName($userName);
	$itemID = $request->param('itemID');
	$itemName = trim($request->param('itemName'));
	$errorMessage = checkItemName($itemName);
	$description = trim($request->param('description'));
	if (length($errorMessage) ne 0) {
		$sessionObj->param("userMessage", $errorMessage);
		$queryString = "action=displayUpdateItem" .
						"&adminName=". URLEncode($adminName) .
						"&userName=". URLEncode($userName) .
						"&itemID=". URLEncode($itemID) .
						"&itemName=" . URLEncode($itemName) .
						"&description=" . URLEncode($description);
	} else {
		updateItem($userName, $itemID, $itemName, $description);
		$sessionObj->param("userMessage", "$itemName Updated");
		$queryString = "action=displayUpdateItem" .
						"&adminName=". URLEncode($adminName) .
						"&userName=". URLEncode($userName) .
						"&itemID=". URLEncode($itemID) .
						"&itemName=" . URLEncode($itemName) .
						"&description=" . URLEncode($description);
	}
	
} else {
	# Login is user
	$adminName = $sessionObj->param("creator");
	checkAdminName($adminName);
	$userName = $sessionObj->param("userName");
	checkUserName($userName);
	$itemID = $request->param('itemID');
	$itemName = trim($request->param('itemName'));
	$errorMessage = checkItemName($itemName);
	$description = trim($request->param('description'));
	if (length($errorMessage) ne 0) {
		$sessionObj->param("userMessage", $errorMessage);
		$queryString = "action=displayUpdateItem" .
						"&adminName=". URLEncode($adminName) .
						"&userName=". URLEncode($userName) .
						"&itemID=". URLEncode($itemID) .
						"&itemName=" . URLEncode($itemName) .
						"&description=" . URLEncode($description);
	} else {
		updateItem($userName, $itemID, $itemName, $description);
		$sessionObj->param("userMessage", "$itemName Updated");
		$queryString = "action=displayUpdateItem" .
						"&adminName=". URLEncode($adminName) .
						"&userName=". URLEncode($userName) .
						"&itemID=". URLEncode($itemID) .
						"&itemName=" . URLEncode($itemName) .
						"&description=" . URLEncode($description);
	}
}

################################################### SUBROUTINES
# UPDATE ITEM
sub updateItem {
	my ($userName, $itemID, $itemName, $description) = @_;
	my $directoryName = "$perfhome/var/db/users/$userName";
	my $fileName = "$directoryName/$userName.ser";
	my $userObj = lock_retrieve($fileName) || die("ERROR: Can't retrieve userObj from $fileName\n");
	die("ERROR: can't define userObj from $fileName\n") unless defined($userObj);
	# Create host group object
	$userObj->{'hostGroups'}->[$itemID]->setName($itemName);
	$userObj->{'hostGroups'}->[$itemID]->setDescription($description);
	lock_store($userObj, "$fileName") || die("ERROR: can't store userObj in $fileName\n");
}

1;