use strict;
package main;
print("<html>\n");
print("	<head>\n");
print("		<meta http-equiv=\"content-type\" content=\"text/html;charset=iso-8859-1\">\n");
print("		<title>PerfStat Tool: Perfomance Monitoring & Status Notification</title>\n");
print("		<link rel=\"stylesheet\" type=\"text/css\" href=\"../../perfStatResources/styleSheets/contentFrame.css\" media=\"screen\">\n");
print("		<link rel=\"stylesheet\" type=\"text/css\" href=\"../../perfStatResources/styleSheets/forms.css\" media=\"screen\">\n");
print("		<script language=\"javascript\" src=\"../../perfStatResources/javaScripts/contentFrame.js\"></script>\n");
print("	</head>\n");

print("	<body>\n");
 if ($sessionObj->param("creator") eq "perfstat") {
print("		<table cellpadding=\"2\" cellspacing=\"1\" border=\"0\" class=\"table1\">\n");
print("			<tr>\n");
print("				<form action=\"index.pl\" method=\"post\">\n");
print("				<td nowrap=\"nowrap\" valign=\"middle\" align=\"right\"><span class=\"table1Text1\">Admin:</span></td>\n");
print("				<td nowrap=\"nowrap\" valign=\"middle\" align=\"left\">\n");
print("					<select name=\"adminName\" size=\"1\" onChange=\"submit();\">\n");
 foreach my $adminNameTemp (sort (keys(%$adminList))) {
my $formula0=$adminNameTemp;my $formula1=$adminNameTemp eq $adminName ? "selected" : "";;my $formula2=$adminNameTemp;print("						<option value=\"$formula0\" $formula1>$formula2</option>\n");
 }
print("					</select>\n");
print("				</td>\n");
print("				</form>\n");
print("			</tr>\n");
print("		</table>\n");
}
 if ($sessionObj->param("role") eq "admin") {
 if ($action ne "displayUpdateUser") {
 # Admin is not updating, so display insert form 
print("		<table cellpadding=\"2\" cellspacing=\"1\" border=\"0\" class=\"table1\">\n");
print("			<tr>\n");
print("				<td class=\"tdTop\" nowrap=\"nowrap\" colspan=\"5\" valign=\"middle\" align=\"left\">Add User</td>\n");
print("			</tr>\n");
 if ($sessionObj->param("userMessage") ne "") {
print("			<tr>\n");
my $formula3=$sessionObj->param("userMessage");print("				<td class=\"liteGray\" valign=\"top\" align=\"left\" colspan=\"5\"><span class=\"userMessage\">$formula3</span></td>\n");
print("			</tr>\n");
 $sessionObj->param("userMessage", "");
 }
print("			<tr>\n");
print("				<th nowrap=\"nowrap\" valign=\"middle\" align=\"left\">User Name</th>\n");
print("				<th nowrap=\"nowrap\" valign=\"middle\" align=\"left\">Password</th>\n");
print("				<th nowrap=\"nowrap\" valign=\"middle\" align=\"left\">Confirm Password</th>\n");
print("				<th nowrap=\"nowrap\" valign=\"middle\" align=\"left\">Role</th>\n");
print("				<th nowrap=\"nowrap\" valign=\"middle\" align=\"center\"></th>\n");
print("			</tr>\n");
print("			<tr>\n");
print("				<form name=\"insertUser\" action=\"index.pl\" method=\"post\">\n");
print("				<input type=\"hidden\" name=\"action\" value=\"insertUser\">\n");
my $formula4=$adminName;print("				<input type=\"hidden\" name=\"adminName\" value=\"$formula4\">\n");
my $formula5=$userName;print("				<td class=\"liteGray\" align=\"left\" valign=\"top\"><input type=\"text\" name=\"userName\" value=\"$formula5\" size=\"18\"></td>\n");
print("				<td class=\"liteGray\" nowrap=\"nowrap\" valign=\"top\" align=\"left\"><input type=\"password\" name=\"password\" size=\"15\"></td>\n");
print("					<td class=\"liteGray\" align=\"left\" valign=\"top\"><input type=\"password\" name=\"confirmPassword\" size=\"15\"></td>\n");
print("					<td class=\"liteGray\" align=\"left\" valign=\"top\">\n");
 if ($sessionObj->param("creator") eq "perfstat") {
print("					<select name=\"userRole\" size=\"1\">\n");
my $formula6=$userRole eq "admin" ? "selected" : "";;print("						<option value=\"admin\" $formula6>admin</option>\n");
my $formula7=$userRole eq "user" ? "selected" : "";;print("						<option value=\"user\" $formula7>user</option>\n");
print("					</select>\n");
} else {
print("						<span class=\"table1Text2\">user</span>\n");
}
print("				</td>\n");
print("				<td class=\"darkGray\" valign=\"top\" align=\"center\"><input class=\"liteButton\" type=\"submit\" value=\"ENTER\"></td>\n");
print("				</form>\n");
print("			</tr>\n");
print("		</table>\n");
} else {
 # Admin is updating, so don't display insert form, but do display update form
print("		<table cellpadding=\"2\" cellspacing=\"1\" border=\"0\" class=\"table1\">\n");
print("			<tr>\n");
print("				<td class=\"tdTop\" nowrap=\"nowrap\" colspan=\"5\" valign=\"middle\" align=\"left\">Modify User</td>\n");
print("			</tr>\n");
 if ($sessionObj->param("userMessage") ne "") {
print("			<tr>\n");
my $formula8=$sessionObj->param("userMessage");print("				<td class=\"liteGray\" valign=\"top\" align=\"left\" colspan=\"5\"><span class=\"userMessage\">$formula8</span></td>\n");
print("			</tr>\n");
 $sessionObj->param("userMessage", "");
 }
print("			<tr>\n");
print("				<th nowrap=\"nowrap\" valign=\"middle\" align=\"left\">User Name</th>\n");
print("				<th nowrap=\"nowrap\" valign=\"middle\" align=\"left\">Password</th>\n");
print("				<th nowrap=\"nowrap\" valign=\"middle\" align=\"left\">Confirm Password</th>\n");
print("				<th nowrap=\"nowrap\" valign=\"middle\" align=\"left\">Role</th>\n");
print("				<th nowrap=\"nowrap\" valign=\"middle\" align=\"center\"></th>\n");
print("			</tr>\n");
print("			<tr>\n");
my $formula9=$userName;print("				<form name=\"$formula9\" action=\"index.pl\" method=\"post\">\n");
print("				<input type=\"hidden\" name=\"action\" value=\"updateUser\">\n");
my $formula10=$userName;print("				<input type=\"hidden\" name=\"userName\" value=\"$formula10\">\n");
my $formula11=$adminName;print("				<input type=\"hidden\" name=\"adminName\" value=\"$formula11\">\n");
my $formula12=$userName;print("				<td class=\"liteGray\" align=\"left\" valign=\"top\"><span class=\"table1Text1\">$formula12</span></td>\n");
print("				<td class=\"liteGray\" nowrap=\"nowrap\" valign=\"top\" align=\"left\"><input type=\"password\" name=\"password\" size=\"15\"></td>\n");
print("					<td class=\"liteGray\" align=\"left\" valign=\"top\"><input type=\"password\" name=\"confirmPassword\" size=\"15\"></td>\n");
my $formula13=$userList->{$userName}->getRole();print("					<td class=\"liteGray\" align=\"left\" valign=\"top\"><span class=\"table1Text2\">$formula13</span></td>\n");
print("					<td class=\"darkGray\" valign=\"top\" align=\"center\">\n");
print("						<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" >\n");
print("							<tr>\n");
print("								<td nowrap=\"nowrap\"><input class=\"liteButton\" type=\"submit\" name=\"submit\" value=\"ENTER\"></td>\n");
print("								<td nowrap=\"nowrap\"><input class=\"liteButton\" type=\"submit\" name=\"submit\" value=\"CLEAR\"></td>\n");
print("							</tr>\n");
print("						</table>\n");
print("					</td>\n");
print("				</form>\n");
print("			</tr>\n");
print("		</table>\n");
}
} else {
 # User is updatings self
print("		<table cellpadding=\"2\" cellspacing=\"1\" border=\"0\" class=\"table1\">\n");
print("			<tr>\n");
print("				<td class=\"tdTop\" nowrap=\"nowrap\" colspan=\"5\" valign=\"middle\" align=\"left\">Modify Password</td>\n");
print("			</tr>\n");
 if ($sessionObj->param("userMessage") ne "") {
print("			<tr>\n");
my $formula14=$sessionObj->param("userMessage");print("				<td class=\"liteGray\" valign=\"top\" align=\"left\" colspan=\"5\"><span class=\"userMessage\">$formula14</span></td>\n");
print("			</tr>\n");
 $sessionObj->param("userMessage", "");
 }
print("			<tr>\n");
print("				<th nowrap=\"nowrap\" valign=\"middle\" align=\"left\">User Name</th>\n");
print("				<th nowrap=\"nowrap\" valign=\"middle\" align=\"left\">Password</th>\n");
print("				<th nowrap=\"nowrap\" valign=\"middle\" align=\"left\">Confirm Password</th>\n");
print("				<th nowrap=\"nowrap\" valign=\"middle\" align=\"left\">Role</th>\n");
print("				<th nowrap=\"nowrap\" valign=\"middle\" align=\"center\"></th>\n");
print("			</tr>\n");
print("			<tr>\n");
my $formula15=$userName;print("				<form name=\"$formula15\" action=\"index.pl\" method=\"post\">\n");
print("				<input type=\"hidden\" name=\"action\" value=\"updateUser\">\n");
my $formula16=$userName;print("				<input type=\"hidden\" name=\"userName\" value=\"$formula16\">\n");
my $formula17=$adminName;print("				<input type=\"hidden\" name=\"adminName\" value=\"$formula17\">\n");
my $formula18=$userName;print("				<td class=\"liteGray\" align=\"left\" valign=\"top\"><span class=\"table1Text1\">$formula18</span></td>\n");
print("				<td class=\"liteGray\" nowrap=\"nowrap\" valign=\"top\" align=\"left\"><input type=\"password\" name=\"password\" size=\"15\"></td>\n");
print("					<td class=\"liteGray\" align=\"left\" valign=\"top\"><input type=\"password\" name=\"confirmPassword\" size=\"15\"></td>\n");
print("					<td class=\"liteGray\" align=\"left\" valign=\"top\"><span class=\"table1Text2\">user</span></td>\n");
print("					<td class=\"darkGray\" valign=\"top\" align=\"center\">\n");
print("						<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" >\n");
print("							<tr>\n");
print("								<td nowrap=\"nowrap\"><input class=\"liteButton\" type=\"submit\" name=\"submit\" value=\"ENTER\"></td>\n");
print("							</tr>\n");
print("						</table>\n");
print("					</td>\n");
print("				</form>\n");
print("			</tr>\n");
print("		</table>\n");
}
 if ($sessionObj->param("role") eq "admin") {
print("		<table width=\"100%\" cellpadding=\"2\" cellspacing=\"1\" border=\"0\" class=\"table1\">\n");
print("			<tr>\n");
my $formula19=$sessionObj->param("role") eq "admin" ? "Users" : "Password";print("				<td class=\"tdTop\" nowrap=\"nowrap\" colspan=\"4\" valign=\"middle\" align=\"left\">Manage $formula19</td>\n");
print("			</tr>\n");
print("			<tr>\n");
print("				<th nowrap=\"nowrap\" valign=\"middle\" align=\"center\" width=\"10\">Actions</th>\n");
print("				<th nowrap=\"nowrap\" valign=\"middle\" align=\"left\">User Name</th>\n");
print("				<th nowrap=\"nowrap\" valign=\"middle\" align=\"left\">Password</th>\n");
print("				<th nowrap=\"nowrap\" valign=\"middle\" align=\"left\">Role</th>\n");
print("			</tr>\n");
 # always display admin at top of user list
print("			<tr>\n");
$queryString = "&adminName=$adminName&userName=$adminName";
print("				<td class=\"liteGray\" align=\"center\" valign=\"top\" width=\"10\">\n");
print("					<table cellpadding=\"1\" cellspacing=\"1\" border=\"0\" class=\"table2\">\n");
print("						<tr>\n");
my $formula20=$queryString;print("							<th nowrap=\"nowrap\"><a href=\"index.pl?action=displayUpdateUser$formula20\">Modify</a></th>\n");
 if ($sessionObj->param("creator") eq "perfstat" && $adminName ne "perfstat") {
my $formula21=$queryString;my $formula22=$adminName;print("							<th nowrap=\"nowrap\"><a href=\"index.pl?action=deleteUser$formula21\" onclick=\"return warnOnClickAnchor('Are you sure you want to delete $formula22')\">Delete</a></th>\n");
}
print("						</tr>\n");
print("					</table>\n");
print("				</td>\n");
my $formula23=$adminName;print("				<td class=\"liteGray\" align=\"left\" valign=\"top\"><span class=\"table1Text1\">$formula23</span></td>\n");
print("				<td class=\"liteGray\" nowrap=\"nowrap\" valign=\"top\" align=\"left\"><span class=\"table1Text2\">XXXXXX</span></td>\n");
print("				<td class=\"liteGray\" align=\"left\" valign=\"top\"><span class=\"table1Text2\">admin</span></td>\n");
print("				</form>\n");
print("			</tr>\n");
foreach my $userNameTemp (sort(keys(%$userList))) {
 if ($userList->{$userNameTemp} ->getRole() ne "admin") {
 # If admin always loop all personell that admin created and display users
print("			<tr>\n");
$queryString = "&adminName=$adminName&userName=$userNameTemp";
print("				<td class=\"liteGray\" align=\"center\" valign=\"top\" width=\"10\">\n");
print("					<table cellpadding=\"1\" cellspacing=\"1\" border=\"0\" class=\"table2\" width=\"100%\">\n");
print("						<tr>\n");
my $formula24=$queryString;print("							<th nowrap=\"nowrap\"><a href=\"index.pl?action=displayUpdateUser$formula24\">Modify</a></th>\n");
my $formula25=$queryString;my $formula26=$userNameTemp;print("							<th nowrap=\"nowrap\"><a href=\"index.pl?action=deleteUser$formula25\" onclick=\"return warnOnClickAnchor('Are you sure you want to delete $formula26')\">Delete</a></th>\n");
print("						</tr>\n");
print("					</table>\n");
print("				</td>\n");
my $formula27=$userNameTemp;print("				<td class=\"liteGray\" align=\"left\" valign=\"top\"><span class=\"table1Text1\">$formula27</span></td>\n");
print("				<td class=\"liteGray\" nowrap=\"nowrap\" valign=\"top\" align=\"left\"><span class=\"table1Text2\">XXXXXX</span></td>\n");
my $formula28=$userList->{$userNameTemp}->getRole();print("				<td class=\"liteGray\" align=\"left\" valign=\"top\"><span class=\"table1Text2\">$formula28</span></td>\n");
print("			</tr>\n");
}
}
print("		</table>\n");
}
print("	</body>\n");
print("</html>\n");
