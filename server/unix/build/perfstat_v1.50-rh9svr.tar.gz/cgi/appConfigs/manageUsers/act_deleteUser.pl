use strict;
package main;
require("lib_inputCheck.pl");
# init message variables
$sessionObj->param("userMessage", "");
my $errorMessage = "";

if ($sessionObj->param("userName") eq "perfstat") {
	# Login is root admin
	$adminName = $request->param('adminName');
	checkAdminName("delete", $adminName);
	$userName = trim($request->param('userName'));
	if ($userName eq "perfstat") {
		die("ERROR: perfstate can't delete self");
	}
	checkUserName2($userName, $perfhome);
	$userRole = $userIndex->{$adminName}->{$userName}->getRole();
	if ($userRole eq "admin") {
		deleteUser($adminName, $userName, $userRole, $perfhome);
		$queryString = "";
	} elsif ($userRole eq "user") {
		deleteUser($adminName, $userName, $userRole, $perfhome);
		$queryString = "adminName=$adminName";
	} else {
		die('ERROR: invalid value for $userRole');
	}

} elsif ($sessionObj->param("role") eq "admin") {
	# Login is group admin
	$adminName = $sessionObj->param("userName");
	checkAdminName("delete", $adminName);
	$userName = trim($request->param('userName'));
	if ($adminName eq $userName) {
		die("ERROR: group admin can't delete self");
	}
	checkUserName2($userName, $perfhome);
	$userRole = $userIndex->{$adminName}->{$userName}->getRole();
	if ($userRole eq "admin") {
		die("ERROR: group admin can't delete admin");
	} elsif ($userRole eq "user") {
		deleteUser($adminName, $userName, $userRole, $perfhome);
	} else {
		die('ERROR: invalid value for $userRole');
	}
	$queryString = "";
	
} else {
	# Login is user
	die("ERROR: builder can't delete a user")
}
################################################### SUBROUTINES
sub deleteUser {
	my ($adminName, $userName, $userRole, $perfhome) = @_;

	if ($userRole eq "admin") {
		my $userList = $userIndex->{$userName};
		## delete admin's users in filesystem
		
		foreach my $userNameTemp (sort(keys(%$userList))) {
			opendir(USERDIR, "$perfhome/var/db/users/$userNameTemp") or die("WARNING: Couldn't open dir $perfhome/var/db/users/$userNameTemp: $!\n");
			while (my $fileName = readdir(USERDIR)) {
				# Skip if file starts with a . 
				next if ($fileName =~ m/^\.\.?$/);
				unlink("$perfhome/var/db/users/$userNameTemp/$fileName");
			}
			closedir(USERDIR);
			rmdir("$perfhome/var/db/users/$userNameTemp") or die("WARNING: Couldn't remove dir $perfhome/var/db/users/$userNameTemp: $!\n") ;
		}

		## delete admin's key in user index
		delete($userIndex->{$userName});
		
	} elsif($userRole eq "user") {
		## delete user in filesystem
		opendir(USERDIR, "$perfhome/var/db/users/$userName") or die("WARNING: Couldn't open dir $perfhome/var/db/users/$userName: $!\n");
		while (my $fileName = readdir(USERDIR)) {
				# Skip if file starts with a . 
				next if ($fileName =~ m/^\.\.?$/);
				unlink("$perfhome/var/db/users/$userName/$fileName");
			}
			closedir(USERDIR);
			rmdir("$perfhome/var/db/users/$userName") or die("WARNING: Couldn't remove dir $perfhome/var/db/users/$userName: $!\n") ;
		## delete user's key in user index
		delete($userIndex->{$adminName}->{$userName});
	} else {
		die('ERROR: invalid value for $userRole');
	}
}

1;