#  input check functions
sub checkAdminName {
	my ($action, $adminName) = @_;
	if (length($adminName) == 0) {die('Error: missing required value for $adminName');}
	if ($action ne "insert") {
		if(!(-d "$perfhome/var/db/users/$adminName")) {die('Error: invalid value for $adminName: no user directory');}
		if(!(-e "$perfhome/var/db/users/$adminName/$adminName.ser")) {die('Error: invalid value for $adminName: no user file');}
		if (!(exists( $userIndex->{$adminName}->{$adminName}))) {die('Error: invalid value for $adminName');}
	}
	elsif ($action eq "insert" && $sessionObj->param("creator") ne "perfstat") {
		if(!(-d "$perfhome/var/db/users/$adminName")) {die('Error: invalid value for $adminName: no user directory');}
		if(!(-e "$perfhome/var/db/users/$adminName/$adminName.ser")) {die('Error: invalid value for $adminName: no user file');}
		if (!(exists( $userIndex->{$adminName}->{$adminName}))) {die('Error: invalid value for $adminName');}
	}
}

sub checkUserName1 {
	my ($userName) = @_;
	if (length($userName) == 0) {return("Please enter a user name");}
	if (containsNonWordChar($userName)) {return("User Name has an illegal character or space");}
	if (length($userName) < 4) {return("User Name must have at least 4 characters");}
	if(-d "$perfhome/var/db/users/$userName") {return("User Name is already taken");}
}

sub checkUserName2 {
	my ($userName, $perfhome) = @_;
	if (length($userName) == 0) {die('Error: missing required value for $userName');}
	if(!(-d "$perfhome/var/db/users/$userName")) {die('Error: invalid value for $userName: no user directory');}
	if(!(-e "$perfhome/var/db/users/$userName/$userName.ser")) {die('Error: invalid value for $userName: no user file');}
}

sub checkUserRole {
	my ($userRole) = @_;
	if (length($userRole) == 0) {die('Error: missing required value for $userRole');}
	if ($userRole ne "admin" && $userRole ne "user") { die('Error: invalid value for $userRole');}
}

sub checkPassword {
	my ($password) = @_;
	if (length($password) == 0) {return("Please enter a password");}
	if (length($password) < 8) {return("Password must have at least 8 characters");}
}

sub checkConfirmPassword {
	my ($password, $confirmPassword) = @_;
	if ($password ne $confirmPassword) {return("Password and Confirm Password do not match");}
}

1;