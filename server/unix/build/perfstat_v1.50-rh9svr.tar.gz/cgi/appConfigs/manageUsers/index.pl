#!/usr/bin/perl -w

use strict;

BEGIN
{
	unshift(@INC, "../..");
	require("app_globals.pl");
}

use vars qw($action $adminName $userName $password $confirmPassword $userRole $adminList $userList $userID $queryString);

$request = new CGI;
$action = "";
$action = $request->param('action');

if ($action eq "insertUser")
{
	require("act_insertUser.pl");
	metaRedirect(0, "index.pl?$queryString");
}
elsif ($action eq "updateUser")
{
	if ($request->param("submit") eq "CLEAR")
	{
		if ($doParse) {PerfStatCGI::Parser->html2Perl("dsp_home.html");}
		$request->delete('userName');
		$request->delete('password');
		$request->delete('confirmPassword');
		require("act_initDisplayHome.pl");
		require("dsp_home.pl");
	}
	else
	{
		require("act_updateUser.pl");
		metaRedirect(0, "index.pl?$queryString");
	}
}
elsif ($action eq "deleteUser")
{
	require("act_deleteUser.pl");
	metaRedirect(0, "index.pl?$queryString");
}
elsif ($action eq "clearItem")
{
	if ($doParse) {PerfStatCGI::Parser->html2Perl("dsp_home.html");}
	$request->delete('userName');
	$request->delete('password');
	$request->delete('confirmPassword');
	require("act_initDisplayHome.pl");
	require("dsp_home.pl");
}
else
{
	if ($doParse) {PerfStatCGI::Parser->html2Perl("dsp_home.html");}
	require("act_initDisplayHome.pl");
	require("dsp_home.pl");
}