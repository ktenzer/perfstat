#!/usr/bin/perl -w
use strict;
BEGIN
{
	unshift(@INC, "../../..");
	require("app_globals.pl");
}

use vars qw($action $allHostArray $allHostServiceHash $hostGroupHash);

$request = new CGI;
$action = undef;
$action = $request->param('action');

if ($doParse) {PerfStatCGI::Parser->html2Perl("dsp_level1.html");}
require("act_initLevel1.pl");
require("dsp_level1.pl");