use strict;
package main;
print("<html>\n");
print("	<head>\n");
print("		<meta http-equiv=\"content-type\" content=\"text/html;charset=iso-8859-1\">\n");
print("		<title>PerfStat Tool: Perfomance Monitoring & Status Notification</title>\n");
print("		<link rel=\"stylesheet\" type=\"text/css\" href=\"../../../perfStatResources/styleSheets/contentFrame.css\" media=\"screen\">\n");
print("		<script language=\"javascript\" src=\"../../../perfStatResources/javaScripts/contentFrame.js\"></script>\n");
print("	</head>\n");

my $formula0=$sessionObj->param("serviceName");print("	<body onLoad=\"statusLevel3InitialToggle('$formula0');\">\n");
print("		<div class=\"navHeader\">\n");
my $formula1=$sessionObj->param("hostGroupID");my $formula2=$hostGroupName;my $formula3=$sessionObj->param("hostName");print("			<a href=\"../level1/index.pl\">Host Groups:</a> <a href=\"../level2/index.pl?hostGroupID=$formula1\">$formula2</a>: $formula3\n");
print("		</div>\n");
print("		<table width=\"100%\" cellpadding=\"2\" cellspacing=\"1\" border=\"0\" class=\"table1\">\n");
print("			<tr>\n");
print("				<td class=\"tdTop\" nowrap=\"nowrap\" valign=\"middle\" align=\"left\">Service Status Report</td>\n");
print("			</tr>\n");
print("			<tr>\n");
print("				<td class=\"darkGray\" align=\"left\" valign=\"top\" height=\"50\">\n");
 if (%$serviceHashRefined == 0) {
print("						<table cellpadding=\"1\" cellspacing=\"1\" border=\"0\" class=\"table2\" width=\"100%\">\n");
print("							<tr>\n");
print("								<td>No status metrics currently available</td>\n");
print("							</tr>\n");
print("						</table>\n");
 } else {
print("						<table border=\"0\" cellpadding=\"2\" cellspacing=\"2\">\n");
print("							<tr>\n");
 foreach my $serviceHashRefinedKey (sort(keys(%$serviceHashRefined))) {
my $serviceDescHash = $serviceHashRefined->{$serviceHashRefinedKey};
print("								<td width=\"40\" valign=\"top\" align=\"center\">					\n");
if ($serviceDescHash->{'hasSubService'} != 1) {
print("									<table cellpadding=\"1\" cellspacing=\"1\" border=\"0\" class=\"table2\" width=\"100%\">\n");
print("										<tr>\n");
my $formula4=$serviceHashRefinedKey;print("											<th nowrap=\"nowrap\">$formula4</th>\n");
print("										</tr>\n");
print("										<tr>\n");
my $formula5=$sessionObj->param("hostGroupID");my $formula6=$sessionObj->param("hostName");my $formula7=$serviceHashRefinedKey;my $formula8=$serviceDescHash->{'status'};print("											<td valign=\"top\" align=\"center\"><a href=\"index.pl?hostGroupID=$formula5&hostName=$formula6&serviceName=$formula7\"><img src=\"../../../perfStatResources/images/content/status_$formula8.gif\" width=\"20\" height=\"20\" /></a></td>\n");
print("										</tr>\n");
print("									</table>\n");
} else {
my $subServiceHash = $serviceDescHash->{'subServiceHash'};
print("									<table cellpadding=\"1\" cellspacing=\"1\" border=\"0\" class=\"table2\" width=\"100%\">\n");
print("										<tr>\n");
my $formula9=$serviceHashRefinedKey;my $formula10=$serviceHashRefinedKey;my $formula11=$serviceHashRefinedKey;my $formula12=$serviceHashRefinedKey;print("											<th nowrap=\"nowrap\" valign=\"middle\" align=\"left\"><a href=\"javascript:toggle('$formula9-off', '$formula10-on');\"><img id=\"x$formula11-off\" src=\"../../../perfStatResources/images/navigation/icon_plusNavBar.gif\" width=\"9\" height=\"9\" border=\"0\"></a>&nbsp;$formula12</th>\n");
print("										</tr>\n");
print("										<tr>\n");
print("											<td valign=\"top\" align=\"center\">\n");
my $formula13=$serviceHashRefinedKey;print("												<div id=\"$formula13-off\" style=\"display:block;\">\n");
my $formula14=$serviceDescHash->{'status'};print("													<img src=\"../../../perfStatResources/images/content/status_$formula14.gif\" width=\"20\" height=\"20\" />\n");
print("												</div>\n");
my $formula15=$serviceHashRefinedKey;print("												<div id=\"$formula15-on\" style=\"display:none;\">\n");
print("													<table border=\"0\" cellpadding=\"1\" cellspacing=\"1\" class=\"table2\">\n");
foreach my $subServiceHashKey (sort(keys(%$subServiceHash))) {
print("														<tr>\n");
my $formula16=$sessionObj->param("hostGroupID");my $formula17=$sessionObj->param("hostName");my $formula18=$serviceHashRefinedKey;my $formula19=$subServiceHashKey;my $formula20=$subServiceHashKey;print("															<td style=\"text-align:right;\"><a href=\"index.pl?hostGroupID=$formula16&hostName=$formula17&serviceName=$formula18.$formula19\">$formula20</a></td>\n");
my $formula21=$subServiceHash->{$subServiceHashKey};print("															<td><img src=\"../../../perfStatResources/images/content/status_$formula21.gif\" width=\"20\" height=\"20\" /></td>\n");
print("														</tr>\n");
}
print("													</table>\n");
print("												</div>\n");
print("											</td>\n");
print("										</tr>\n");
print("									</table>\n");
 }
print("								</td>\n");
}
print("							</tr>\n");
print("						</table>\n");
}
print("				</td>\n");
print("			</tr>\n");
print("		</table>\n");
 if (length($sessionObj->param("serviceName")) != 0) {
print("		<div align=\"center\">\n");
print("		<table cellpadding=\"2\" cellspacing=\"1\" border=\"0\" class=\"table1\">\n");
print("			<tr>\n");
my $formula22=$sessionObj->param("serviceName");print("					<td class=\"tdTop\" nowrap colspan=\"6\" valign=\"middle\" align=\"left\">$formula22</td>\n");
print("				</tr>\n");
print("			<tr>\n");
print("					<th nowrap valign=\"middle\" align=\"left\">Metric</th>\n");
print("					<th nowrap valign=\"middle\" align=\"left\">Warn</th>\n");
print("					<th nowrap valign=\"middle\" align=\"left\">Crit</th>\n");
print("					<th nowrap valign=\"middle\" align=\"left\">Unit</th>\n");
print("					<th nowrap valign=\"middle\" align=\"left\">Value</th>\n");
print("					<th nowrap valign=\"middle\" align=\"left\">Status</th>\n");
print("				</tr>\n");
my $serviceMetricArray = $hostIndex->{$sessionObj->param("hostName")}->{'serviceIndex'}->{$sessionObj->param("serviceName")}->{'metricArray'};
foreach my $metricObject (@$serviceMetricArray) {
 my $hasEvents = $metricObject->getHasEvents();
 if ($hasEvents == 1) {
 my $friendlyName = $metricObject->getFriendlyName();
 my $warnThreshold = $metricObject->getWarnThreshold();
 if (! defined $warnThreshold) { $warnThreshold="null"; };
print("\n");
 my $critThreshold = $metricObject->getCritThreshold();
 if (! defined $critThreshold) { $critThreshold="null"; };
print("\n");
 my $thresholdUnit = $metricObject->getThresholdUnit();
 if (! defined $thresholdUnit) { $thresholdUnit="null"; };
print("\n");
 my $metricValue = $metricObject->getMetricValue();
 if (! defined $metricValue) { $metricValue="null"; };
print("\n");
 my $status = $metricObject->getStatus();
print("			<tr>\n");
my $formula23=$friendlyName;print("				<td class=\"liteGray\"><span class=\"table1Text2\">$formula23</span></td>\n");
my $formula24=$warnThreshold;print("				<td class=\"liteGray\"><span class=\"table1Text2\">$formula24</span></td>\n");
my $formula25=$critThreshold;print("				<td class=\"liteGray\"><span class=\"table1Text2\">$formula25</span></td>\n");
 #<td class="liteGray" valign="middle" align="center"><%$thresholdUnit%></td>
my $formula26=$thresholdUnit;print("				<td class=\"liteGray\"> <span class=\"table1Text2\">$formula26</span></td>\n");
my $formula27=$metricValue;print("				<td class=\"liteGray\"> <span class=\"table1Text2\">$formula27</span></td>\n");
my $formula28=$status;print("				<td class=\"darkGray\" valign=\"middle\" align=\"center\"><img src=\"../../../perfStatResources/images/content/status_$formula28.gif\" width=\"20\" height=\"20\"></td>\n");
print("			</tr>\n");
}
}
print("			<tr>\n");
print("				<form action=\"../level4/index.pl\" method=\"get\">\n");
my $formula29=$sessionObj->param("hostGroupID");print("					<input type=\"hidden\" name=\"hostGroupID\" value=\"$formula29\">\n");
my $formula30=$sessionObj->param("hostName");print("					<input type=\"hidden\" name=\"hostName\" value=\"$formula30\">\n");
my $formula31=$sessionObj->param("serviceName");print("					<input type=\"hidden\" name=\"serviceName\" value=\"$formula31\">\n");
print("					<td class=\"tdBottom\" colspan=\"6\" valign=\"middle\" align=\"center\"><input class=\"liteButton\" type=\"submit\" value=\"View Event Log\" /></td>\n");
print("				</form>\n");
print("			</tr>\n");
print("			</table>\n");
print("		</div>\n");
}
print("	</body>\n");
print("</html>\n");
