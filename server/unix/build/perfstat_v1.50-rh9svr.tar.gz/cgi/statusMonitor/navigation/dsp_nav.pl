use strict;
package main;
print("<html>\n");
print("	<head>\n");
print("		<meta http-equiv=\"content-type\" content=\"text/html;charset=iso-8859-1\">\n");
print("		<title>PerfStat Tool: Perfomance Monitoring & Status Notification</title>\n");
print("		<link type=\"text/css\" rel=\"stylesheet\" href=\"../../perfStatResources/styleSheets/navigationFrame.css\">\n");
print("		<script language=\"javascript\" src=\"../../perfStatResources/javaScripts/navigationFrame.js\"></script>\n");
print("	</head>\n");
print("	<body onLoad=\"onBodyLoad('status');\">\n");
 if ($sessionObj->param("userName") eq "perfstat" || $sessionObj->param("role") eq "admin") {
print("		<table cellpadding=\"2\" cellspacing=\"1\" border=\"0\" class=\"table1\" width=\"100%\">\n");
 if ($sessionObj->param("userName") eq "perfstat") {
print("			<tr>\n");
print("				<form action=\"index.pl\" method=\"get\">\n");
print("				<td nowrap=\"nowrap\" valign=\"middle\" align=\"right\"><span class=\"table1Text1\">Admin:</span></td>\n");
print("				<td nowrap=\"nowrap\" valign=\"middle\" align=\"left\">\n");
print("					<select name=\"adminName\" size=\"1\" onChange=\"submit();\">\n");
 foreach my $adminNameTemp (sort (keys(%$adminList))) {
my $formula0=$adminNameTemp;my $formula1=$adminNameTemp eq $sessionObj->param("selectedAdmin") ? "selected" : "";;my $formula2=$adminNameTemp;print("						<option value=\"$formula0\" $formula1>$formula2</option>\n");
 }
print("					</select>\n");
print("				</td>\n");
print("				</form>\n");
print("			</tr>\n");
}
 if ($sessionObj->param("role") eq "admin") {
print("			<tr>\n");
print("				<form action=\"index.pl\" method=\"get\">\n");
my $formula3=$sessionObj->param("selectedAdmin");print("				<input type=\"hidden\" name=\"adminName\" value=\"$formula3\">\n");
print("				<td nowrap=\"nowrap\" valign=\"middle\" align=\"right\"><span class=\"table1Text1\">User:</span></td>\n");
print("				<td nowrap=\"nowrap\" valign=\"middle\" align=\"left\">\n");
print("					<select name=\"userName\" size=\"1\" onChange=\"submit();\">\n");
 foreach my $userNameTemp (sort (keys(%$userList))) {
my $formula4=$userNameTemp;my $formula5=$userNameTemp eq $sessionObj->param("selectedUser")  ? "selected" : "";;my $formula6=$userNameTemp;print("						<option value=\"$formula4\" $formula5>$formula6</option>\n");
 }
print("					</select>\n");
print("				</td>\n");
print("				</form>\n");
print("			</tr>\n");
}
print("		</table>\n");
}
print("		<table border=\"0\" align=\"center\" cellpadding=\"3\" cellspacing=\"1\" class=\"table1\" width=\"100%\">\n");
print("		<tr> \n");
print("			<td height=\"25\" class=\"header\">Status Monitor</td>\n");
print("		</tr>\n");
print("		<tr> \n");
print("			<td height=\"25\" class=\"subheader\">\n");
print("				<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" class=\"table2\" align=\"center\">\n");
print("					<tr>\n");
print("						<td nowrap><a href=\"javascript:openAll();\">open all</a></td>\n");
print("						<td nowrap><img src=\"../../perfStatResources/images/common/spacer.gif\" height=\"6\" width=\"10\" border=\"0\"></td>\n");
print("						<td nowrap><a href=\"javascript:closeAll();\">close all</a></td>\n");
print("					</tr>\n");
print("				</table>\n");
print("			</td>\n");
print("		</tr>\n");
print("		<tr>\n");
print("			<td align=\"left\" valign=\"top\">\n");
print("				<table border=\"0\" cellpadding=\"2\" cellspacing=\"0\">\n");
print("					<tr>\n");
print("						<td><img src=\"../../perfStatResources/images/navigation/icon_statusMonitor2.gif\" border=\"0\"></td>\n");
print("						<td nowrap><a href=\"../content/level1/index.pl?hostGroupID=allHosts\" target=\"content\">Status Home</a></td>\n");
print("					</tr>\n");
print("				</table>\n");
print("			</td>\n");
print("		</tr>\n");
print("			<tr>\n");
print("			<td align=\"left\" valign=\"top\">\n");
print("				<div id=\"navContainer\" style=\"margin-left:5px\">\n");
print("				<table border=\"0\" cellpadding=\"2\" cellspacing=\"0\">\n");
print("					<tr>\n");
print("						<td>\n");
 if (%$allHostHash == 0) {
print("							<img src=\"../../perfStatResources/images/common/spacer.gif\" border=\"0\" width=\"9\" height=\"9\">\n");
 } else {
print("							<a id=\"xallHosts\" href=\"javascript:Toggle('allHosts');\"><img name=\"xallHosts\" src=\"../../perfStatResources/images/navigation/icon_plusNavBar.gif\" border=\"0\" width=\"9\" height=\"9\"></a>\n");
}
print("						</td>\n");
print("						<td><img src=\"../../perfStatResources/images/navigation/icon_statusMonitor1.gif\" border=\"0\"></td>\n");
print("						<td>\n");
 if (%$allHostHash == 0) {
print("								All Hosts\n");
 } else {
print("								<a target=\"content\" href=\"../content/level2/index.pl?hostGroupID=allHosts\" onClick=\"Toggle('allHosts');\">All Hosts</a>\n");
 }
print("						</td>\n");
print("					</tr>\n");
print("				</table>\n");
 if (%$allHostHash != 0) {
print("				<div id=\"allHosts\" style=\"display:none; margin-left:1em;\">\n");
 foreach my $allHostMember (sort(keys(%$allHostHash))) {
 my $hostDescHash = $allHostHash->{$allHostMember};
 my $hasServices = $hostDescHash->{'hasServices'};
print("				<table border=\"0\" cellpadding=\"2\" cellspacing=\"0\">\n");
print("					<tr>\n");
print("						<td>\n");
 if ($hasServices == 0) {
print("								<img src=\"../../perfStatResources/images/common/spacer.gif\" border=\"0\" width=\"9\" height=\"9\">\n");
} else {
my $formula7=$allHostMember;my $formula8=$allHostMember;my $formula9=$allHostMember;print("								<a id=\"xallHosts^$formula7\" href=\"javascript:Toggle('allHosts^$formula8');\"><img name=\"xallHosts^$formula9\" src=\"../../perfStatResources/images/navigation/icon_plusNavBar.gif\" border=\"0\"></a>\n");
}
print("						</td>\n");
print("						<td><img src=\"../../perfStatResources/images/navigation/icon_statusMonitor2.gif\" border=\"0\"></td>\n");
print("						<td nowrap>\n");
 if ($hasServices == 0) {
my $formula10=$allHostMember;print("							$formula10\n");
} else {
my $formula11=$allHostMember;my $formula12=$allHostMember;my $formula13=$allHostMember;print("							<a target=\"content\" href=\"../content/level3/index.pl?hostGroupID=allHosts&hostName=$formula11\" onClick=\"Toggle('allHosts^$formula12')\">$formula13</a>\n");
}
print("						</td>\n");
print("					</tr>\n");
print("				</table>\n");
 if ($hasServices != 0) {
my $formula14=$allHostMember;print("				<div id=\"allHosts^$formula14\" style=\"display:none; margin-left:12px\">\n");
my $serviceHashRefined = $hostDescHash->{'serviceHash'};
foreach my $serviceHashRefinedKey (sort(keys(%$serviceHashRefined))) {
my $serviceDescHash = $serviceHashRefined->{$serviceHashRefinedKey};
 if ($serviceDescHash->{'hasSubService'} != 1) {
print("				<table border=\"0\" cellpadding=\"2\" cellspacing=\"0\">\n");
print("					<tr>\n");
print("						<td><img src=\"../../perfStatResources/images/common/spacer.gif\" height=\"10\" width=\"9\" border=\"0\"></td>\n");
print("						<td><img src=\"../../perfStatResources/images/navigation/icon_statusMonitor3.gif\" border=\"0\"></td>\n");
my $formula15=$allHostMember;my $formula16=$serviceHashRefinedKey;my $formula17=$serviceHashRefinedKey;print("						<td><a href=\"../content/level3/index.pl?hostGroupID=allHosts&hostName=$formula15&serviceName=$formula16\" target=\"content\">$formula17</a></td>\n");
print("					</tr>\n");
print("				</table>\n");
 } else {
my $subServiceHash = $serviceDescHash->{'subServiceHash'};
my @list = sort(keys(%$subServiceHash));
print("				<table border=\"0\" cellpadding=\"2\" cellspacing=\"0\">\n");
print("				<tr>\n");
my $formula18=$allHostMember;my $formula19=$serviceHashRefinedKey;my $formula20=$allHostMember;my $formula21=$serviceHashRefinedKey;my $formula22=$allHostMember;my $formula23=$serviceHashRefinedKey;print("					<td><a id=\"xallHosts^$formula18^$formula19\" href=\"javascript:Toggle('allHosts^$formula20^$formula21');\"><img name=\"xallHosts^$formula22^$formula23\" src=\"../../perfStatResources/images/navigation/icon_plusNavBar.gif\" border=\"0\"></a></td>\n");
print("					<td><img src=\"../../perfStatResources/images/navigation/icon_statusMonitor3.gif\" border=\"0\"></td>\n");
my $formula24=$allHostMember;my $formula25=$serviceHashRefinedKey;my $formula26=$list[0];my $formula27=$allHostMember;my $formula28=$serviceHashRefinedKey;my $formula29=$serviceHashRefinedKey;print("					<td nowrap><a target=\"content\" href=\"../content/level3/index.pl?hostGroupID=allHosts&hostName=$formula24&serviceName=$formula25.$formula26\" onClick=\"Toggle('allHosts^$formula27^$formula28');\">$formula29</a></td>\n");
print("				</tr>\n");
print("				</table>\n");
my $formula30=$allHostMember;my $formula31=$serviceHashRefinedKey;print("				<div id=\"allHosts^$formula30^$formula31\" style=\"display:none; margin-left:12px;\">\n");
foreach my $subServiceHashKey (sort(keys(%$subServiceHash))) {
print("				<table border=\"0\" cellpadding=\"2\" cellspacing=\"0\">\n");
print("					<tr>\n");
print("						<td><img src=\"../../perfStatResources/images/common/spacer.gif\" height=\"10\" width=\"9\" border=\"0\"></td>\n");
print("						<td><img src=\"../../perfStatResources/images/navigation/icon_statusMonitor3.gif\" border=\"0\"></td>\n");
my $formula32=$allHostMember;my $formula33=$serviceHashRefinedKey;my $formula34=$subServiceHashKey;my $formula35=$subServiceHashKey;print("						<td><a target=\"content\" href=\"../content/level3/index.pl?hostGroupID=allHosts&hostName=$formula32&serviceName=$formula33.$formula34\">$formula35</a></td>\n");
print("					</tr>\n");
print("				</table>\n");
}
print("				</div>\n");
}
}
print("				</div>\n");
}
}
print("				</div>\n");
}
foreach my $hostGroup (sort(keys(%$hostGroupHash))) {
my $hostGroupDescHash = $hostGroupHash->{$hostGroup};
my $hasHosts = $hostGroupDescHash->{'hasHosts'};
my $hostGroupID = $hostGroupDescHash->{'hostGroupID'};
print("				<table border=\"0\" cellpadding=\"2\" cellspacing=\"0\">\n");
print("					<tr>\n");
print("						<td>\n");
 if ($hasHosts == 0) {
print("							<img src=\"../../perfStatResources/images/common/spacer.gif\" border=\"0\" width=\"9\" height=\"9\">\n");
 } else {
my $formula36=$hostGroupID;my $formula37=$hostGroupID;my $formula38=$hostGroupID;print("							<a id=\"x$formula36\" href=\"javascript:Toggle('$formula37');\"><img name=\"x$formula38\" src=\"../../perfStatResources/images/navigation/icon_plusNavBar.gif\" border=\"0\"></a>\n");
 }
print("						</td>\n");
print("						<td><img src=\"../../perfStatResources/images/navigation/icon_statusMonitor1.gif\" border=\"0\"></td>\n");
print("						<td>\n");
 if ($hasHosts == 0) {
my $formula39=$hostGroup;print("								$formula39\n");
} else {
my $formula40=$hostGroupID;my $formula41=$hostGroupID;my $formula42=$hostGroup;print("							<a target=\"content\" href=\"../content/level2/index.pl?hostGroupID=$formula40\" onClick=\"Toggle('$formula41');\">$formula42</a>\n");
}
print("						</td>\n");
print("					</tr>\n");
print("				</table>\n");
 if ($hasHosts != 0) {
my $formula43=$hostGroupID;print("				<div id=\"$formula43\" style=\"display:none; margin-left:1em\">\n");
my $hostGroupMemberHash = $hostGroupDescHash->{'hostGroupMemberHash'};
foreach my $hostGroupMember (sort(keys(%$hostGroupMemberHash))) {
my $hostDescHash = $hostGroupMemberHash->{$hostGroupMember};
my $hasServices = $hostDescHash->{'hasServices'};
print("				<table border=\"0\" cellpadding=\"2\" cellspacing=\"0\">\n");
print("					<tr>\n");
print("						<td>\n");
if ($hasServices == 0) {
print("							<img src=\"../../perfStatResources/images/common/spacer.gif\" border=\"0\" width=\"9\" height=\"9\">\n");
} else {
my $formula44=$hostGroupID;my $formula45=$hostGroupMember;my $formula46=$hostGroupID;my $formula47=$hostGroupMember;my $formula48=$hostGroupID;my $formula49=$hostGroupMember;print("							<a id=\"x$formula44^$formula45\" href=\"javascript:Toggle('$formula46^$formula47');\"><img name=\"x$formula48^$formula49\" src=\"../../perfStatResources/images/navigation/icon_plusNavBar.gif\" border=\"0\"></a>\n");
}
print("						</td>\n");
print("						<td><img src=\"../../perfStatResources/images/navigation/icon_statusMonitor2.gif\" border=\"0\"></td>\n");
print("						<td nowrap>\n");
if ($hasServices == 0) {
my $formula50=$hostGroupMember;print("							$formula50\n");
} else {
my $formula51=$hostGroupID;my $formula52=$hostGroupMember;my $formula53=$hostGroupID;my $formula54=$hostGroupMember;my $formula55=$hostGroupMember;print("							<a target=\"content\" href=\"../content/level3/index.pl?hostGroupID=$formula51&hostName=$formula52\" onClick=\"Toggle('$formula53^$formula54');\">$formula55</a>\n");
}
print("						</td>\n");
print("					</tr>\n");
print("				</table>\n");
 if ($hasServices != 0) {
my $formula56=$hostGroupID;my $formula57=$hostGroupMember;print("				<div id=\"$formula56^$formula57\" style=\"display:none; margin-left:12px;\">\n");
my $serviceHashRefined = $hostDescHash->{'serviceHash'};
foreach my $serviceHashRefinedKey (sort(keys(%$serviceHashRefined))) {
my $serviceDescHash = $serviceHashRefined->{$serviceHashRefinedKey};
 if ($serviceDescHash->{'hasSubService'} != 1) {
print("				<table border=\"0\" cellpadding=\"2\" cellspacing=\"0\">\n");
print("					<tr>\n");
print("						<td><img src=\"../../perfStatResources/images/common/spacer.gif\" height=\"10\" width=\"9\" border=\"0\"></td>\n");
print("						<td><img src=\"../../perfStatResources/images/navigation/icon_statusMonitor3.gif\" border=\"0\"></td>\n");
my $formula58=$hostGroupID;my $formula59=$hostGroupMember;my $formula60=$serviceHashRefinedKey;my $formula61=$serviceHashRefinedKey;print("						<td><a target=\"content\" href=\"../content/level3/index.pl?hostGroupID=$formula58&hostName=$formula59&serviceName=$formula60\">$formula61</a></td>\n");
print("					</tr>\n");
print("				</table>\n");
 } else {
my $subServiceHash = $serviceDescHash->{'subServiceHash'};
my @list = sort(keys(%$subServiceHash));
print("				<table border=\"0\" cellpadding=\"2\" cellspacing=\"0\">\n");
print("					<tr>\n");
my $formula62=$hostGroupID;my $formula63=$hostGroupMember;my $formula64=$serviceHashRefinedKey;my $formula65=$hostGroupID;my $formula66=$hostGroupMember;my $formula67=$serviceHashRefinedKey;my $formula68=$hostGroupID;my $formula69=$hostGroupMember;my $formula70=$serviceHashRefinedKey;print("						<td><a id=\"x$formula62^$formula63^$formula64\" href=\"javascript:Toggle('$formula65^$formula66^$formula67');\"><img name=\"x$formula68^$formula69^$formula70\" src=\"../../perfStatResources/images/navigation/icon_plusNavBar.gif\" border=\"0\"></a></td>\n");
print("						<td><img src=\"../../perfStatResources/images/navigation/icon_statusMonitor3.gif\" border=\"0\"></td>\n");
my $formula71=$hostGroupID;my $formula72=$hostGroupMember;my $formula73=$serviceHashRefinedKey;my $formula74=$list[0];my $formula75=$hostGroupID;my $formula76=$hostGroupMember;my $formula77=$serviceHashRefinedKey;my $formula78=$serviceHashRefinedKey;print("						<td nowrap><a target=\"content\" href=\"../content/level3/index.pl?hostGroupID=$formula71&hostName=$formula72&serviceName=$formula73.$formula74\" onClick=\"Toggle('$formula75^$formula76^$formula77');\">$formula78</a></td>\n");
print("					</tr>\n");
print("				</table>\n");
my $formula79=$hostGroupID;my $formula80=$hostGroupMember;my $formula81=$serviceHashRefinedKey;print("				<div id=\"$formula79^$formula80^$formula81\" style=\"display:none; margin-left:12px;\">\n");
foreach my $subServiceHashKey (sort(keys(%$subServiceHash))) {
print("				<table border=\"0\" cellpadding=\"2\" cellspacing=\"0\">\n");
print("					<tr>\n");
print("						<td><img src=\"../../perfStatResources/images/common/spacer.gif\" height=\"10\" width=\"9\" border=\"0\"></td>\n");
print("						<td><img src=\"../../perfStatResources/images/navigation/icon_statusMonitor3.gif\" border=\"0\"></td>\n");
my $formula82=$hostGroupID;my $formula83=$hostGroupMember;my $formula84=$serviceHashRefinedKey;my $formula85=$subServiceHashKey;my $formula86=$subServiceHashKey;print("						<td><a href=\"../content/level3/index.pl?hostGroupID=$formula82&hostName=$formula83&serviceName=$formula84.$formula85\" target=\"content\">$formula86</a></td>\n");
print("					</tr>\n");
print("				</table>\n");
}
print("				</div>\n");
}
}
print("				</div>\n");
}
}
print("				</div>\n");
}
}
print("				</div>\n");
print("			</td>\n");
print("		</tr>\n");
print("		</table>\n");
print("	</body>\n");
print("</html>\n");
