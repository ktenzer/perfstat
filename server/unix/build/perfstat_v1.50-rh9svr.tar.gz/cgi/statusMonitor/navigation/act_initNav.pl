use strict;
package main;

# Login is perfstat admin
if ($sessionObj->param("userName") eq "perfstat") {
	####
	if (defined($request->param('adminName'))) {
		if ($request->param('adminName') ne $sessionObj->param("selectedAdmin")) {
			checkAdminName($request->param('adminName'));
			$sessionObj->param("selectedAdmin", $request->param('adminName'));
			$sessionObj->param("selectedUser", $request->param('adminName'));
		}
	}
	####
	if (defined($request->param('userName'))) {
		if ($request->param('userName') ne $sessionObj->param("selectedUser")) {
			checkUserName($sessionObj->param("selectedAdmin"), $request->param('userName'));
			$sessionObj->param("selectedUser", $request->param('userName'));
		}
	}

	#define list of admin
	$adminList = $userIndex;
	#define list of users
	$userList = $adminList->{$sessionObj->param("selectedAdmin")};

# Login is group admin
} elsif ($sessionObj->param("role") eq "admin") {
	###
	$sessionObj->param("selectedAdmin", $sessionObj->param("userName"));
	###
	if (defined($request->param('userName'))) {
		if ($request->param('userName') ne $sessionObj->param("selectedUser")) {
			checkUserName($sessionObj->param("selectedAdmin"), $request->param('userName'));
			$sessionObj->param("selectedUser", $request->param('userName'));
		}
	}
	#define list of users
	$userList = $userIndex->{$sessionObj->param("selectedAdmin")};

# Login is user
} else {
	$sessionObj->param("selectedAdmin", $sessionObj->param("creator"));
	$sessionObj->param("selectedUser", $sessionObj->param("userName"));
}

#define hash of all default hosts (ie, those owned by $adminName)
$allHostHash = {};
foreach my $hostName (keys(%$hostIndex)) {
	my $hostObject = $hostIndex->{$hostName};
	my $owner = $hostObject->getOwner();
	
	if ($owner eq $sessionObj->param("selectedAdmin")) {
		my $hostDescHash = {};
		my $serviceIndex = $hostObject->{'serviceIndex'};
		if (%$serviceIndex == 0) {
			$hostDescHash->{'hasServices'} = 0;
		} else {
			$hostDescHash->{'hasServices'} = 1;
			my $serviceHashRaw = {};
			makeServiceHashRaw($serviceHashRaw, $serviceIndex);
			my $serviceHashRefined = {};
			makeServiceHashRefined($serviceHashRaw, $serviceHashRefined);
			$hostDescHash->{'serviceHash'} = $serviceHashRefined;
		}
		$allHostHash->{$hostName} = $hostDescHash;
	}
}

#define hash of host Groups to list
my $hostGroupArray = $userIndex->{$sessionObj->param("selectedAdmin")}->{$sessionObj->param("selectedUser")}->{hostGroups};
my $hostGroupArrayLen = @$hostGroupArray;

#create hostGroupHash
$hostGroupHash = {};
for (my $count1 = 0; $count1 < $hostGroupArrayLen; $count1++) {
	my $hostGroupObject = $hostGroupArray->[$count1];
	my $groupName = $hostGroupObject->getName();
	
	#find hostGroup member array 
	my $hostGroupMemberArray = $hostGroupObject->{memberArray};
	my $hostGroupDescHash = {};
	if (@$hostGroupMemberArray == 0) {
		$hostGroupDescHash->{'hasHosts'} = 0;
		$hostGroupDescHash->{'hostGroupID'} = $count1;
		$hostGroupDescHash->{'hostGroupMemberHash'} = {};
	} else {
		$hostGroupDescHash->{'hasHosts'} = 1;
		$hostGroupDescHash->{'hostGroupID'} = $count1;
		$hostGroupDescHash->{'hostGroupMemberHash'} = {};
		foreach my $hostName (@$hostGroupMemberArray) {
			my $hostObject = $hostIndex->{$hostName};
			my $serviceIndex = $hostObject->{'serviceIndex'};
			my $hostDescHash = {};
			$hostDescHash->{'hasServices'} = 0;
			$hostDescHash->{'serviceHash'} = {};
			if (%$serviceIndex != 0) {
				$hostDescHash->{'hasServices'} = 1;
				my $serviceHashRaw = {};
				makeServiceHashRaw($serviceHashRaw, $serviceIndex);
				my $serviceHashRefined = {};
				makeServiceHashRefined($serviceHashRaw, $serviceHashRefined);
				$hostDescHash->{'serviceHash'} = $serviceHashRefined;
			}
			$hostGroupDescHash->{'hostGroupMemberHash'}->{$hostName} = $hostDescHash;
		}
	}
	$hostGroupHash->{$groupName} = $hostGroupDescHash;
}

###############################################################FUNCTIONS
#----------------------------------------------------------------------------------------------------- makeServiceHashRaw
sub makeServiceHashRaw {
	my ($rawHash, $serviceIndex) = @_;
	foreach my $service (keys(%$serviceIndex)) {
		my $serviceObject = $serviceIndex->{$service};
		my $serviceName = $serviceObject->getServiceName();
		my $arrayLength = $serviceObject->getMetricArrayLength();

		for (my $counter=0; $counter < $arrayLength; $counter++) {
			my $metricObject = $serviceObject->{metricArray}->[$counter];
			my $hasEvents = $metricObject->getHasEvents();
			if ($hasEvents == 1) {
				$rawHash->{$service} = "";
			}
		}
	}
}

#---------------------------------------------------------------------------------------------------- makeServiceHashRefined
sub makeServiceHashRefined {
	my ($rawHash, $refinedHash) = @_;
	my $previousServicePrefix = "";

	foreach my $fullServiceName (sort(keys(%$rawHash))) {
		my $prefix = $fullServiceName;
		$prefix =~ s/\..*//;
		if ($prefix ne $previousServicePrefix) {
			# new service or subservice
			if ($fullServiceName !~ m/\S+\.\S+/) {
				# if not subservice
				my $tempHash = {};
				$tempHash->{'hasSubService'} = 0;
				$refinedHash->{$prefix} = $tempHash;
			} else {
				# if is first occurrence of subservice
				my $tempHash = {};
				my $suffix = $fullServiceName;
				$suffix =~ s/.*\.//;
				$tempHash->{'hasSubService'} = 1;
				$tempHash->{'subServiceHash'} = {};
				$tempHash->{'subServiceHash'}->{$suffix} = $rawHash->{$fullServiceName};
				$refinedHash->{$prefix} = $tempHash;
			}
			$previousServicePrefix = $prefix;
		} else {
			# next occurrence of previously entered subservice in newHash
			my $suffix = $fullServiceName;
			$suffix =~ s/^\w+\.//;
			$refinedHash->{$prefix}->{'subServiceHash'}->{$suffix} =  $rawHash->{$fullServiceName};
		}
	}
}

1;