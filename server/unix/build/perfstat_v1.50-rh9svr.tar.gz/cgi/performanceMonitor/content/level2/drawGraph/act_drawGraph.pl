use strict;
package main;

my @LINE=();
my @DEF=();
my $width=();
my $height=();

my $RRD="$perfhome/rrd/$hostName/$hostName.$serviceName.rrd";
#my $imageType='png';
# Convert period into seconds
if ($period =~ m/hourly/) {
	$period="end-1d";
} elsif ($period =~ m/daily/) {
	$period="end-1w";
} elsif ($period =~ m/weekly/) {
	$period="end-1m";
} elsif ($period =~ m/monthly/) {
	$period="end-1y";
}

# Get options
my $title=$hostIndex->{$hostName}->{serviceIndex}->{$serviceName}->{graphHash}->{$graphName}->getTitle();
my $title="$title ($serviceName) on $hostName";
my $comment=$hostIndex->{$hostName}->{serviceIndex}->{$serviceName}->{graphHash}->{$graphName}->getComment();
#$imageFormat=$hostIndex->{$hostName}->{serviceIndex}->{$serviceName}->{graphHash}->{$graphName}->getImageFormat();
my $imageFormat="PNG";

# Get graph width/height if they aren't already set
if ($graphWidth eq "") {
	$width=$hostIndex->{$hostName}->{serviceIndex}->{$serviceName}->{graphHash}->{$graphName}->getWidth();
} else {
	$width=$graphWidth;
}
if ($graphHeight eq "") {
	$height=$hostIndex->{$hostName}->{serviceIndex}->{$serviceName}->{graphHash}->{$graphName}->getHeight();
} else {
	$height=$graphHeight;
}

my $verticalLabel=$hostIndex->{$hostName}->{serviceIndex}->{$serviceName}->{graphHash}->{$graphName}->getVerticalLabel();
my $upperLimit=$hostIndex->{$hostName}->{serviceIndex}->{$serviceName}->{graphHash}->{$graphName}->getUpperLimit();
my $lowerLimit=$hostIndex->{$hostName}->{serviceIndex}->{$serviceName}->{graphHash}->{$graphName}->getLowerLimit();
my $rigid=$hostIndex->{$hostName}->{serviceIndex}->{$serviceName}->{graphHash}->{$graphName}->getRigid();
my $base=$hostIndex->{$hostName}->{serviceIndex}->{$serviceName}->{graphHash}->{$graphName}->getBase();
my $unitsExponent=$hostIndex->{$hostName}->{serviceIndex}->{$serviceName}->{graphHash}->{$graphName}->getUnitsExponent();
my $noMinorGrids=$hostIndex->{$hostName}->{serviceIndex}->{$serviceName}->{graphHash}->{$graphName}->getNoMinorGrids();
my $stepValue=$hostIndex->{$hostName}->{serviceIndex}->{$serviceName}->{graphHash}->{$graphName}->getStepValue();
my $gprintFormat=$hostIndex->{$hostName}->{serviceIndex}->{$serviceName}->{graphHash}->{$graphName}->getGprintFormat();

# Build Options Array
my @optionsArray = ();

# Add required options
push(@optionsArray,"--start=$period");
push(@optionsArray,"--imgformat=$imageFormat");
push(@optionsArray,"--width=$width");
push(@optionsArray,"--height=$height");
push(@optionsArray,"--title=$title");
push(@optionsArray,"--vertical-label=$verticalLabel");
push(@optionsArray,"--base=$base");

# Add optional options
if ($upperLimit ne "") {
        push(@optionsArray,"--upper-limit=$upperLimit");
}

if ($lowerLimit ne "") {
        push(@optionsArray,"--lower-limit=$lowerLimit");
}

if ($unitsExponent ne "") {
        push(@optionsArray,"--units-exponent=$unitsExponent");
}

if ($rigid ne "") {
        push(@optionsArray,"--rigid");
}

if ($noMinorGrids ne "") {
        push(@optionsArray,"--no-minor");
}

if ($stepValue ne "") {
        push(@optionsArray,"--step=$stepValue");
}

# Get definition and line for every metric
my $graphObject=$hostIndex->{$hostName}->{serviceIndex}->{$serviceName}->{graphHash}->{$graphName};
push(@LINE,"COMMENT:\\n");
foreach my $metric (@{$graphObject->{metricArray}}) {
        my $metricName = $metric->getName();
        my $color = $metric->getColor();
        my $lineType = $metric->getLineType();

        push(@DEF,"DEF:$metricName=$RRD:$metricName:AVERAGE");
        push(@LINE,"$lineType:$metricName$color:$metricName");

        my $i="0";
        my $data_ref=\@{$metric->{gprintArray}};
        foreach my $line (@{$metric->{gprintArray}}) {
                my $gprint="GPRINT:$metricName:$line: $line  \\:$gprintFormat";

                if ($i eq $#$data_ref) {
                        push(@LINE,$gprint . "\\n");
                } else {
                        push(@LINE,$gprint);
                }
                $i++;
        }
}

###DEBUG Print###
#print "RRDs::graph( '-', @optionsArray, @DEF, @LINE)";
#print("Graph Output: @optionsArray @DEF @LINE");

print header( -type => "image/png", -expires => '0',  -pragma=>'no-cache', -cache-control=>'no-cache, no-store, must-revalidate');

###Print to a File###
#RRDs::graph( "$perfhome/cgi/graphs/$graphName.$period.png", @optionsArray, @DEF, @LINE);

###Print to STDOUT###
RRDs::graph( '-', @optionsArray, @DEF, @LINE);
my $err1 = RRDs::error;
if ( $err1 ) {
	print ("RRD ERROR: $err1");
}

1;
