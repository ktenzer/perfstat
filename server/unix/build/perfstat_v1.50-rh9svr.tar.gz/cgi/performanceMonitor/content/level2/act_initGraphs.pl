use strict;
package main;

checkAndSetHostGroupID(0);
checkAndSetHostName(0);

# CURRENT graphSize, graphLayout
if (!defined($request->param("graphSize"))) {
	$graphSize = "medium";
} else {
	$graphSize = $request->param("graphSize");
}
if ($graphSize =~ m/small/) {
	$graphHeight = "65";
	$graphWidth = "275";
} elsif ($graphSize =~ /medium/) {
	$graphHeight = "100";
	$graphWidth = "400";
} elsif ($graphSize =~ /large/) {
	$graphHeight = "180";
	$graphWidth = "675";
}

if (!defined($request->param("graphLayout"))) {
	$graphLayout = "1";
} else {
	$graphLayout = $request->param("graphLayout");
}

$graphHolderArray = [];
my $serializedGraphHolderArray =  $request->param('graphHolderArray');
$graphHolderArray = deserializeGraphHolderArray( $serializedGraphHolderArray);

sub deserializeGraphHolderArray {
	my ($serializedGraphHolderArray) = @_;
	$serializedGraphHolderArray = trim($serializedGraphHolderArray);
	my $graphHolderArray = [];
	while ( $serializedGraphHolderArray  =~  /([^;]+);/g) {
		my $serializedGraphArray = $1;
		my $graphArray = [];
		while ( $serializedGraphArray =~ /([^\^]+)\^/g) {
			push(@$graphArray, $1);
		}
		push (@$graphHolderArray, $graphArray);
	}
	return $graphHolderArray;
}