#!/usr/bin/perl -w
use strict;
BEGIN
{
	unshift(@INC, "../../..");
	require("app_globals.pl");
}

use vars qw($action $graphHolderArray $graphHeight $graphWidth  $graphSize $graphLayout);

$request = new CGI;
$action = undef;
$action = $request->param('action');

if ($doParse) {PerfStatCGI::Parser->html2Perl("dsp_graphs.html");}
require("act_initGraphs.pl");
require("dsp_graphs.pl");