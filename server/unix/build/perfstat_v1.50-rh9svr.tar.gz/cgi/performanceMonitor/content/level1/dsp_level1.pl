use strict;
package main;
print("<html>\n");
print("	<head>\n");
print("		<meta http-equiv=\"content-type\" content=\"text/html;charset=iso-8859-1\">\n");
print("		<title>PerfStat Tool: Status And Performance Monitoring</title>\n");
print("		<link rel=\"stylesheet\" type=\"text/css\" href=\"../../../perfStatResources/styleSheets/contentFrame.css\" media=\"screen\">\n");
print("		<link rel=\"stylesheet\" type=\"text/css\" href=\"../../../perfStatResources/styleSheets/forms.css\" media=\"screen\">\n");
print("		<script language=\"javascript\" src=\"../../../perfStatResources/javaScripts/contentFrame.js\"></script>\n");
print("		<script language=\"javascript\" src=\"../../../perfStatResources/javaScripts/pm.level1.js\"></script>\n");
print("	</head>\n");

print("	<body onload=\"drawGraphTable();\">\n");
print("		<table cellpadding=\"2\" cellspacing=\"1\" border=\"0\" class=\"table1\">\n");
print("			<tr>\n");
print("				<th nowrap=\"nowrap\" valign=\"middle\" align=\"left\">Host Group</th>\n");
print("				<th nowrap=\"nowrap\" valign=\"middle\" align=\"left\">Host Name</th>\n");
print("			</tr>\n");
print("			<tr>\n");
print("				<td class=\"liteGray\" align=\"left\" valign=\"middle\">\n");
print("					<form action=\"index.pl\" method=\"get\">\n");
my $formula0=$graphSize;print("					<input type=\"hidden\" name=\"graphSize\" value=\"$formula0\">\n");
my $formula1=$graphLayout;print("					<input type=\"hidden\" name=\"graphLayout\" value=\"$formula1\">\n");
print("					<select name=\"hostGroupID\" size=\"1\" onChange=\"submit();\">\n");
my $formula2=$sessionObj->param("hostGroupID") eq "allHost" ? "selected" : "";;print("						<option value=\"allHosts\" $formula2>All Hosts</option>\n");
foreach my $hostGroupName (sort(keys(%$hostGroupHash))) {
my $formula3=$hostGroupHash->{$hostGroupName};my $formula4=$sessionObj->param("hostGroupID") eq $hostGroupHash->{$hostGroupName} ? "selected" : "";;my $formula5=$hostGroupName;print("						<option value=\"$formula3\" $formula4>$formula5</option>					\n");
}
print("					</select>\n");
print("				</td>\n");
print("				</form>\n");
print("				<td class=\"liteGray\" align=\"center\" valign=\"middle\">\n");
print("					<form action=\"index.pl\" method=\"get\">\n");
my $formula6=$graphSize;print("					<input type=\"hidden\" name=\"graphSize\" value=\"$formula6\">\n");
my $formula7=$graphLayout;print("					<input type=\"hidden\" name=\"graphLayout\" value=\"$formula7\">\n");
my $formula8=$sessionObj->param("hostGroupID");print("					<input type=\"hidden\" name=\"hostGroupID\" value=\"$formula8\">\n");
print("					<select name=\"hostName\" size=\"1\" onChange=\"submit();\">\n");
foreach my $hostName (@$hostArray) {
my $formula9=$hostName;my $formula10=$sessionObj->param("hostName") eq $hostName ? "selected" : "";;my $formula11=$hostName;print("						<option value=\"$formula9\" $formula10>$formula11</option>					\n");
}
print("					</select>\n");
print("				</td>\n");
print("				</form>\n");
print("			</tr>\n");
print("		</table>\n");
print("		<table cellpadding=\"2\" cellspacing=\"1\" border=\"0\" class=\"table1\" width=\"100%\">\n");
print("				<tr>\n");
print("				<td class=\"tdTop\" nowrap=\"nowrap\" valign=\"middle\" align=\"left\"><span class=\"tableHeader\">Select Graph(s)</span></td>\n");
print("				</tr>\n");
print("			<tr>\n");
print("				<td class=\"darkGray\" align=\"left\" valign=\"top\">\n");
print("					<table class=\"smallJSLinkTable\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\n");
print("						<tr>\n");
print("							<td nowrap><a href=\"javascript:openAll();\">open all</a></td>\n");
print("							<td nowrap><img src=\"../../../perfStatResources/images/common/spacer.gif\" height=\"6\" width=\"6\" border=\"0\"></td>\n");
print("							<td nowrap><a href=\"javascript:closeAll();\">close all</a></td>\n");
print("							<td nowrap><img src=\"../../../perfStatResources/images/common/spacer.gif\" height=\"5\" width=\"6\" border=\"0\"></td>\n");
print("							<td nowrap><a href=\"javascript:selectAll();\">select all</a></td>\n");
print("							<td nowrap><img src=\"../../../perfStatResources/images/common/spacer.gif\" height=\"5\" width=\"6\" border=\"0\"></td>\n");
print("							<td nowrap><a href=\"javascript:removeAll();\">remove all</a></td>\n");
print("						</tr>\n");
print("					</table>\n");
print("				</td>\n");
print("			</tr>\n");
print("			<tr>\n");
print("					<td class=\"darkGray\" align=\"left\" valign=\"top\">\n");
print("					<table border=\"0\" cellpadding=\"2\" cellspacing=\"2\">\n");
print("						<tr>\n");
foreach my $serviceName (sort(keys(%$serviceHashRefined))) {
my $descriptorHash = $serviceHashRefined->{$serviceName};
if ( $descriptorHash->{'hasSubService'} == 0) {
my $graphHash = $descriptorHash->{'graphHash'};
print("							<td width=\"40\" valign=\"top\" align=\"left\">\n");
my $formula12=$serviceName;print("								<div id=\"$formula12-off\" style=\"display:block;\">\n");
print("									<table cellpadding=\"1\" cellspacing=\"1\" border=\"0\" class=\"table2\">\n");
print("										<tr>\n");
my $formula13=$serviceName;my $formula14=$serviceName;my $formula15=$serviceName;my $formula16=$serviceName;print("											<th nowrap=\"nowrap\" valign=\"middle\" align=\"left\"><a href=\"javascript:toggle('$formula13-off', '$formula14-on');\"><img id=\"x$formula15-off\" src=\"../../../perfStatResources/images/navigation/icon_plusNavBar.gif\" width=\"9\" height=\"9\" border=\"0\"></a>&nbsp;$formula16</th>\n");
print("										</tr>\n");
print("									</table>\n");
print("								</div>\n");
my $formula17=$serviceName;print("								<div id=\"$formula17-on\" style=\"display:none;\">\n");
print("									<table cellpadding=\"1\" cellspacing=\"1\" border=\"0\" class=\"table2\">\n");
print("										<tr>\n");
my $formula18=$serviceName;my $formula19=$serviceName;my $formula20=$serviceName;my $formula21=$serviceName;print("											<th nowrap=\"nowrap\" valign=\"middle\" align=\"left\"><a href=\"javascript:toggle('$formula18-off', '$formula19-on');\"><img id=\"x$formula20-on\" src=\"../../../perfStatResources/images/navigation/icon_minusNavBar.gif\" width=\"9\" height=\"9\" border=\"0\"></a>&nbsp;$formula21</th>\n");
print("										</tr>\n");
print("										<tr>\n");
print("											<td valign=\"top\">\n");
print("												<table border=\"0\" cellpadding=\"1\" cellspacing=\"1\">\n");
 foreach my $graphName (keys(%$graphHash)) {
print("													<tr>\n");
my $formula22=$sessionObj->param("hostName");my $formula23=$serviceName;my $formula24=$graphName;my $formula25=$sessionObj->param("hostName");my $formula26=$serviceName;my $formula27=$graphName;my $formula28=$graphName;print("														<td nowrap style=\"text-align: left;\" valign=\"middle\" align=\"left\"><a class=\"insertHREF\" ID=\"$formula22^$formula23^$formula24\" href=\"javascript: insertGraph('$formula25', '$formula26', '$formula27');\">$formula28</a></td>\n");
print("													</tr>\n");
 }
print("												</table>\n");
print("											</td>\n");
print("										</tr>\n");
print("									</table>\n");
print("								</div>\n");
print("							</td>\n");
 } else {
 my $subServiceHash = $descriptorHash->{'subServiceHash'};
print("							<td width=\"40\" valign=\"top\" align=\"left\">\n");
my $formula29=$serviceName;print("								<div id=\"$formula29-off\" style=\"display:block;\">\n");
print("									<table cellpadding=\"1\" cellspacing=\"1\" border=\"0\" class=\"table2\">\n");
print("										<tr>\n");
my $formula30=$serviceName;my $formula31=$serviceName;my $formula32=$serviceName;my $formula33=$serviceName;print("											<th nowrap=\"nowrap\" valign=\"middle\" align=\"left\"><a href=\"javascript:toggle('$formula30-off', '$formula31-on');\"><img id=\"x$formula32-off\" src=\"../../../perfStatResources/images/navigation/icon_plusNavBar.gif\" width=\"9\" height=\"9\" border=\"0\"></a>&nbsp;$formula33</th>\n");
print("										</tr>\n");
print("									</table>\n");
print("								</div>\n");
my $formula34=$serviceName;print("								<div id=\"$formula34-on\" style=\"display:none;\">\n");
print("									<table cellpadding=\"1\" cellspacing=\"1\" border=\"0\" class=\"table2\">\n");
print("										<tr>\n");
my $formula35=$serviceName;my $formula36=$serviceName;my $formula37=$serviceName;my $formula38=$serviceName;print("											<th nowrap=\"nowrap\" valign=\"middle\" align=\"left\"><a href=\"javascript:toggle('$formula35-off', '$formula36-on');\"><img id=\"x$formula37-on\" src=\"../../../perfStatResources/images/navigation/icon_minusNavBar.gif\" width=\"9\" height=\"9\" border=\"0\"></a>&nbsp;$formula38</th>\n");
print("										</tr>\n");
foreach my $subServiceName (keys(%$subServiceHash)) {
 my $graphHash = $subServiceHash->{$subServiceName};
print("										<tr>\n");
print("											<td style=\"text-align: left;\">\n");
my $formula39=$serviceName;my $formula40=$subServiceName;print("												<div id=\"$formula39-$formula40-off\" style=\"display:block;\">\n");
print("												<table border=\"0\" cellpadding=\"1\" cellspacing=\"1\">\n");
print("													<tr>\n");
my $formula41=$serviceName;my $formula42=$subServiceName;my $formula43=$serviceName;my $formula44=$subServiceName;my $formula45=$serviceName;my $formula46=$subServiceName;print("														<td><a href=\"javascript:toggle('$formula41-$formula42-off', '$formula43-$formula44-on');\"><img id=\"x$formula45-$formula46-off\" src=\"../../../perfStatResources/images/navigation/icon_plusNavBar.gif\" width=\"9\" height=\"9\" border=\"0\"></a></td>\n");
my $formula47=$subServiceName;print("														<td nowrap>$formula47</td>\n");
print("													</tr>\n");
print("												</table>\n");
print("												</div>\n");
my $formula48=$serviceName;my $formula49=$subServiceName;print("												<div id=\"$formula48-$formula49-on\" style=\"display:none;\">\n");
print("												<table border=\"0\" cellpadding=\"1\" cellspacing=\"1\">\n");
print("													<tr>\n");
my $formula50=$serviceName;my $formula51=$subServiceName;my $formula52=$serviceName;my $formula53=$subServiceName;my $formula54=$serviceName;my $formula55=$subServiceName;print("														<td><a href=\"javascript:toggle('$formula50-$formula51-off', '$formula52-$formula53-on');\"><img id=\"x$formula54-$formula55-on\" src=\"../../../perfStatResources/images/navigation/icon_minusNavBar.gif\" width=\"9\" height=\"9\" border=\"0\"></a></td>\n");
my $formula56=$subServiceName;print("														<td nowrap>$formula56</td>\n");
print("													</tr>\n");
print("												</table>\n");
 foreach my $graphName (keys(%$graphHash)) {
print("												<table cellpadding=\"1\" cellspacing=\"1\" border=\"0\">\n");
print("													<tr>\n");
print("														<td><img src=\"../../../perfStatResources/images/common/spacer.gif\" width=\"12\" height=\"9\" border=\"0\"></td>\n");
my $formula57=$sessionObj->param("hostName");my $formula58=$serviceName;my $formula59=$subServiceName;my $formula60=$graphName;my $formula61=$sessionObj->param("hostName");my $formula62=$serviceName;my $formula63=$subServiceName;my $formula64=$graphName;my $formula65=$graphName;print("														<td style=\"text-align: left;\" nowrap><a class=\"insertHREF\" ID=\"$formula57^$formula58.$formula59^$formula60\" href=\"javascript:insertGraph('$formula61', '$formula62.$formula63', '$formula64');\">$formula65</a></td>\n");
print("													</tr>\n");
print("												</table>\n");
}
print("												</div>\n");
print("											</td>\n");
print("										</tr>\n");
}
print("									</table>\n");
print("								</div>\n");
print("							</td>\n");
 }
 }
print("						</tr>\n");
print("					</table>\n");
print("				</td>\n");
print("				</tr>\n");
print("			</table>\n");
print("		<table cellpadding=\"2\" cellspacing=\"1\" border=\"0\" class=\"table1\" width=\"100%\">\n");
print("			<tr>\n");
print("				<td class=\"tdTop\" nowrap=\"nowrap\" valign=\"middle\" align=\"left\">Select Interval(s)</td>\n");
print("			</tr>\n");
print("			<tr>\n");
print("				<td class=\"darkGray\" align=\"left\" valign=\"top\">\n");
print("					<table class=\"table3\" id=\"graphTable\" border=\"0\" cellpadding=\"2\" cellspacing=\"2\">\n");
print("						<thead>\n");
print("							<tr>\n");
print("								<th valign=\"middle\" align=\"left\"></th>\n");
print("								<th valign=\"middle\" align=\"left\">Host</th>\n");
print("								<th valign=\"middle\" align=\"left\">Service</th>\n");
print("								<th valign=\"middle\" align=\"left\">Graph</th>\n");
print("								<th valign=\"middle\" align=\"center\">Hourly</th>\n");
print("								<th valign=\"middle\" align=\"center\">Daily</th>\n");
print("								<th valign=\"middle\" align=\"center\">Weekly</th>\n");
print("								<th valign=\"middle\" align=\"center\">Monthly</th>\n");
print("							</tr>\n");
print("							<tr>\n");
print("								<th colspan=\"4\"></th>\n");
print("								<th valign=\"middle\" align=\"center\"><a href=\"javascript:selectColumn('hourly');\">+</a> | <a href=\"javascript:deSelectColumn('hourly')\">-</a></th>\n");
print("								<th valign=\"middle\" align=\"center\"><a href=\"javascript:selectColumn('daily');\">+</a> | <a href=\"javascript:deSelectColumn('daily')\">-</a></th>\n");
print("								<th valign=\"middle\" align=\"center\"><a href=\"javascript:selectColumn('weekly');\">+</a> | <a href=\"javascript:deSelectColumn('weekly')\">-</a></th>\n");
print("								<th valign=\"middle\" align=\"center\"><a href=\"javascript:selectColumn('monthly');\">+</a> | <a href=\"javascript:deSelectColumn('monthly')\">-</a></th>\n");
print("							</tr>\n");
print("						</thead>\n");
print("						<tbody>\n");
print("						</tbody>\n");
print("					</table>\n");
print("				</td>\n");
print("			</tr>\n");
print("		</table>\n");
print("		<table cellpadding=\"2\" cellspacing=\"1\" border=\"0\" class=\"table1\" width=\"100%\">\n");
print("			<tr>\n");
print("				<td class=\"tdTop\" nowrap=\"nowrap\" valign=\"middle\" align=\"left\">Create Graph(s)</td>\n");
print("			</tr>\n");
print("			<tr>\n");
print("				<td class=\"darkGray\" align=\"left\" valign=\"top\">\n");
print("					<form name=\"outputGraphs\" action=\"../level2/index.pl\" method=\"get\">\n");
my $formula66=$sessionObj->param("hostGroupID");print("					<input type=\"hidden\" name=\"hostGroupID\" value=\"$formula66\">\n");
my $formula67=$sessionObj->param("hostName");print("					<input type=\"hidden\" name=\"hostName\" value=\"$formula67\">\n");
print("					<input type=\"hidden\" name=\"graphHolderArray\" value=\"\">\n");
print("					<table>\n");
print("						<tr>\n");
print("							<td><span class=\"table1Text1\">Graph Size:</span></td>\n");
print("							<td>\n");
print("								<select name=\"graphSize\" size=\"1\">\n");
my $formula68=$graphSize eq "small" ? "selected" : "";;print("									<option value=\"small\" $formula68>Small</option>\n");
my $formula69=$graphSize eq "medium" ? "selected" : "";;print("									<option value=\"medium\" $formula69>Medium</option>\n");
my $formula70=$graphSize eq "large" ? "selected" : "";;print("									<option value=\"large\" $formula70>Large</option>\n");
print("								</select>\n");
print("							</td>\n");
print("							<td><img src=\"../../../perfStatResources/images/common/spacer.gif\" height=\"6\" width=\"4\" border=\"0\"></td>\n");
print("							<td><span class=\"table1Text1\">Layout:</span></td>\n");
print("							<td>\n");
print("								<select name=\"graphLayout\" size=\"1\">\n");
my $formula71=$graphLayout eq "1" ? "selected" : "";;print("									<option value=\"1\" $formula71>1 Column</option>\n");
my $formula72=$graphLayout eq "2" ? "selected" : "";;print("									<option value=\"2\" $formula72>2 Column</option>\n");
my $formula73=$graphLayout eq "3" ? "selected" : "";;print("									<option value=\"3\" $formula73>3 Column</option>\n");
my $formula74=$graphLayout eq "4" ? "selected" : "";;print("									<option value=\"4\" $formula74>4 Column</option>\n");
print("								</select>\n");
print("							</td>\n");
print("							<td><img src=\"../../../perfStatResources/images/common/spacer.gif\" height=\"6\" width=\"4\" border=\"0\"></td>\n");
print("							<td><input class=\"liteButton\" type=\"button\" value=\"Create\" onClick=\"displayGraphs();\"></td>\n");
print("						</tr>\n");
print("					</table>\n");
print("				</td>\n");
print("				</form>\n");
print("			</tr>\n");
print("		</table>\n");
print("	</body>\n");
print("</html>\n");
