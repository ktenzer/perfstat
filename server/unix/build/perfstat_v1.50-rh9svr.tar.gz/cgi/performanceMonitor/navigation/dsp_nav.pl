use strict;
package main;
print("<html>\n");
print("	<head>\n");
print("		<meta http-equiv=\"content-type\" content=\"text/html;charset=iso-8859-1\">\n");
print("		<title>PerfStat Tool: Perfomance Monitoring & Status Notification</title>\n");
print("		<link type=\"text/css\" rel=\"stylesheet\" href=\"../../perfStatResources/styleSheets/navigationFrame.css\">\n");
print("		<script language=\"javascript\" src=\"../../perfStatResources/javaScripts/navigationFrame.js\"></script>\n");
print("		<script language=\"javascript\" src=\"../../perfStatResources/javaScripts/pm.nav.js\"></script>\n");
print("	</head>\n");
print("	<body onLoad=\"onBodyLoad('performance');\">\n");
 if ($sessionObj->param("userName") eq "perfstat" || $sessionObj->param("role") eq "admin") {
print("		<table cellpadding=\"2\" cellspacing=\"1\" border=\"0\" class=\"table1\" width=\"100%\">\n");
 if ($sessionObj->param("userName") eq "perfstat") {
print("			<tr>\n");
print("				<form action=\"index.pl\" method=\"get\">\n");
print("				<td nowrap=\"nowrap\" valign=\"middle\" align=\"right\"><span class=\"table1Text1\">Admin:</span></td>\n");
print("				<td nowrap=\"nowrap\" valign=\"middle\" align=\"left\">\n");
print("					<select name=\"adminName\" size=\"1\" onChange=\"submit();\">\n");
 foreach my $adminNameTemp (sort (keys(%$adminList))) {
my $formula0=$adminNameTemp;my $formula1=$adminNameTemp eq $sessionObj->param("selectedAdmin") ? "selected" : "";;my $formula2=$adminNameTemp;print("						<option value=\"$formula0\" $formula1>$formula2</option>\n");
 }
print("					</select>\n");
print("				</td>\n");
print("				</form>\n");
print("			</tr>\n");
}
 if ($sessionObj->param("role") eq "admin") {
print("			<tr>\n");
print("				<form action=\"index.pl\" method=\"get\">\n");
my $formula3=$sessionObj->param("selectedAdmin");print("				<input type=\"hidden\" name=\"adminName\" value=\"$formula3\">\n");
print("				<td nowrap=\"nowrap\" valign=\"middle\" align=\"right\"><span class=\"table1Text1\">User:</span></td>\n");
print("				<td nowrap=\"nowrap\" valign=\"middle\" align=\"left\">\n");
print("					<select name=\"userName\" size=\"1\" onChange=\"submit();\">\n");
 foreach my $userNameTemp (sort (keys(%$userList))) {
my $formula4=$userNameTemp;my $formula5=$userNameTemp eq $sessionObj->param("selectedUser")  ? "selected" : "";;my $formula6=$userNameTemp;print("						<option value=\"$formula4\" $formula5>$formula6</option>\n");
 }
print("					</select>\n");
print("				</td>\n");
print("				</form>\n");
print("			</tr>\n");
}
print("		</table>\n");
}
print("	<table border=\"0\" align=\"center\" cellpadding=\"3\" cellspacing=\"1\" class=\"table1\" width=\"100%\">\n");
print("		<tr> \n");
print("			<td height=\"25\" class=\"header\">Performance Monitor</td>\n");
print("		</tr>\n");
print("		<tr> \n");
print("			<td height=\"25\" class=\"subheader\">\n");
print("				<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" class=\"table2\" align=\"center\">\n");
print("					<tr>\n");
print("						<td nowrap><a href=\"javascript:openAll();\">open all</a></td>\n");
print("						<td nowrap><img src=\"../../perfStatResources/images/common/spacer.gif\" height=\"6\" width=\"10\" border=\"0\"></td>\n");
print("						<td nowrap><a href=\"javascript:closeAll();\">close all</a></td>\n");
print("					</tr>\n");
print("				</table>\n");
print("			</td>\n");
print("		</tr>\n");
print("		<tr>\n");
print("			<td align=\"left\" valign=\"top\">\n");
print("				<table border=\"0\" cellpadding=\"2\" cellspacing=\"0\">\n");
print("					<tr>\n");
print("						<td><img src=\"../../perfStatResources/images/navigation/icon_statusMonitor2.gif\" border=\"0\"></td>\n");
print("						<td nowrap><a href=\"../content/level1/index.pl?hostGroupID=allHosts\" target=\"content\">Performance Home</a></td>\n");
print("					</tr>\n");
print("				</table>\n");
print("			</td>\n");
print("		</tr>\n");
print("			<tr>\n");
print("			<td align=\"left\" valign=\"top\">\n");
print("				<div id=\"navContainer\" style=\"margin-left:5px\">\n");
print("				<table border=\"0\" cellpadding=\"2\" cellspacing=\"0\">\n");
print("					<tr>\n");
print("						<td>\n");
 if (%$allHostHash == 0) {
print("							<img src=\"../../perfStatResources/images/common/spacer.gif\" border=\"0\" width=\"9\" height=\"9\">\n");
 } else {
print("							<a id=\"xallHosts\" href=\"javascript:Toggle('allHosts');\"><img name=\"xallHosts\" src=\"../../perfStatResources/images/navigation/icon_plusNavBar.gif\" border=\"0\" width=\"9\" height=\"9\"></a>\n");
}
print("						</td>\n");
print("						<td><img src=\"../../perfStatResources/images/navigation/icon_statusMonitor1.gif\" border=\"0\"></td>\n");
print("						<td>\n");
 if (%$allHostHash == 0) {
print("								All Hosts\n");
 } else {
print("								<a id=\"xallHosts\" href=\"javascript:Toggle('allHosts');\">All Hosts</a>\n");
 }
print("						</td>\n");
print("					</tr>\n");
print("				</table>\n");
 if (%$allHostHash != 0) {
print("				<div id=\"allHosts\" style=\"display:none; margin-left:1em;\">\n");
 foreach my $allHostMember (sort(keys(%$allHostHash))) {
 my $hostDescHash = $allHostHash->{$allHostMember};
 my $hasGraphs = $hostDescHash->{'hasGraphs'};
print("				<table border=\"0\" cellpadding=\"2\" cellspacing=\"0\">\n");
print("					<tr>\n");
print("						<td>\n");
 if ($hasGraphs == 0) {
print("								<img src=\"../../perfStatResources/images/common/spacer.gif\" border=\"0\" width=\"9\" height=\"9\">\n");
} else {
my $formula7=$allHostMember;my $formula8=$allHostMember;my $formula9=$allHostMember;print("								<a id=\"xallHosts^$formula7\" href=\"javascript:Toggle('allHosts^$formula8');\"><img name=\"xallHosts^$formula9\" src=\"../../perfStatResources/images/navigation/icon_plusNavBar.gif\" border=\"0\"></a>\n");
}
print("						</td>\n");
print("						<td><img src=\"../../perfStatResources/images/navigation/icon_statusMonitor2.gif\" border=\"0\"></td>\n");
print("						<td nowrap>\n");
 if ($hasGraphs == 0) {
my $formula10=$allHostMember;print("							$formula10\n");
} else {
my $formula11=$allHostMember;my $formula12=$allHostMember;my $formula13=$allHostMember;print("							<a id=\"xallHosts^$formula11\" href=\"javascript:Toggle('allHosts^$formula12');\">$formula13</a>\n");
}
print("						</td>\n");
print("					</tr>\n");
print("				</table>\n");
 if ($hasGraphs != 0) {
my $formula14=$allHostMember;print("				<div id=\"allHosts^$formula14\" style=\"display:none; margin-left:12px\">\n");
my $serviceHashRefined = $hostDescHash->{'serviceHash'};
foreach my $serviceHashRefinedKey (sort(keys(%$serviceHashRefined))) {
my $serviceDescHash = $serviceHashRefined->{$serviceHashRefinedKey};
 if ($serviceDescHash->{'hasSubService'} != 1) {
print("				<table border=\"0\" cellpadding=\"2\" cellspacing=\"0\">\n");
print("					<tr>\n");
my $formula15=$allHostMember;my $formula16=$serviceHashRefinedKey;my $formula17=$allHostMember;my $formula18=$serviceHashRefinedKey;my $formula19=$allHostMember;my $formula20=$serviceHashRefinedKey;print("						<td><a id=\"xallHosts^$formula15^$formula16\" href=\"javascript:Toggle('allHosts^$formula17^$formula18');\"><img name=\"xallHosts^$formula19^$formula20\" src=\"../../perfStatResources/images/navigation/icon_plusNavBar.gif\" border=\"0\"></a></td>\n");
print("						<td><img src=\"../../perfStatResources/images/navigation/icon_statusMonitor3.gif\" border=\"0\"></td>\n");
my $formula21=$allHostMember;my $formula22=$serviceHashRefinedKey;my $formula23=$allHostMember;my $formula24=$serviceHashRefinedKey;my $formula25=$serviceHashRefinedKey;print("						<td><a id=\"xallHosts^$formula21^$formula22\" href=\"javascript:Toggle('allHosts^$formula23^$formula24');\">$formula25</a></td>\n");
print("					</tr>\n");
print("				</table>\n");
my $formula26=$allHostMember;my $formula27=$serviceHashRefinedKey;print("				<div id=\"allHosts^$formula26^$formula27\" style=\"display:none; margin-left:12px;\">\n");
my $graphHash = $serviceDescHash->{'graphHash'};
foreach my $graphHashName (keys(%$graphHash)) {
my $idString = "$allHostMember^$serviceHashRefinedKey^$graphHashName";
print("				<table border=\"0\" cellpadding=\"2\" cellspacing=\"0\">\n");
print("					<tr>\n");
my $formula28=$idString;my $formula29=$idString;my $formula30=$idString;print("						<td><a id=\"xallHosts^$formula28\" href=\"javascript:Toggle('allHosts^$formula29');\"><img name=\"xallHosts^$formula30\" src=\"../../perfStatResources/images/navigation/icon_plusNavBar.gif\" border=\"0\"></a></td>\n");
print("						<td><img src=\"../../perfStatResources/images/navigation/icon_performanceMonitor2.gif\" border=\"0\"></td>\n");
my $formula31=$idString;my $formula32=$idString;my $formula33=$graphHashName;print("						<td nowrap><a id=\"xallHosts^$formula31\" href=\"javascript:Toggle('allHosts^$formula32');\">$formula33<a></td>\n");
print("					</tr>\n");
print("				</table>\n");
my $formula34=$idString;print("				<div id=\"allHosts^$formula34\" style=\"display:none; margin-left:12px;\">\n");
print("					<table border=\"0\" cellpadding=\"2\" cellspacing=\"0\">\n");
print("						<tr>\n");
print("							<td><img src=\"../../perfStatResources/images/common/spacer.gif\" height=\"10\" width=\"9\" border=\"0\"></td>\n");
print("							<td><img src=\"../../perfStatResources/images/navigation/icon_performanceMonitor1.gif\" border=\"0\"></td>\n");
my $formula35=$allHostMember;my $formula36=$serviceHashRefinedKey;my $formula37=$graphHashName;print("							<td nowrap><a href=\"javascript:insertGraph('$formula35', '$formula36', '$formula37', 'hourly');\">hourly</a></td>\n");
print("						</tr>\n");
print("					</table>\n");
print("					<table border=\"0\" cellpadding=\"2\" cellspacing=\"0\">\n");
print("						<tr>\n");
print("							<td><img src=\"../../perfStatResources/images/common/spacer.gif\" height=\"10\" width=\"9\" border=\"0\"></td>\n");
print("							<td><img src=\"../../perfStatResources/images/navigation/icon_performanceMonitor1.gif\" border=\"0\"></td>\n");
my $formula38=$allHostMember;my $formula39=$serviceHashRefinedKey;my $formula40=$graphHashName;print("							<td nowrap><a href=\"javascript:insertGraph('$formula38', '$formula39', '$formula40', 'daily');\">daily</a></td>\n");
print("						</tr>\n");
print("					</table>\n");
print("					<table border=\"0\" cellpadding=\"2\" cellspacing=\"0\">\n");
print("						<tr>\n");
print("							<td><img src=\"../../perfStatResources/images/common/spacer.gif\" height=\"10\" width=\"9\" border=\"0\"></td>\n");
print("							<td><img src=\"../../perfStatResources/images/navigation/icon_performanceMonitor1.gif\" border=\"0\"></td>\n");
my $formula41=$allHostMember;my $formula42=$serviceHashRefinedKey;my $formula43=$graphHashName;print("							<td nowrap><a href=\"javascript:insertGraph('$formula41', '$formula42', '$formula43', 'weekly');\">weekly</a></td>\n");
print("						</tr>\n");
print("					</table>\n");
print("					<table border=\"0\" cellpadding=\"2\" cellspacing=\"0\">\n");
print("						<tr>\n");
print("							<td><img src=\"../../perfStatResources/images/common/spacer.gif\" height=\"10\" width=\"9\" border=\"0\"></td>\n");
print("							<td><img src=\"../../perfStatResources/images/navigation/icon_performanceMonitor1.gif\" border=\"0\"></td>\n");
my $formula44=$allHostMember;my $formula45=$serviceHashRefinedKey;my $formula46=$graphHashName;print("							<td nowrap><a href=\"javascript:insertGraph('$formula44', '$formula45', '$formula46', 'monthly');\">monthly</a></td>\n");
print("						</tr>\n");
print("					</table>\n");
print("				</div>\n");
}
print("				</div>\n");
 } else {
my $subServiceHash = $serviceDescHash->{'subServiceHash'};
my @list = sort(keys(%$subServiceHash));
print("				<table border=\"0\" cellpadding=\"2\" cellspacing=\"0\">\n");
print("				<tr>\n");
my $formula47=$allHostMember;my $formula48=$serviceHashRefinedKey;my $formula49=$allHostMember;my $formula50=$serviceHashRefinedKey;my $formula51=$allHostMember;my $formula52=$serviceHashRefinedKey;print("					<td><a id=\"xallHosts^$formula47^$formula48\" href=\"javascript:Toggle('allHosts^$formula49^$formula50');\"><img name=\"xallHosts^$formula51^$formula52\" src=\"../../perfStatResources/images/navigation/icon_plusNavBar.gif\" border=\"0\"></a></td>\n");
print("					<td><img src=\"../../perfStatResources/images/navigation/icon_statusMonitor3.gif\" border=\"0\"></td>\n");
my $formula53=$allHostMember;my $formula54=$serviceHashRefinedKey;my $formula55=$allHostMember;my $formula56=$serviceHashRefinedKey;my $formula57=$serviceHashRefinedKey;print("					<td nowrap><a id=\"xallHosts^$formula53^$formula54\" href=\"javascript:Toggle('allHosts^$formula55^$formula56');\">$formula57</a></td>\n");
print("				</tr>\n");
print("				</table>\n");
my $formula58=$allHostMember;my $formula59=$serviceHashRefinedKey;print("				<div id=\"allHosts^$formula58^$formula59\" style=\"display:none; margin-left:12px;\">\n");
foreach my $subServiceHashKey (sort(keys(%$subServiceHash))) {
print("				<table border=\"0\" cellpadding=\"2\" cellspacing=\"0\">\n");
print("					<tr>\n");
my $formula60=$allHostMember;my $formula61=$serviceHashRefinedKey;my $formula62=$subServiceHashKey;my $formula63=$allHostMember;my $formula64=$serviceHashRefinedKey;my $formula65=$subServiceHashKey;my $formula66=$allHostMember;my $formula67=$serviceHashRefinedKey;my $formula68=$subServiceHashKey;print("						<td><a id=\"xallHosts^$formula60^$formula61^$formula62\" href=\"javascript:Toggle('allHosts^$formula63^$formula64^$formula65');\"><img name=\"xallHosts^$formula66^$formula67^$formula68\" src=\"../../perfStatResources/images/navigation/icon_plusNavBar.gif\" border=\"0\"></a></td>\n");
print("						<td><img src=\"../../perfStatResources/images/navigation/icon_statusMonitor3.gif\" border=\"0\"></td>\n");
my $formula69=$allHostMember;my $formula70=$serviceHashRefinedKey;my $formula71=$subServiceHashKey;my $formula72=$allHostMember;my $formula73=$serviceHashRefinedKey;my $formula74=$subServiceHashKey;my $formula75=$subServiceHashKey;print("						<td><a id=\"xallHosts^$formula69^$formula70^$formula71\" href=\"javascript:Toggle('allHosts^$formula72^$formula73^$formula74');\">$formula75</a></td>\n");
print("					</tr>\n");
print("				</table>\n");
my $formula76=$allHostMember;my $formula77=$serviceHashRefinedKey;my $formula78=$subServiceHashKey;print("				<div id=\"allHosts^$formula76^$formula77^$formula78\" style=\"display:none; margin-left:12px;\">\n");
my $graphHash = $subServiceHash->{$subServiceHashKey};
foreach my $graphHashName (keys(%$graphHash)) {
my $idString = "$allHostMember^$serviceHashRefinedKey^$subServiceHashKey^$graphHashName";
print("				<table border=\"0\" cellpadding=\"2\" cellspacing=\"0\">\n");
print("					<tr>\n");
my $formula79=$idString;my $formula80=$idString;my $formula81=$idString;print("						<td><a id=\"xallHosts^$formula79\" href=\"javascript:Toggle('allHosts^$formula80');\"><img name=\"xallHosts^$formula81\" src=\"../../perfStatResources/images/navigation/icon_plusNavBar.gif\" border=\"0\"></a></td>\n");
print("						<td><img src=\"../../perfStatResources/images/navigation/icon_performanceMonitor2.gif\" border=\"0\"></td>\n");
my $formula82=$idString;my $formula83=$idString;my $formula84=$graphHashName;print("						<td nowrap><a id=\"xallHosts^$formula82\" href=\"javascript:Toggle('allHosts^$formula83');\">$formula84<a></td>\n");
print("					</tr>\n");
print("				</table>\n");
my $formula85=$idString;print("					<div id=\"allHosts^$formula85\" style=\"display:none; margin-left:12px;\">\n");
print("					<table border=\"0\" cellpadding=\"2\" cellspacing=\"0\">\n");
print("						<tr>\n");
print("							<td><img src=\"../../perfStatResources/images/common/spacer.gif\" height=\"10\" width=\"9\" border=\"0\"></td>\n");
print("							<td><img src=\"../../perfStatResources/images/navigation/icon_performanceMonitor1.gif\" border=\"0\"></td>\n");
my $formula86=$allHostMember;my $formula87=$serviceHashRefinedKey;my $formula88=$subServiceHashKey;my $formula89=$graphHashName;print("							<td nowrap><a href=\"javascript:insertGraph('$formula86', '$formula87.$formula88', '$formula89', 'hourly');\">hourly</a></td>\n");
print("						</tr>\n");
print("					</table>\n");
print("					<table border=\"0\" cellpadding=\"2\" cellspacing=\"0\">\n");
print("						<tr>\n");
print("							<td><img src=\"../../perfStatResources/images/common/spacer.gif\" height=\"10\" width=\"9\" border=\"0\"></td>\n");
print("							<td><img src=\"../../perfStatResources/images/navigation/icon_performanceMonitor1.gif\" border=\"0\"></td>\n");
my $formula90=$allHostMember;my $formula91=$serviceHashRefinedKey;my $formula92=$subServiceHashKey;my $formula93=$graphHashName;print("							<td nowrap><a href=\"javascript:insertGraph('$formula90', '$formula91.$formula92', '$formula93', 'daily');\">daily</a></td>\n");
print("						</tr>\n");
print("					</table>\n");
print("					<table border=\"0\" cellpadding=\"2\" cellspacing=\"0\">\n");
print("						<tr>\n");
print("							<td><img src=\"../../perfStatResources/images/common/spacer.gif\" height=\"10\" width=\"9\" border=\"0\"></td>\n");
print("							<td><img src=\"../../perfStatResources/images/navigation/icon_performanceMonitor1.gif\" border=\"0\"></td>\n");
my $formula94=$allHostMember;my $formula95=$serviceHashRefinedKey;my $formula96=$subServiceHashKey;my $formula97=$graphHashName;print("							<td nowrap><a href=\"javascript:insertGraph('$formula94', '$formula95.$formula96', '$formula97', 'weekly');\">weekly</a></td>\n");
print("						</tr>\n");
print("					</table>\n");
print("					<table border=\"0\" cellpadding=\"2\" cellspacing=\"0\">\n");
print("						<tr>\n");
print("							<td><img src=\"../../perfStatResources/images/common/spacer.gif\" height=\"10\" width=\"9\" border=\"0\"></td>\n");
print("							<td><img src=\"../../perfStatResources/images/navigation/icon_performanceMonitor1.gif\" border=\"0\"></td>\n");
my $formula98=$allHostMember;my $formula99=$serviceHashRefinedKey;my $formula100=$subServiceHashKey;my $formula101=$graphHashName;print("							<td nowrap><a href=\"javascript:insertGraph('$formula98', '$formula99.$formula100', '$formula101', 'monthly');\">monthly</a></td>\n");
print("						</tr>\n");
print("					</table>\n");
print("					</div>\n");
} 
print("				</div>\n");
}
print("				</div>\n");
}
}
print("				</div>\n");
}
}
print("				</div>\n");
}
foreach my $hostGroup (sort(keys(%$hostGroupHash))) {
my $hostGroupDescHash = $hostGroupHash->{$hostGroup};
my $hasHosts = $hostGroupDescHash->{'hasHosts'};
my $hostGroupID = $hostGroupDescHash->{'hostGroupID'};
print("				<table border=\"0\" cellpadding=\"2\" cellspacing=\"0\">\n");
print("					<tr>\n");
print("						<td>\n");
 if ($hasHosts == 0) {
print("							<img src=\"../../perfStatResources/images/common/spacer.gif\" border=\"0\" width=\"9\" height=\"9\">\n");
 } else {
my $formula102=$hostGroupID;my $formula103=$hostGroupID;my $formula104=$hostGroupID;print("							<a id=\"x$formula102\" href=\"javascript:Toggle('$formula103');\"><img name=\"x$formula104\" src=\"../../perfStatResources/images/navigation/icon_plusNavBar.gif\" border=\"0\"></a>\n");
 }
print("						</td>\n");
print("						<td><img src=\"../../perfStatResources/images/navigation/icon_statusMonitor1.gif\" border=\"0\"></td>\n");
print("						<td>\n");
 if ($hasHosts == 0) {
my $formula105=$hostGroup;print("								$formula105\n");
} else {
my $formula106=$hostGroupID;my $formula107=$hostGroupID;my $formula108=$hostGroup;print("							<a id=\"x$formula106\" href=\"javascript:Toggle('$formula107');\">$formula108</a>\n");
}
print("						</td>\n");
print("					</tr>\n");
print("				</table>\n");
 if ($hasHosts != 0) {
my $formula109=$hostGroupID;print("				<div id=\"$formula109\" style=\"display:none; margin-left:1em\">\n");
my $hostGroupMemberHash = $hostGroupDescHash->{'hostGroupMemberHash'};
foreach my $hostGroupMember (sort(keys(%$hostGroupMemberHash))) {
my $hostDescHash = $hostGroupMemberHash->{$hostGroupMember};
my $hasGraphs = $hostDescHash->{'hasGraphs'};
print("				<table border=\"0\" cellpadding=\"2\" cellspacing=\"0\">\n");
print("					<tr>\n");
print("						<td>\n");
if ($hasGraphs == 0) {
print("							<img src=\"../../perfStatResources/images/common/spacer.gif\" border=\"0\" width=\"9\" height=\"9\">\n");
} else {
my $formula110=$hostGroupID;my $formula111=$hostGroupMember;my $formula112=$hostGroupID;my $formula113=$hostGroupMember;my $formula114=$hostGroupID;my $formula115=$hostGroupMember;print("							<a id=\"x$formula110^$formula111\" href=\"javascript:Toggle('$formula112^$formula113');\"><img name=\"x$formula114^$formula115\" src=\"../../perfStatResources/images/navigation/icon_plusNavBar.gif\" border=\"0\"></a>\n");
}
print("						</td>\n");
print("						<td><img src=\"../../perfStatResources/images/navigation/icon_statusMonitor2.gif\" border=\"0\"></td>\n");
print("						<td nowrap>\n");
if ($hasGraphs == 0) {
my $formula116=$hostGroupMember;print("							$formula116\n");
} else {
my $formula117=$hostGroupID;my $formula118=$hostGroupMember;my $formula119=$hostGroupID;my $formula120=$hostGroupMember;my $formula121=$hostGroupMember;print("							<a id=\"x$formula117^$formula118\" href=\"javascript:Toggle('$formula119^$formula120');\">$formula121</a>\n");
}
print("						</td>\n");
print("					</tr>\n");
print("				</table>\n");
 if ($hasGraphs != 0) {
my $formula122=$hostGroupID;my $formula123=$hostGroupMember;print("				<div id=\"$formula122^$formula123\" style=\"display:none; margin-left:12px;\">\n");
my $serviceHashRefined = $hostDescHash->{'serviceHash'};
foreach my $serviceHashRefinedKey (sort(keys(%$serviceHashRefined))) {
my $serviceDescHash = $serviceHashRefined->{$serviceHashRefinedKey};
 if ($serviceDescHash->{'hasSubService'} == 0) {
print("					<table border=\"0\" cellpadding=\"2\" cellspacing=\"0\">\n");
print("						<tr>\n");
my $formula124=$hostGroupID;my $formula125=$hostGroupMember;my $formula126=$serviceHashRefinedKey;my $formula127=$hostGroupID;my $formula128=$hostGroupMember;my $formula129=$serviceHashRefinedKey;my $formula130=$hostGroupID;my $formula131=$hostGroupMember;my $formula132=$serviceHashRefinedKey;print("							<td><a id=\"x$formula124^$formula125^$formula126\" href=\"javascript:Toggle('$formula127^$formula128^$formula129');\"><img name=\"x$formula130^$formula131^$formula132\" src=\"../../perfStatResources/images/navigation/icon_plusNavBar.gif\" border=\"0\"></a></td>\n");
print("							<td><img src=\"../../perfStatResources/images/navigation/icon_statusMonitor3.gif\" border=\"0\"></td>\n");
my $formula133=$hostGroupID;my $formula134=$hostGroupMember;my $formula135=$serviceHashRefinedKey;my $formula136=$hostGroupID;my $formula137=$hostGroupMember;my $formula138=$serviceHashRefinedKey;my $formula139=$serviceHashRefinedKey;print("							<td><a id=\"x$formula133^$formula134^$formula135\" href=\"javascript:Toggle('$formula136^$formula137^$formula138');\">$formula139</a></td>\n");
print("						</tr>\n");
print("					</table>\n");
my $formula140=$hostGroupID;my $formula141=$hostGroupMember;my $formula142=$serviceHashRefinedKey;print("					<div id=\"$formula140^$formula141^$formula142\" style=\"display:none; margin-left:12px;\">\n");
my $graphHash = $serviceDescHash->{'graphHash'};
foreach my $graphHashName (keys(%$graphHash)) {
my $idString = "$hostGroupID^$hostGroupMember^$serviceHashRefinedKey^$graphHashName";
print("						<table border=\"0\" cellpadding=\"2\" cellspacing=\"0\">\n");
print("							<tr>\n");
my $formula143=$idString;my $formula144=$idString;my $formula145=$idString;print("								<td><a id=\"x$formula143\" href=\"javascript:Toggle('$formula144');\"><img name=\"x$formula145\" src=\"../../perfStatResources/images/navigation/icon_plusNavBar.gif\" border=\"0\"></a></td>\n");
print("								<td><img src=\"../../perfStatResources/images/navigation/icon_performanceMonitor2.gif\" border=\"0\"></td>\n");
my $formula146=$idString;my $formula147=$idString;my $formula148=$graphHashName;print("								<td nowrap><a id=\"x$formula146\" href=\"javascript:Toggle('$formula147');\">$formula148<a></td>\n");
print("							</tr>\n");
print("						</table>\n");
my $formula149=$idString;print("						<div id=\"$formula149\" style=\"display:none; margin-left:12px;\">\n");
print("						<table border=\"0\" cellpadding=\"2\" cellspacing=\"0\">\n");
print("							<tr>\n");
print("								<td><img src=\"../../perfStatResources/images/common/spacer.gif\" height=\"10\" width=\"9\" border=\"0\"></td>\n");
print("								<td><img src=\"../../perfStatResources/images/navigation/icon_performanceMonitor1.gif\" border=\"0\"></td>\n");
my $formula150=$hostGroupMember;my $formula151=$serviceHashRefinedKey;my $formula152=$graphHashName;print("								<td nowrap><a href=\"javascript:insertGraph('$formula150', '$formula151', '$formula152', 'hourly');\">hourly</a></td>\n");
print("							</tr>\n");
print("						</table>\n");
print("						<table border=\"0\" cellpadding=\"2\" cellspacing=\"0\">\n");
print("							<tr>\n");
print("								<td><img src=\"../../perfStatResources/images/common/spacer.gif\" height=\"10\" width=\"9\" border=\"0\"></td>\n");
print("								<td><img src=\"../../perfStatResources/images/navigation/icon_performanceMonitor1.gif\" border=\"0\"></td>\n");
my $formula153=$hostGroupMember;my $formula154=$serviceHashRefinedKey;my $formula155=$graphHashName;print("								<td nowrap><a href=\"javascript:insertGraph('$formula153', '$formula154', '$formula155', 'daily');\">daily</a></td>\n");
print("							</tr>\n");
print("						</table>\n");
print("						<table border=\"0\" cellpadding=\"2\" cellspacing=\"0\">\n");
print("							<tr>\n");
print("								<td><img src=\"../../perfStatResources/images/common/spacer.gif\" height=\"10\" width=\"9\" border=\"0\"></td>\n");
print("								<td><img src=\"../../perfStatResources/images/navigation/icon_performanceMonitor1.gif\" border=\"0\"></td>\n");
my $formula156=$hostGroupMember;my $formula157=$serviceHashRefinedKey;my $formula158=$graphHashName;print("								<td nowrap><a href=\"javascript:insertGraph('$formula156', '$formula157', '$formula158', 'weekly');\">weekly</a></td>\n");
print("							</tr>\n");
print("						</table>\n");
print("						<table border=\"0\" cellpadding=\"2\" cellspacing=\"0\">\n");
print("							<tr>\n");
print("								<td><img src=\"../../perfStatResources/images/common/spacer.gif\" height=\"10\" width=\"9\" border=\"0\"></td>\n");
print("								<td><img src=\"../../perfStatResources/images/navigation/icon_performanceMonitor1.gif\" border=\"0\"></td>\n");
my $formula159=$hostGroupMember;my $formula160=$serviceHashRefinedKey;my $formula161=$graphHashName;print("								<td nowrap><a href=\"javascript:insertGraph('$formula159', '$formula160', '$formula161', 'monthly');\">monthly</a></td>\n");
print("							</tr>\n");
print("						</table>\n");
print("						</div>\n");
}
print("				</div>\n");
 } else {
my $subServiceHash = $serviceDescHash->{'subServiceHash'};
my @list = sort(keys(%$subServiceHash));
print("				<table border=\"0\" cellpadding=\"2\" cellspacing=\"0\">\n");
print("				<tr>\n");
my $formula162=$hostGroupID;my $formula163=$hostGroupMember;my $formula164=$serviceHashRefinedKey;my $formula165=$hostGroupID;my $formula166=$hostGroupMember;my $formula167=$serviceHashRefinedKey;my $formula168=$hostGroupID;my $formula169=$hostGroupMember;my $formula170=$serviceHashRefinedKey;print("					<td><a id=\"x$formula162^$formula163^$formula164\" href=\"javascript:Toggle('$formula165^$formula166^$formula167');\"><img name=\"x$formula168^$formula169^$formula170\" src=\"../../perfStatResources/images/navigation/icon_plusNavBar.gif\" border=\"0\"></a></td>\n");
print("					<td><img src=\"../../perfStatResources/images/navigation/icon_statusMonitor3.gif\" border=\"0\"></td>\n");
my $formula171=$hostGroupID;my $formula172=$hostGroupMember;my $formula173=$serviceHashRefinedKey;my $formula174=$hostGroupID;my $formula175=$hostGroupMember;my $formula176=$serviceHashRefinedKey;my $formula177=$serviceHashRefinedKey;print("					<td nowrap><a id=\"x$formula171^$formula172^$formula173\" href=\"javascript:Toggle('$formula174^$formula175^$formula176');\">$formula177</a></td>\n");
print("				</tr>\n");
print("				</table>\n");
my $formula178=$hostGroupID;my $formula179=$hostGroupMember;my $formula180=$serviceHashRefinedKey;print("				<div id=\"$formula178^$formula179^$formula180\" style=\"display:none; margin-left:12px;\">\n");
foreach my $subServiceHashKey (sort(keys(%$subServiceHash))) {
 my $idString = "$hostGroupID^$hostGroupMember^$serviceHashRefinedKey^$subServiceHashKey";
print("				<table border=\"0\" cellpadding=\"2\" cellspacing=\"0\">\n");
print("					<tr>\n");
my $formula181=$idString;my $formula182=$idString;my $formula183=$idString;print("						<td><a id=\"x$formula181\" href=\"javascript:Toggle('$formula182');\"><img name=\"x$formula183\" src=\"../../perfStatResources/images/navigation/icon_plusNavBar.gif\" border=\"0\"></a></td>\n");
print("						<td><img src=\"../../perfStatResources/images/navigation/icon_statusMonitor3.gif\" border=\"0\"></td>\n");
my $formula184=$idString;my $formula185=$idString;my $formula186=$subServiceHashKey;print("						<td><a id=\"x$formula184\" href=\"javascript:Toggle('$formula185');\">$formula186</a></td>\n");
print("					</tr>\n");
print("				</table>\n");

my $formula187=$hostGroupID;my $formula188=$hostGroupMember;my $formula189=$serviceHashRefinedKey;my $formula190=$subServiceHashKey;print("				<div id=\"$formula187^$formula188^$formula189^$formula190\" style=\"display:none; margin-left:12px;\">\n");
my $graphHash = $subServiceHash->{$subServiceHashKey};
foreach my $graphHashName (keys(%$graphHash)) {
my $idString = "$hostGroupID^$hostGroupMember^$serviceHashRefinedKey^$subServiceHashKey^$graphHashName";
print("					<table border=\"0\" cellpadding=\"2\" cellspacing=\"0\">\n");
print("						<tr>\n");
my $formula191=$idString;my $formula192=$idString;my $formula193=$idString;print("							<td><a id=\"x$formula191\" href=\"javascript:Toggle('$formula192');\"><img name=\"x$formula193\" src=\"../../perfStatResources/images/navigation/icon_plusNavBar.gif\" border=\"0\"></a></td>\n");
print("							<td><img src=\"../../perfStatResources/images/navigation/icon_performanceMonitor2.gif\" border=\"0\"></td>\n");
my $formula194=$idString;my $formula195=$idString;my $formula196=$graphHashName;print("							<td nowrap><a id=\"x$formula194\" href=\"javascript:Toggle('$formula195');\">$formula196<a></td>\n");
print("						</tr>\n");
print("					</table>\n");
my $formula197=$idString;print("						<div id=\"$formula197\" style=\"display:none; margin-left:12px;\">\n");
print("						<table border=\"0\" cellpadding=\"2\" cellspacing=\"0\">\n");
print("							<tr>\n");
print("								<td><img src=\"../../perfStatResources/images/common/spacer.gif\" height=\"10\" width=\"9\" border=\"0\"></td>\n");
print("								<td><img src=\"../../perfStatResources/images/navigation/icon_performanceMonitor1.gif\" border=\"0\"></td>\n");
my $formula198=$hostGroupMember;my $formula199=$serviceHashRefinedKey;my $formula200=$subServiceHashKey;my $formula201=$graphHashName;print("								<td nowrap><a href=\"javascript:insertGraph('$formula198', '$formula199.$formula200', '$formula201', 'hourly');\">hourly</a></td>\n");
print("							</tr>\n");
print("						</table>\n");
print("						<table border=\"0\" cellpadding=\"2\" cellspacing=\"0\">\n");
print("							<tr>\n");
print("								<td><img src=\"../../perfStatResources/images/common/spacer.gif\" height=\"10\" width=\"9\" border=\"0\"></td>\n");
print("								<td><img src=\"../../perfStatResources/images/navigation/icon_performanceMonitor1.gif\" border=\"0\"></td>\n");
my $formula202=$hostGroupMember;my $formula203=$serviceHashRefinedKey;my $formula204=$subServiceHashKey;my $formula205=$graphHashName;print("								<td nowrap><a href=\"javascript:insertGraph('$formula202', '$formula203.$formula204', '$formula205', 'daily');\">daily</a></td>\n");
print("							</tr>\n");
print("						</table>\n");
print("						<table border=\"0\" cellpadding=\"2\" cellspacing=\"0\">\n");
print("							<tr>\n");
print("								<td><img src=\"../../perfStatResources/images/common/spacer.gif\" height=\"10\" width=\"9\" border=\"0\"></td>\n");
print("								<td><img src=\"../../perfStatResources/images/navigation/icon_performanceMonitor1.gif\" border=\"0\"></td>\n");
my $formula206=$hostGroupMember;my $formula207=$serviceHashRefinedKey;my $formula208=$subServiceHashKey;my $formula209=$graphHashName;print("								<td nowrap><a href=\"javascript:insertGraph('$formula206', '$formula207.$formula208', '$formula209', 'weekly');\">weekly</a></td>\n");
print("							</tr>\n");
print("						</table>\n");
print("						<table border=\"0\" cellpadding=\"2\" cellspacing=\"0\">\n");
print("							<tr>\n");
print("								<td><img src=\"../../perfStatResources/images/common/spacer.gif\" height=\"10\" width=\"9\" border=\"0\"></td>\n");
print("								<td><img src=\"../../perfStatResources/images/navigation/icon_performanceMonitor1.gif\" border=\"0\"></td>\n");
my $formula210=$hostGroupMember;my $formula211=$serviceHashRefinedKey;my $formula212=$subServiceHashKey;my $formula213=$graphHashName;print("								<td nowrap><a href=\"javascript:insertGraph('$formula210', '$formula211.$formula212', '$formula213', 'monthly');\">monthly</a></td>\n");
print("							</tr>\n");
print("						</table>\n");
print("						</div>\n");
} 
print("				</div>\n");
}
print("				</div>\n");
}
}
print("				</div>\n");
}
}
print("				</div>\n");
}
}
print("				</div>\n");
print("			</td>\n");
print("		</tr>\n");
print("		</table>\n");
print("	</body>\n");
print("</html>\n");
