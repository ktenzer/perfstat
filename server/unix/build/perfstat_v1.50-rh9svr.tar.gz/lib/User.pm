package User;
require Storable;
@ISA = ("Storable");

sub new
{
	my $this = {};
	bless ($this, shift);
	$this->doInit(@_);
	return $this;
}

sub doInit
{
	my ($this, %arg) = @_;
	$this->{name} = $arg{name} || die("missing name");
	$this->{password} = $arg{password} || die("missing password");
	$this->{creator} = $arg{creator} || die("missing creator");
	$this->{role} = $arg{role} || die("missing role");
	$this->{hostLimit} = $arg{hostLimit} || 50;
	$this->{navBarWidth} = $arg{navBarWidth} || 180;
	$this->{navBarTextLength} = $arg{navBarTextLength} || 80;
	$this->{timeoutInterval} = $arg{timeoutInterval} || 80;
	$this->{statusRefreshInterval} = $arg{statusRefreshInterval} || 20;
	$this->{hostGroups} = [];
	$this->{reportGroups} = [];

}

sub getName
{
	my ($this) = @_;
	return $this->{name};
}

sub setName
{
	my ($this, $value) = @_;
	$this->{name} = $value;
}

sub getPassword
{
	my ($this) = @_;
	return $this->{password};
}

sub setPassword
{
	my ($this, $value) = @_;
	$this->{password} = $value;
}

sub getCreator
{
	my ($this) = @_;
	return $this->{creator};
}

sub setCreator
{
	my ($this, $value) = @_;
	$this->{creator} = $value;
}

sub getRole
{
	my ($this) = @_;
	return $this->{role};
}

sub setRole
{
	my ($this, $value) = @_;
	$this->{role} = $value;
}

sub getHostLimit
{
	my ($this) = @_;
	return $this->{hostLimit};
}

sub setHostLimit
{
	my ($this, $value) = @_;
	$this->{hostLimit} = $value;
}

sub getNavBarWidth
{
	my ($this) = @_;
	return $this->{navBarWidth};
}

sub setNavBarWidth
{
	my ($this, $value) = @_;
	$this->{navBarWidth} = $value;
}

sub getNavBarTextLength
{
	my ($this) = @_;
	return $this->{navBarTextLength};
}

sub setNavBarTextLength
{
	my ($this, $value) = @_;
	$this->{navBarTextLength} = $value;
}

sub getTimeoutInterval
{
	my ($this) = @_;
	return $this->{timeoutInterval};
}

sub setTimeoutInterval
{
	my ($this, $value) = @_;
	$this->{timeoutInterval} = $value;
}

sub getStatusRefreshInterval
{
	my ($this) = @_;
	return $this->{statusRefreshInterval};
}

sub setStatusRefreshInterval
{
	my ($this, $value) = @_;
	$this->{statusRefreshInterval} = $value;
}

sub getHostGroupsLength
{
	my $this = shift @_;
	my $arrayRef = $this->{hostGroups};
	my $arrayLength = @$arrayRef;
	return $arrayLength;
}

sub addHostGroup
{
	my ($this, $arg) = @_;
	$arrayRef = $this->{hostGroups};
	push(@$arrayRef, $arg);
}

sub deleteHostGroup
{
	my ($this, $skipElements) = @_;
	$arrayRef = $this->{hostGroups};
	splice(@$arrayRef, skipElements, 1);
}

sub getReportGroupsLength
{
	my $this = shift @_;
	my $arrayRef = $this->{reportGroups};
	my $arrayLength = @$arrayRef;
	return $arrayLength;
}

sub addReportGroup
{
	my ($this, $arg) = @_;
	$arrayRef = $this->{reportGroups};
	push(@$arrayRef, $arg);
}

sub deleteReportGroup
{
	my ($this, $skipElements) = @_;
	$arrayRef = $this->{reportGroups};
	splice(@$arrayRef, skipElements, 1);
}

1; #terminate the package