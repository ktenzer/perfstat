package Graph;

sub new
{
	my $this = {};
	bless ($this, shift);
	$this->doInit(@_);
	return $this;
}

sub doInit
{
	my ($this, %arg) = @_;
	$this->{name} = $arg{name} || die("missing name");
	$this->{title} = $arg{title} || "";
	$this->{comment} = $arg{comment} || "";
	$this->{imageFormat} = $arg{imageFormat} || "";
	$this->{width} = $arg{width} || "";
	$this->{height} = $arg{height} || "";
	$this->{verticalLabel} = $arg{verticalLabel} || "";
	$this->{upperLimit} = $arg{upperLimit};
	$this->{lowerLimit} = $arg{lowerLimit};
	$this->{rigid} = $arg{rigid} || "";
	$this->{base} = $arg{base} || "";
	$this->{unitsExponent} = $arg{unitsExponent};
	$this->{noMinorGrids} = $arg{noMinorGrids} || "";
	$this->{stepValue} = $arg{stepValue} || "";
	$this->{gprintFormat} = $arg{gprintFormat} || "";
	$this->{metricIndexHash} = {};
	$this->{metricArray} = [];
}

sub getName
{
	my ($this) = @_;
	return $this->{name};
}

sub setName
{
	my ($this, $value) = @_;
	$this->{name} = $value;
}

sub getTitle
{
	my ($this) = @_;
	return $this->{title};
}

sub setTitle
{
	my ($this, $value) = @_;
	$this->{title} = $value;
}

sub getComment
{
        my ($this) = @_;
        return $this->{comment};
}

sub setComment
{
        my ($this, $value) = @_;
        $this->{comment} = $value;
}

sub getImageFormat
{
        my ($this) = @_;
        return $this->{imageFormat};
}

sub setImageFormat
{
        my ($this, $value) = @_;
        $this->{imageFormat} = $value;
}

sub getWidth
{
        my ($this) = @_;
        return $this->{width};
}

sub setWidth
{
        my ($this, $value) = @_;
        $this->{width} = $value;
}

sub getHeight
{
        my ($this) = @_;
        return $this->{height};
}

sub setHeight
{
        my ($this, $value) = @_;
        $this->{height} = $value;
}

sub getVerticalLabel
{
        my ($this) = @_;
        return $this->{verticalLabel};
}

sub setVerticalLabel
{
        my ($this, $value) = @_;
        $this->{verticalLabel} = $value;
}

sub getUpperLimit
{
        my ($this) = @_;
        return $this->{upperLimit};
}

sub setUpperLimit
{
        my ($this, $value) = @_;
        $this->{upperLimit} = $value;
}

sub getLowerLimit
{
        my ($this) = @_;
        return $this->{lowerLimit};
}

sub setLowerLimit
{
        my ($this, $value) = @_;
        $this->{lowerLimit} = $value;
}

sub getRigid
{
        my ($this) = @_;
        return $this->{rigid};
}

sub setRigid
{
        my ($this, $value) = @_;
        $this->{rigid} = $value;
}

sub getBase
{
        my ($this) = @_;
        return $this->{base};
}

sub setBase
{
        my ($this, $value) = @_;
        $this->{base} = $value;
}

sub getUnitsExponent
{
        my ($this) = @_;
        return $this->{unitsExponent};
}

sub setUnitsExponent
{
        my ($this, $value) = @_;
        $this->{unitsExponent} = $value;
}

sub getNoMinorGrids
{
        my ($this) = @_;
        return $this->{noMinorGrids};
}

sub setNoMinorGrids
{
        my ($this, $value) = @_;
        $this->{noMinoreGrids} = $value;
}

sub getStepValue
{
        my ($this) = @_;
        return $this->{stepValue};
}

sub setStepValue
{
        my ($this, $value) = @_;
        $this->{stepValue} = $value;
}

sub getGprintFormat
{
        my ($this) = @_;
        return $this->{gprintFormat};
}

sub setGprintFormat
{
        my ($this, $value) = @_;
        $this->{gprintFormat} = $value;
}

sub addGraphMetric
{
	my ($this, $key, $obj) = @_;
	my $arrayRef = $this->{metricArray};
	push(@$arrayRef, $obj);
	my $dataRef = \@$arrayRef;
	my $length = $#$dataRef;
	print "Length: $length Key: $key Obj: $obj\n";
	my $hashRef = $this->{metricIndexHash};
	$hashRef->{$key} = $length;
}
	

1; #terminate the package
