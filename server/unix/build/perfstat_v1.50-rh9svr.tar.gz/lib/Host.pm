package Host;
require Storable;
@ISA = ("Storable");

sub new
{
	my $this = {};
	bless ($this, shift);
	$this->doInit(@_);
	return $this;
}

sub doInit
{
	my ($this, %arg) = @_;
	$this->{OS} = $arg{OS} || die("missing OS");
	$this->{IP} = $arg{IP};
	$this->{Owner} = $arg{Owner};
	$this->{lastUpdate} = $arg{lastUpdate} || "0";
	$this->{serviceIndex} = {};
}

sub getOS
{
	my ($this) = @_;
	return $this->{OS};
}

sub setOS
{
	my ($this, $value) = @_;
	$this->{OS} = $value;
}

sub getLastUpdate
{
	my ($this) = @_;
	return $this->{lastUpdate};
}

sub setLastUpdate
{
	my ($this, $value) = @_;
	$this->{lastUpdate} = $value;
}

sub getIP
{
	my ($this) = @_;
	return $this->{IP};
}

sub setIP
{
	my ($this, $value) = @_;
	$this->{IP} = $value;
}

sub getOwner
{
	my ($this) = @_;
	return $this->{Owner};
}

sub setOwner
{
	my ($this, $value) = @_;
	$this->{Owner} = $value;
}

sub getServiceIndex
{
	my ($this) = @_;
	return $this->{serviceIndex};
}

sub addService
{
	my ($this, $key, $value) = @_;
	$hashRef = $this->{serviceIndex};
	$hashRef->{$key} = $value;
}

1; #terminate the package
