package ReportGroup;
require Storable;
@ISA = ("Storable");

sub new
{
	my $this = {};
	bless ($this, shift);
	$this->doInit(@_);
	return $this;
}

sub doInit
{
	my ($this, %arg) = @_;
	$this->{name} = $arg{name} || die("missing name");
	$this->{description} = $arg{description} || "";
	$this->{memberArray} = [];

}

sub getName
{
	my ($this) = @_;
	return $this->{name};
}

sub setName
{
	my ($this, $value) = @_;
	$this->{name} = $value;
}

sub getDescription
{
	my ($this) = @_;
	return $this->{description};
}

sub setDescription
{
	my ($this, $value) = @_;
	$this->{description} = $value;
}

sub getMemberArrayLength
{
	my $this = shift @_;
	my $arrayRef = $this->{memberArray};
	my $arrayLength = @$arrayRef;
	return $arrayLength;
}

sub addMember
{
	my ($this, $arg) = @_;
	$arrayRef = $this->{memberArray};
	push(@$arrayRef, $arg);
}

sub deleteMember
{
	my ($this, $skipElements) = @_;
	$arrayRef = $this->{memberArray};
	splice(@$arrayRef, skipElements, 1);
}

1; #terminate the package