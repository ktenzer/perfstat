##Libraray of Utility function for perfstat CGI
sub containsNonWordChar {
	my ($string) = @_;
	if ($string =~ /[\W]/) {
		return 1;
	} else {
		return 0;
	}
}
### Get configuration dynamically from perf-conf ###
sub getConfiguration {
        my $configfile="$perfhome/etc/perf-conf";
        my $hashref = shift;

        open(FILE, $configfile)
                or die "ERROR: Couldn't open FileHandle for $configfile: $!\n";

        my @data=<FILE>;
        foreach my $line (@data) {

                # Skip line if commented out
                next if ($line =~ m/^#/);
                next if ($line =~ m/^\s+/);
                $line =~ m/(\w+)=(.+)/;

                my $key=$1;
                my $value=$2;

                $hashref->{$key}=$value;
        }
        close(FILE);
}

#######################################################inputCheckFunctions
sub checkAdminName {
	my ($adminName) = @_;
	if (length($adminName) == 0) {die('Error: missing required value for $adminName');}
	if(!(-d "$perfhome/var/db/users/$adminName")) {die('Error: invalid value for $adminName: no user directory');}
	if(!(-e "$perfhome/var/db/users/$adminName/$adminName.ser")) {die('Error: invalid value for $adminName: no user file');}
	if (!(exists( $userIndex->{$adminName}->{$adminName}))) {die('Error: invalid value for $adminName');}
}

sub checkUserName {
	my ($adminName, $userName) = @_;
	if (length($userName) == 0) {die('Error: missing required value for $userName');}
	if(!(-d "$perfhome/var/db/users/$userName")) {die('Error: invalid value for $userName: no user directory');}
	if(!(-e "$perfhome/var/db/users/$userName/$userName.ser")) {die('Error: invalid value for $userName: no user file');}
	if (!(exists( $userIndex->{$adminName}->{$userName}))) {die('Error: invalid value for $userName');}
}

sub checkHostName {
	my ($adminName, $hostName) = @_;
	if (length($hostName) == 0) {die('Error: missing required value for $hostName');}
	if(!(-d "$perfhome/var/db/hosts/$hostName")) {die('Error: invalid value for $hostName: no host directory');}
	if(!(-e "$perfhome/var/db/hosts/$hostName/$hostName.ser")) {die('Error: invalid value for $hostName: no host file');}
	if (!(exists( $hostIndex->{$hostName}))) {die('Error: invalid value for $hostName');}
	if ($adminName ne "perfstat") {
		if ($hostIndex->{$hostName}->getOwner() ne $adminName)  {die('ERROR invalid permissions for $adminName');}
	}
}

sub checkAndSetHostGroupID {
	my ($allowUndefinedRequestParam) = @_;

	my $hostGroupID;
	if (!$allowUndefinedRequestParam && !defined($request->param("hostGroupID"))) {
			die('Error: missing required value for hostGroupID');
	} else {
		$hostGroupID = $request->param("hostGroupID");
	}

	if (!defined($sessionObj->param("hostGroupID"))) {$sessionObj->param("hostGroupID", "");}

	if ($sessionObj->param("hostGroupID") ne $hostGroupID) {
		if (!defined($hostGroupID)) {
			$sessionObj->param("hostGroupID",  $hostGroupID);
		} elsif ($hostGroupID == "allHosts") {
			$sessionObj->param("hostGroupID",  $hostGroupID);
		} else {
			my $hostGroupArray = $userIndex->{$sessionObj->param("selectedAdmin")}->{$sessionObj->param("selectedUser")}->{'hostGroups'};
			if (!defined($hostGroupArray->[$hostGroupID])) {
				die('Error: invalid value for $hostGroupID');
			} else {
				$sessionObj->param("hostGroupID",  $hostGroupID);
			}
		}
	}

	if (!defined($hostGroupID)) {
		#do nothing
	} elsif ($hostGroupID == "allHosts") {
		#define array of allHosts
		$hostGroupName = "All Hosts";
	} else {
		my $hostGroup = $userIndex->{$sessionObj->param("selectedAdmin")}->{$sessionObj->param("selectedUser")}->{'hostGroups'}->[$sessionObj->param("hostGroupID")];
		$hostGroupName = $hostGroup->getName();
	}
}

sub checkAndSetHostName {
	my ($allowUndefinedRequestParam) = @_;

	my $hostName;
	if (!$allowUndefinedRequestParam && !defined($request->param("hostName"))) {
		die('Error: missing required value for hostName');
	} else {
		$hostName = $request->param("hostName");
	}

	if (!defined($sessionObj->param("hostName"))) {$sessionObj->param("hostName", "");}

	if ($sessionObj->param("hostName") ne $hostName) {
		if (defined($hostName)) {
			checkHostName($sessionObj->param("selectedAdmin"), $hostName);
			$sessionObj->param("hostName",  $hostName);
		}
	}
}

sub checkAndSetServiceName {
	my ($allowUndefinedRequestParam) = @_;

	my $serviceName;
	if (!$allowUndefinedRequestParam && !defined($request->param("serviceName"))) {
		die('Error: missing required value for serviceName');
	} else {
		$serviceName = $request->param("serviceName");
	}

	if (!defined($sessionObj->param("serviceName"))) {$sessionObj->param("serviceName", "");}

	if ($sessionObj->param("serviceName") ne $serviceName) {
		if (defined($hostName)) {
			if (length($serviceName) != 0 && !exists($hostIndex->{$sessionObj->param("hostName")}->{'serviceIndex'}->{$serviceName})) {
				die('Error: invalid value for $serviceName');
			} else {
				$sessionObj->param("$serviceName",  $serviceName);
			}
		}
	}
}

#######################################################basicWebUtilFunctions
sub metaRedirect {
	my ($time, $url) = @_;
	print("<meta http-equiv=\"refresh\" content=\"$time; url=$url\">\n");
}
sub trim {
	my ($string) = @_;
	$string =~ s/^\s+//;
	$string =~ s/\s+$//;
	return $string;
}

sub URLEncode {
	my ($string) = $_[0];
	$string =~ s/([\W])/"%" . uc(sprintf("%2.2x", ord($1)))/eg;
	return $string;
}


1;