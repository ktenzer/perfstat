use strict;
package main;

#define array of allHosts
$allHostArray = [];
foreach my $host (sort(keys(%$hostIndex))) {
	my $hostObject = $hostIndex->{$host};
	my $owner = $hostObject->getOwner();
	if ($owner eq $sessionObj->param("selectedAdmin")) {
		push(@$allHostArray, $host);
	}
}
#Create allHostServiceHash
if (@$allHostArray == 0) {
	#don't do anything; no hosts in all hosts
} else {
	$allHostServiceHash = {};
	makeStatusHash($allHostServiceHash, $allHostArray);
}

#define hash of host Groups to list
my $hostGroupArray = $userIndex->{$sessionObj->param("selectedAdmin")}->{$sessionObj->param("selectedUser")}->{hostGroups};
my $hostGroupArrayLen = @$hostGroupArray;
$hostGroupHash = {};
for (my $count1 = 0; $count1 < $hostGroupArrayLen; $count1++) {
	my $hostGroupObject = $hostGroupArray->[$count1];
	my $hostGroupName = $hostGroupObject->getName();
	my $memberArray = $hostGroupObject->{'memberArray'};
	if (@$memberArray == 0) {
		my $hostGroupDescHash = {};
		$hostGroupDescHash->{'hasHosts'} = 0;
		$hostGroupDescHash->{'hostGroupID'} = $count1;
		$hostGroupDescHash->{'hostGroupServiceHash'} = {};
		$hostGroupHash->{$hostGroupName} = $hostGroupDescHash;
	} else {
		my $serviceHash = {};
		makeStatusHash($serviceHash, $memberArray);
		my $hostGroupDescHash = {};
		$hostGroupDescHash->{'hasHosts'} = 1;
		$hostGroupDescHash->{'hostGroupID'} = $count1;
		$hostGroupDescHash->{'hostGroupServiceHash'} = $serviceHash;
		$hostGroupHash->{$hostGroupName} = $hostGroupDescHash;
	}
}

############################################################### FUNCTIONS
sub makeStatusHash {
	my ($serviceHash, $memberArray) = @_;
	foreach my $hostName (@$memberArray) {
		my $hostObject = $hostIndex->{$hostName};
		my $serviceIndex = $hostObject->{'serviceIndex'};
		foreach my $service (keys(%$serviceIndex)) {
			my $serviceObject = $serviceIndex->{$service};
			my $serviceName = $serviceObject->getServiceName();
			my $arrayLength = $serviceObject->getMetricArrayLength();

     	           for (my $counter=0; $counter < $arrayLength; $counter++) {
				my $metricObject = $serviceObject->{metricArray}->[$counter];
				my $hasEvents = $metricObject->getHasEvents();          
				if ($hasEvents == 1) {
					my $status = $metricObject->getStatus();
					my $prefix = $service;
					$prefix =~ s/\..*//;
					if ( ! exists($serviceHash->{$prefix})) {
						#service not yet added
						$serviceHash->{$prefix} = $status;
					}
					
					#service already added
					if ($status eq "nostatus") {
						$serviceHash->{$prefix} = $status;
						last;
					} elsif ($status eq "CRIT" && $serviceHash->{$prefix} ne "nostatus") {
						$serviceHash->{$prefix} = $status;
					} elsif ($status eq "WARN" && $serviceHash->{$prefix} ne "nostatus"
										&& $serviceHash->{$prefix} ne "CRIT") {
						$serviceHash->{$prefix} = $status;
					} elsif ($status eq "OK"  && $serviceHash->{$prefix} ne "nostatus"
										&& $serviceHash->{$prefix} ne "CRIT"
										&& $serviceHash->{$prefix} ne "WARN") {
						$serviceHash->{$prefix} = $status;
					}
				}
			}
		}
	}
}

1;