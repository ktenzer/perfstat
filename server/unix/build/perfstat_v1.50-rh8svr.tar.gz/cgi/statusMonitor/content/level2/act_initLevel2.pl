use strict;
package main;

checkAndSetHostGroupID(0);

$hostHash = {};
my $hostGroupArray = [];

if ($sessionObj->param("hostGroupID") eq "allHosts") {
	#define array of allHosts
	$hostGroupName = "All Hosts";
	foreach my $host (sort(keys(%$hostIndex))) {
		my $hostObject = $hostIndex->{$host};
		my $owner = $hostObject->getOwner();
		if ($owner eq $sessionObj->param("selectedAdmin")) {
			push(@$hostGroupArray, $host);
		}
	}
} else {
	my $hostGroup = $userIndex->{$sessionObj->param("selectedAdmin")}->{$sessionObj->param("selectedUser")}->{'hostGroups'}->[$sessionObj->param("hostGroupID")];
	$hostGroupName = $hostGroup->getName();
	$hostGroupArray = $hostGroup->{'memberArray'};
}

foreach my $hostName (@$hostGroupArray) {
	my $hostDescHash = {};
	my $hostObject = $hostIndex->{$hostName};
	$hostDescHash->{'OS'} = $hostObject->getOS();
	my $lastUpdate = $hostObject->getLastUpdate();
	if ($lastUpdate == 0) {
		$lastUpdate = "null";
	} else {
		$lastUpdate = localtime($lastUpdate);
	}
	$hostDescHash->{'lastUpdate'} = $lastUpdate;
	my $serviceIndex = $hostObject->{'serviceIndex'};
	
	if (%$serviceIndex == 0) {
		$hostDescHash->{'hasServices'} = 0;
	} else {
		$hostDescHash->{'hasServices'} = 1;
		my $serviceHashRaw = {};
		makeServiceHashRaw($serviceHashRaw, $serviceIndex);
		my $serviceHashRefined = {};
		makeServiceHashRefined($serviceHashRaw, $serviceHashRefined);
		$hostDescHash->{'hostServiceHash'} = $serviceHashRefined;
	}
	$hostHash->{$hostName} = $hostDescHash;
}

###############################################################FUNCTIONS
#----------------------------------------------------------------------------------------------------- makeServiceHashRaw
sub makeServiceHashRaw {
	my ($rawHash, $serviceIndex) = @_;
	foreach my $service (keys(%$serviceIndex)) {
		my $serviceObject = $serviceIndex->{$service};
		my $serviceName = $serviceObject->getServiceName();
		my $arrayLength = $serviceObject->getMetricArrayLength();		
		for (my $counter=0; $counter < $arrayLength; $counter++) {
			my $metricObject = $serviceObject->{metricArray}->[$counter];
			my $hasEvents = $metricObject->getHasEvents();          
			my $status = $metricObject->getStatus();
			if ($hasEvents == 1) {
				if ($status eq "nostatus") {
					$rawHash->{$service} = "nostatus";
					last;
				} elsif ($status eq "CRIT" && $rawHash->{$service} ne "nostatus") {
					$rawHash->{$service}  = "CRIT";
				} elsif ( $status eq "WARN" && $rawHash->{$service} ne "nostatus" && $rawHash->{$service} ne "CRIT") {
					$rawHash->{$service}  = "WARN";
				} elsif ($status eq "OK" && $rawHash->{$service} ne "nostatus" && $rawHash->{$service} ne "CRIT" && $rawHash->{$service} ne "WARN") {
					$rawHash->{$service}  = "OK";
				}
			}
		}
	}
}

#---------------------------------------------------------------------------------------------------- makeServiceHashRefined
sub makeServiceHashRefined {
	my ($rawHash, $refinedHash) = @_;
	my $previousServicePrefix = "";

	foreach my $fullServiceName (sort(keys(%$rawHash))) {
		my $prefix = $fullServiceName;
		$prefix =~ s/\..*//;
		if ($prefix ne $previousServicePrefix) {
			# new service or subservice
			if ($fullServiceName !~ m/\S+\.\S+/) {
				# if not subservice
				my $tempHash = {};
				$tempHash->{'hasSubService'} = 0;
				$tempHash->{'status'} = $rawHash->{$fullServiceName};
				$refinedHash->{$prefix} = $tempHash;
				$previousServicePrefix = $prefix;
			} else {
				# if is first occurrence of subservice
				my $tempHash = {};
				my $suffix = $fullServiceName;
				$suffix =~ s/.*\.//;
				$tempHash->{'hasSubService'} = 1;
				$tempHash->{'subServiceHash'} = {};
				my $status = $rawHash->{$fullServiceName};
				$tempHash->{'subServiceHash'}->{$suffix} = $status;
				$tempHash->{'status'} = $status;
				$refinedHash->{$prefix} = $tempHash;
				$previousServicePrefix = $prefix;
			}
		} else {
			# next occurrence of previously entered subservice in newHash
			my $suffix = $fullServiceName;
			$suffix =~ s/^\w+\.//;
			my $status = $rawHash->{$fullServiceName};
			$refinedHash->{$prefix}->{'subServiceHash'}->{$suffix} = $status;
			if ($status eq "nostatus") {
				$refinedHash->{$prefix}->{'status'} = "nostatus";
			} elsif ($status eq "CRIT" && $refinedHash->{$prefix}->{'status'} ne "nostatus") {
				$refinedHash->{$prefix}->{'status'}  = "CRIT";
			} elsif ( $status eq "WARN" && $refinedHash->{$prefix}->{'status'} ne "nostatus" && $refinedHash->{$prefix}->{'status'} ne "CRIT") {
				$refinedHash->{$prefix}->{'status'}  = "WARN";
			} elsif ($status eq "OK" && $refinedHash->{$prefix}->{'status'}  ne "nostatus" && $refinedHash->{$prefix}->{'status'} ne "CRIT" && $refinedHash->{$prefix}->{'status'}  ne "WARN") {
				$refinedHash->{$prefix}->{'status'}   = "OK";
			}
		}
	}
}

1;