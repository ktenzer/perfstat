use strict;
package main;
print("<html>\n");
print("	<head>\n");
print("		<meta http-equiv=\"content-type\" content=\"text/html;charset=iso-8859-1\">\n");
print("		<title>PerfStat Tool: Perfomance Monitoring & Status Notification</title>\n");
print("		<link rel=\"stylesheet\" type=\"text/css\" href=\"../../../perfStatResources/styleSheets/contentFrame.css\" media=\"screen\">\n");
print("		<script language=\"javascript\" src=\"../../../perfStatResources/javaScripts/contentFrame.js\"></script>\n");
print("	</head>\n");

print("	<body>\n");
print("		<div class=\"navHeader\">\n");
my $formula0=$hostGroupName;print("			<a href=\"../level1/index.pl\">Host Groups:</a> $formula0</div>\n");
print("		<table width=\"100%\" cellpadding=\"2\" cellspacing=\"1\" border=\"0\" class=\"table1\">\n");
print("			<tr>\n");
print("				<td class=\"tdTop\" nowrap=\"nowrap\" colspan=\"3\" valign=\"middle\" align=\"left\">Host Status Report</td>\n");
print("			</tr>\n");
print("			<tr>\n");
print("				<th nowrap=\"nowrap\" width=\"48\" valign=\"middle\" align=\"center\">OS&nbsp;</th>\n");
print("				<th nowrap=\"nowrap\" width=\"10%\" valign=\"middle\" align=\"left\">Host Name</th>\n");
print("				<th nowrap=\"nowrap\" valign=\"middle\" align=\"left\">Current Status Details&nbsp;</th>\n");
print("			</tr>\n");
 foreach my $hostName (sort(keys(%$hostHash))) {
 my $hostDescHash = $hostHash->{$hostName};
 my $hasServices = $hostDescHash->{'hasServices'};
print("			<tr>\n");
my $formula1=$hostDescHash->{'OS'};print("				<td class=\"liteGray\" align=\"center\" valign=\"top\" height=\"50\" width=\"48\"><img src=\"../../../perfStatResources/images/osIcons/$formula1/icon.gif\" width=\"36\" height=\"38\" alt=\"No new posts\" title=\"No new posts\" /></td>\n");
print("				<td class=\"liteGray\" height=\"50\" nowrap=\"nowrap\" width=\"10%\" valign=\"top\" align=\"left\">\n");
 if ($hasServices == 0) {
my $formula2=$hostName;print("						<span class=\"table1Text1\">$formula2</span>\n");
 } else {
my $formula3=$sessionObj->param('hostGroupID');my $formula4=$hostName;my $formula5=$hostName;print("					<a href=\"../level3/index.pl?hostGroupID=$formula3&hostName=$formula4\" class=\"table1Text1\">$formula5</a>\n");
}
my $formula6=$hostDescHash->{'lastUpdate'};print("					<br><span class=\"table1Text2\">Last Update:<br>$formula6</span>\n");
print("				</td>\n");
print("				<td class=\"darkGray\" align=\"left\" valign=\"middle\" height=\"50\">\n");
print("					\n");
if ($hasServices == 0) {
print("					<table cellpadding=\"1\" cellspacing=\"1\" border=\"0\" class=\"table2\" width=\"100%\" >\n");
print("						<tr>\n");
print("							<td valign=\"middle\" align=\"left\" height=\"25\" style=\"text-align:left; padding-left: 8px\" nowrap>No status data found for host</td>\n");
print("						</tr>\n");
print("					</table>\n");
 } else {
my $hostServiceHash = $hostDescHash->{'hostServiceHash'};
print("					<table border=\"0\" cellpadding=\"2\" cellspacing=\"2\">\n");
print("						<tr>\n");
foreach my $hostServiceHashKey (sort(keys(%$hostServiceHash))) {
my $serviceDescHash = $hostServiceHash->{$hostServiceHashKey};
print("							<td width=\"40\" valign=\"top\" align=\"center\">\n");
if ($serviceDescHash->{'hasSubService'} != 1) {
print("								<table cellpadding=\"1\" cellspacing=\"1\" border=\"0\" class=\"table2\" height=\"0%\" width=\"100%\">\n");
print("									<tr>\n");
my $formula7=$hostServiceHashKey;print("										<th nowrap=\"nowrap\">$formula7</th>\n");
print("									</tr>\n");
print("									<tr>\n");
my $formula8=$sessionObj->param('hostGroupID');my $formula9=$hostName;my $formula10=$hostServiceHashKey;my $formula11=$serviceDescHash->{'status'};print("										<td valign=\"top\" align=\"center\"><a href=\"../level3/index.pl?hostGroupID=$formula8&hostName=$formula9&serviceName=$formula10\" class=\"table1Text1\"><img src=\"../../../perfStatResources/images/content/status_$formula11.gif\" width=\"20\" height=\"20\" /></a></td>\n");
print("									</tr>\n");
print("								</table>\n");
} else {
my $subServiceHash = $serviceDescHash->{'subServiceHash'};
print("								<table cellpadding=\"1\" cellspacing=\"1\" border=\"0\" class=\"table2\" width=\"100%\">\n");
print("									<tr>\n");
my $formula12=$hostName;my $formula13=$hostServiceHashKey;my $formula14=$hostName;my $formula15=$hostServiceHashKey;my $formula16=$hostName;my $formula17=$hostServiceHashKey;my $formula18=$hostServiceHashKey;print("										<th nowrap=\"nowrap\" valign=\"middle\" align=\"left\"><a href=\"javascript:toggle('$formula12-$formula13-off', '$formula14-$formula15-on');\"><img id=\"x$formula16-$formula17-off\" src=\"../../../perfStatResources/images/navigation/icon_plusNavBar.gif\" width=\"9\" height=\"9\" border=\"0\"></a>&nbsp;$formula18</th>\n");
print("									</tr>\n");
print("									<tr>\n");
print("										<td valign=\"top\" align=\"center\">\n");
my $formula19=$hostName;my $formula20=$hostServiceHashKey;print("											<div id=\"$formula19-$formula20-off\" style=\"display:block;\">\n");
my $formula21=$serviceDescHash->{'status'};print("												<img src=\"../../../perfStatResources/images/content/status_$formula21.gif\" width=\"20\" height=\"20\" /></div>\n");
my $formula22=$hostName;my $formula23=$hostServiceHashKey;print("											<div id=\"$formula22-$formula23-on\" style=\"display:none;\">\n");
print("												<table border=\"0\" cellpadding=\"1\" cellspacing=\"1\" class=\"table2\">\n");
foreach my $subServiceHashKey (sort(keys(%$subServiceHash))) {
print("													<tr>\n");
my $formula24=$sessionObj->param('hostGroupID');my $formula25=$hostName;my $formula26=$hostServiceHashKey;my $formula27=$subServiceHashKey;my $formula28=$subServiceHashKey;print("														<td style=\"text-align:right;\"><a href=\"../level3/index.pl?hostGroupID=$formula24&hostName=$formula25&serviceName=$formula26.$formula27\">$formula28</a></td>\n");
my $formula29=$subServiceHash->{$subServiceHashKey};print("														<td><img src=\"../../../perfStatResources/images/content/status_$formula29.gif\" width=\"20\" height=\"20\" /></td>\n");
print("													</tr>\n");
}
print("												</table>\n");
print("											</div>\n");
print("										</td>\n");
print("									</tr>\n");
print("								</table>\n");
 }
print("							</td>\n");
 }
print("						</tr>\n");
print("					</table>\n");
 }
print("				</td>\n");
print("			</tr>\n");
}
print("		</table>\n");
print("	</body>\n");
print("</html>\n");
