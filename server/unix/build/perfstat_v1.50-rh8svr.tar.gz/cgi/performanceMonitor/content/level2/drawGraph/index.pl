#!/usr/local/ActivePerl-5.8/bin/perl -w
use strict;
BEGIN
{
	unshift(@INC, "../../../..");
	require("app_globals.pl");
}

#use lib "/usr/local/rrdtool-1.0.35/lib/perl/";
use RRDs;
use vars qw($action $hostName $serviceName $graphName $period $graphWidth $graphHeight);

$request = new CGI;
$action = undef;
$action = $request->param('action');

require("act_initDrawGraph.pl");
require("act_drawGraph.pl");
