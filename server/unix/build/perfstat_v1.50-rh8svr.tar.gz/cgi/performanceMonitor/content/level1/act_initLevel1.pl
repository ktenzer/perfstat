use strict;
package main;

# CURRENT HOSTGROUP, HOSTNAME, SERVICENAME
checkAndSetHostGroupID(1);
if  (length($sessionObj->param("hostGroupID")) == 0) {
	# set default to allHosts
	$sessionObj->param("hostGroupID", "allHosts");
}
checkAndSetHostName(1);
checkAndSetServiceName(1);

# CURRENT graphSize, graphLayout
if (!defined($request->param("graphSize"))) {
	$graphSize = "medium";
} else {
	$graphSize = $request->param("graphSize");
}
if (!defined($request->param("graphLayout"))) {
	$graphLayout = "1";
} else {
	$graphLayout = $request->param("graphLayout");
}

# DEFINE HASH of host Groups to list
my $hostGroupArray = $userIndex->{$sessionObj->param("selectedAdmin")}->{$sessionObj->param("selectedUser")}->{hostGroups};
my $hostGroupArrayLen = @$hostGroupArray;
$hostGroupHash = {};
for (my $count1 = 0; $count1 < $hostGroupArrayLen; $count1++) {
	my $hostGroupObject = $hostGroupArray->[$count1];
	my $hostGroupName = $hostGroupObject->getName();
	$hostGroupHash->{$hostGroupName} = $count1;
}

# DEFINE ARRAY of hosts to list
$hostArray = [];
if ($sessionObj->param("hostGroupID") eq "allHosts") {
	#define array of allHosts
	$hostGroupName = "All Hosts";
	foreach my $host (sort(keys(%$hostIndex))) {
		my $hostObject = $hostIndex->{$host};
		my $owner = $hostObject->getOwner();
		if ($owner eq $sessionObj->param("selectedAdmin")) {
			push(@$hostArray, $host);
		}
	}
} else {
	my $hostGroup = $userIndex->{$sessionObj->param("selectedAdmin")}->{$sessionObj->param("selectedUser")}->{'hostGroups'}->[$sessionObj->param("hostGroupID")];
	$hostGroupName = $hostGroup->getName();
	$hostArray = $hostGroup->{'memberArray'};
}

if  (length($sessionObj->param("hostName")) == 0) {
	# set default to first host in sorted hostArray
	$sessionObj->param("hostName", $hostArray->[0]);
}

# DEFINE HASH of services
my $serviceHashRaw = {};
my $hostObject = $hostIndex->{$sessionObj->param("hostName")};
my $serviceIndex = $hostObject->{'serviceIndex'};
makeServiceHashRaw($serviceHashRaw, $serviceIndex);

if  (length($sessionObj->param("serviceName")) eq 0 && %$serviceHashRaw != 0) {
	# pick the first service and if necessary the first subservice
	my @serviceList = sort(keys(%$serviceHashRaw));
	$sessionObj->param("serviceName", $serviceList[0]);
}

$serviceHashRefined = {};
makeServiceHashRefined($serviceHashRaw, $serviceHashRefined);

###############################################################FUNCTIONS
#----------------------------------------------------------------------------------------------------- makeServiceHashRaw
sub makeServiceHashRaw {
	my ($rawHash, $serviceIndex) = @_;
	foreach my $fullServiceName (keys(%$serviceIndex)) {
		my $serviceObject = $serviceIndex->{$fullServiceName};
		my $graphHash =$serviceObject->{'graphHash'};
		if (%$graphHash != 0) {
			$rawHash->{$fullServiceName} = $graphHash;
		}
	}
}

#---------------------------------------------------------------------------------------------------- makeServiceHashRefined
sub makeServiceHashRefined {
	my ($rawHash, $refinedHash) = @_;
	my $previousServicePrefix = "";

	foreach my $fullServiceName (sort(keys(%$rawHash))) {
		my $prefix = $fullServiceName;
		$prefix =~ s/\..*//;
		if ($prefix ne $previousServicePrefix) {
			# new service or subservice
			if ($fullServiceName !~ m/\S+\.\S+/) {
				# if not subservice
				my $tempHash = {};
				$tempHash->{'hasSubService'} = 0;
				$tempHash->{'graphHash'} = $rawHash->{$fullServiceName};
				$refinedHash->{$prefix} = $tempHash;
				$previousServicePrefix = $prefix;
			} else {
				# if is first occurrence of subservice
				my $tempHash = {};
				my $suffix = $fullServiceName;
				$suffix =~ s/.*\.//;
				$tempHash->{'hasSubService'} = 1;
				$tempHash->{'subServiceHash'} = {};
				$tempHash->{'subServiceHash'}->{$suffix} = $rawHash->{$fullServiceName};
				$refinedHash->{$prefix} = $tempHash;
				$previousServicePrefix = $prefix;
			}
		} else {
			# next occurrence of previously entered subservice in newHash
			my $suffix = $fullServiceName;
			$suffix =~ s/^\w+\.//;
			$refinedHash->{$prefix}->{'subServiceHash'}->{$suffix} = $rawHash->{$fullServiceName};
		}
	}
}


1;