package main;
use strict;
use vars qw($perfhome $doParse $claimedSessionID $sessionObj $doStoreSessionObject $request $perfdIsUp $hostIndex $userIndex $osList);
BEGIN
{
	$perfhome = "/path/to/perfhome";
}
use CGI;
use CGI qw (:standard);
use CGI::Carp qw(carpout fatalsToBrowser warningsToBrowser);
# use CGI::Carp qw(carpout);
use CGI::Cookie;
use IO::File;
use Storable qw(lock_retrieve lock_store);

# Perfstat Modules
use lib "$perfhome/lib";
use User;
use HostGroup;
use ReportGroup;
use Host;
use Service;
use Metric;
use Graph;
use GraphMetric;

use PerfStatCGI::Parser;
use PerfStatCGI::Session;
use PerfStatCGI::Utilities;

# Set umask
umask(0007);

# Send error messages to log file
my $cgiLog = new IO::File;
$cgiLog->open(">>$perfhome/var/logs/cgi.log") || die("Unable to open cgi.log: $!\n");
carpout($cgiLog);

# GLOBALS
# $doParse:
# Parse html to perl file before requiring the perl file.
# Needed when developing or editing the HTML content with inline Perl
$doParse = 1;

# Session Management
$doStoreSessionObject = 1;

# Get the http request
$request = new CGI;

# Get the perfstatID cookie
my %cookies = fetch CGI::Cookie;

if (defined($cookies{'perfstatID'})) {
	$claimedSessionID = $cookies{'perfstatID'}->value;
}

if (!defined($cookies{'perfstatID'}) || !defined($claimedSessionID)) {
	# no perfstat cookie exists OR no cookie claimedSessionID exists (bad cookie)
	$sessionObj = new PerfStatCGI::Session(undef, undef, {Directory=>"$perfhome/var/sessions"});
	my $newSessionID = $sessionObj->id();
	$sessionObj->store();
	$doStoreSessionObject = 0;
	my $cookie = new CGI::Cookie(	-name => "perfstatID",
								-value   =>  "$newSessionID",
								-expires =>  "+1y");

	if ($ENV{SCRIPT_NAME} ne "/perfstat/login/index.pl") {
		my $perfstatLogin = "http://$ENV{SERVER_NAME}/perfstat/login/index.pl";
		print $request->header(	-status => "302 (Found) Moved Temporarily",
							-cookie => $cookie,
							-location => $perfstatLogin,
							-type => "text/html");
		CGI::Carp->warningsToBrowser(1);
	} else {
		print $request->header(	-cookie => $cookie );
		CGI::Carp->warningsToBrowser(1);
	}
} else {
	#perfstat cookie exist and claimedSessionID exists
	$sessionObj = new PerfStatCGI::Session(undef, $claimedSessionID, {Directory=>"$perfhome/var/sessions"});
	my $newSessionID = $sessionObj->id();
	my $isLoggedIn = $sessionObj->param("isLoggedIn");

	if ($newSessionID ne $claimedSessionID) {
		# claimedSessionID was corrupt or session was expired
		#Reset Session
		$sessionObj->store();
		$doStoreSessionObject = 0;
		my $cookie = new CGI::Cookie(	-name => "perfstatID",
									-value   =>  "$newSessionID",
									-expires =>  "+1y");

		if ($ENV{SCRIPT_NAME} ne "/perfstat/login/index.pl") {
			my $perfstatLogin = "http://$ENV{SERVER_NAME}/perfstat/login/index.pl";
			print $request->header(	-status => "302 (Found) Moved Temporarily",
								-cookie => $cookie,
								-location => $perfstatLogin,
								-type => "text/html");
			CGI::Carp->warningsToBrowser(1);
		} else {
			print $request->header(	-cookie => $cookie );
			CGI::Carp->warningsToBrowser(1);
		}
	} elsif (!(defined($isLoggedIn)) || $isLoggedIn != 1)  {
		# cookie claimedSessionID is not logged in
		$doStoreSessionObject = 0;
		if ($ENV{SCRIPT_NAME} ne "/perfstat/login/index.pl") {
			my $perfstatLogin = "http://$ENV{SERVER_NAME}/perfstat/login/index.pl";
			print $request->redirect($perfstatLogin);
			CGI::Carp->warningsToBrowser(1);
		} else {
			print $request->header();
			CGI::Carp->warningsToBrowser(1);
		}
	} else {
		# cookie claimedSessionID is OK and session is loggedIn
		if ($ENV{SCRIPT_NAME} ne "/perfstat/performanceMonitor/content/level2/drawGraph/index.pl") {
			print $request->header();
			CGI::Carp->warningsToBrowser(1);
		}
		#print $request->header();
		#CGI::Carp->warningsToBrowser(1);
		
		if ($ENV{SCRIPT_NAME} ne "/perfstat/header/index.pl") {
			
			#determine if perfd with its dynamic shared memory is up
			$perfdIsUp = 0;

			if ($perfdIsUp) {

			} else {
				# set userIndex from persistent memory
				setUserIndexFromDB($sessionObj->param("creator"), $sessionObj->param("userName"));
				
				# set hostIndex from persistent memory		
				setHostIndexFromDB($sessionObj->param("creator"), $sessionObj->param("userName"));
			}

			# set osList with names of all OSes perfstat currently configs
			setOSlist();			
		}	
	}
}

END
{
	if (defined($sessionObj) && $doStoreSessionObject == 1) {
		$sessionObj->store();
	}
}


######################################################## setUserIndex
sub setUserIndexFromDB {
	my ($creatorName, $userName) = @_;
	#create an empty userIndex
	$userIndex = {};

	#populate the keys of the hash with the hostNames
	opendir(STATEDIR, "$perfhome/var/db/users") or die("ERROR: Couldn't open dir $perfhome/var/db/users: $!\n");

	while (my $dirName = readdir(STATEDIR)) {
		if ($dirName ne "." && $dirName ne "..") {
			opendir(USERDIR, "$perfhome/var/db/users/$dirName") or die("WARNING: Couldn't open dir $perfhome/var/db/users/$dirName: $!\n");
			while (my $fileName = readdir(USERDIR)) {
				# Skip if file starts with a . and all reports.ser
				next if ($fileName =~ m/^\.\.?$/);
				next if ($fileName !~ m/$dirName\.ser/);
				my $userObject = lock_retrieve("$perfhome/var/db/users/$dirName/$fileName");
				die("WARNING: can't retrieve $perfhome/var/db/users/$dirName/$fileName\n") unless defined($userObject);
				
				my $creator = $userObject->getCreator();
				my $name = $userObject->getName();
				$userIndex -> {$creator} -> {$name}  = $userObject;
			}
			closedir(USERDIR);
		}
	}
	closedir(STATEDIR);
}

######################################################## setHostIndex
sub setHostIndexFromDB {
	my ($creatorName, $userName) = @_;
	
	#create an empty hostIndex
	$hostIndex = {};

	#populate the keys of the hash with the hostNames
	opendir(STATEDIR, "$perfhome/var/db/hosts") or die("ERROR: Couldn't open dir $perfhome/var/db/hosts: $!\n");

	while (my $hostName = readdir(STATEDIR)) {
		if ($hostName ne "." && $hostName ne "..") {
			$hostIndex->{$hostName} = undef;
		}
	}
	closedir(STATEDIR);
	
	### Populate each host key with a host object ###
	foreach my $hostName (keys(%$hostIndex)) {
		opendir(HOSTDIR, "$perfhome/var/db/hosts/$hostName") or die("WARNING: Couldn't open dir $perfhome/var/db/hosts/$hostName: $!\n");

		while (my $fileName = readdir(HOSTDIR)) {
			# Skip if file starts with a . and all service.ser
			next if ($fileName =~ m/^\.\.?$/);
			next if ($fileName !~ m/$hostName\.ser/);

			if ($fileName =~ /$hostName\.ser/) {
				#create host object by deserialization
				my $hostObject = lock_retrieve("$perfhome/var/db/hosts/$hostName/$fileName");
				die("WARNING: can't retrieve $perfhome/var/db/hosts/$hostName/$fileName\n") unless defined($hostObject);
				#assign host object to hostIndex
				$hostIndex->{$hostName} = $hostObject;
			} else {
				 warn "ERROR: Serialized host data not found for $hostName:$fileName while loading global data\n";
				exit(1);
			}
		}
		closedir(HOSTDIR);
	}

	### Populate each host key with a hash of all host services ###
	foreach my $hostName (keys(%$hostIndex)) {
		#create an empty serviceHash
		my $serviceHash = {};

		#populate empty serviceHash with service objects
		opendir(HOSTDIR, "$perfhome/var/db/hosts/$hostName") or die("WARNING: Couldn't open dir $perfhome/var/db/hosts/$hostName: $!\n");

		while (my $serviceName = readdir(HOSTDIR)) {
			# Skip if file starts with a . and the host.ser
			next if ($serviceName =~ m/^\.\.?$/);
			next if ($serviceName =~ m/$hostName\.ser/);

			if ($serviceName =~ /^([\S]+)\.ser$/) {
				#create service object by deserialization
				my $serviceObject = lock_retrieve("$perfhome/var/db/hosts/$hostName/$serviceName");
					die("WARNING: can't retriewe $perfhome/var/db/hosts/$hostName/$serviceName\n") unless defined($serviceObject);

				#assign service object to service hash
				$serviceHash->{$1} = $serviceObject;
			} else {
				warn "ERROR: Serialized service data not found for $hostName:$serviceName while loading global data\n";
				exit(1);
			}
		}
		closedir(HOSTDIR);
		#assign serviceHash to hostIndex
		$hostIndex->{$hostName}->{serviceIndex} = $serviceHash;
	}
}
######################################################## setOSlist
sub setOSlist {
	
	#create an empty hostIndex
	$osList = [];

	#populate the keys of the hash with the hostNames
	opendir(STATEDIR, "$perfhome/etc/configs") or die("ERROR: Couldn't open dir $perfhome/etc/configs: $!\n");
	while (my $osName = readdir(STATEDIR)) {
		if ($osName ne "." && $osName ne "..") {
			push (@$osList, $osName);
		}
	}
	closedir(STATEDIR);
}
1;
