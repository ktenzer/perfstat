#!/usr/bin/perl -w

use strict;



BEGIN

{

	unshift(@INC, "../..");

	require("app_globals.pl");

}



my $request = new CGI;

my $action = $request->param('action');



if ($action eq "level1")

{

	if ($doParse) {PerfStatCGI::Parser->html2Perl("dsp_level1.html");}

	require("dsp_level1.pl");

}

elsif ($action eq "level2")

{

	if ($doParse) {PerfStatCGI::Parser->html2Perl("dsp_level2.html");}

	require("dsp_level2.pl");

}

elsif ($action eq "level3")

{

	if ($doParse) {PerfStatCGI::Parser->html2Perl("dsp_level3.html");}

	require("dsp_level3.pl");

}

else #default action is display frame

{

	if ($doParse) {PerfStatCGI::Parser->html2Perl("dsp_level1.html");}

	require("dsp_level1.pl");

}