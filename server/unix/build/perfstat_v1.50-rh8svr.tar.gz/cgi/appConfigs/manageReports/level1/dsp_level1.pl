use strict;
package main;
print("<html>\n");
print("	<head>\n");
print("		<meta http-equiv=\"content-type\" content=\"text/html;charset=iso-8859-1\">\n");
print("		<title>PerfStat Tool: Perfomance Monitoring & Status Notification</title>\n");
print("		<link rel=\"stylesheet\" type=\"text/css\" href=\"../../../perfStatResources/styleSheets/contentFrame.css\" media=\"screen\">\n");
print("		<link rel=\"stylesheet\" type=\"text/css\" href=\"../../../perfStatResources/styleSheets/forms.css\" media=\"screen\">\n");
print("		<script language=\"javascript\" src=\"../../../perfStatResources/javaScripts/contentFrame.js\"></script>\n");
print("	</head>\n");

print("	<body>\n");
 if ($sessionObj->param("userName") eq "perfstat") {
print("		<table cellpadding=\"2\" cellspacing=\"1\" border=\"0\" class=\"table1\">\n");
print("			<tr>\n");
print("				<form action=\"index.pl\" method=\"post\">\n");
print("				<td nowrap=\"nowrap\" valign=\"middle\" align=\"right\"><span class=\"table1Text1\">Admin:</span></td>\n");
print("				<td nowrap=\"nowrap\" valign=\"middle\" align=\"left\">\n");
print("					<select name=\"adminName\" size=\"1\" onChange=\"submit();\">\n");
 foreach my $adminNameTemp (sort (keys(%$adminList))) {
my $formula1=$adminNameTemp;my $formula2=$adminNameTemp eq $adminName ? "selected" : "";;my $formula3=$adminNameTemp;print("						<option value=\"$formula1\" $formula2>$formula3</option>\n");
 }
print("					</select>\n");
print("				</td>\n");
print("				</form>\n");
print("			</tr>\n");
print("		</table>\n");
}
 if ($sessionObj->param("role") eq "admin") {
print("		<table cellpadding=\"2\" cellspacing=\"1\" border=\"0\" class=\"table1\">\n");
print("			<tr>\n");
print("				<form action=\"index.pl\" method=\"post\">\n");
my $formula1=$adminName;print("				<input type=\"hidden\" name=\"adminName\" value=\"$formula1\">\n");
print("				<td nowrap=\"nowrap\" valign=\"middle\" align=\"right\"><span class=\"table1Text1\">User:</span></td>\n");
print("				<td nowrap=\"nowrap\" valign=\"middle\" align=\"left\">\n");
print("					<select name=\"userName\" size=\"1\" onChange=\"submit();\">\n");
 foreach my $userNameTemp (sort (keys(%$userList))) {
my $formula1=$userNameTemp;my $formula2=$userNameTemp eq $userName ? "selected" : "";;my $formula3=$userNameTemp;print("						<option value=\"$formula1\" $formula2>$formula3</option>\n");
 }
print("					</select>\n");
print("				</td>\n");
print("				</form>\n");
print("			</tr>\n");
print("		</table>\n");
}
 if ($action ne "displayUpdateItem") {
 # updating, so display insert form 
print("		<table cellpadding=\"2\" cellspacing=\"1\" border=\"0\" class=\"table1\">\n");
print("			<tr>\n");
print("				<td class=\"tdTop\" nowrap=\"nowrap\" colspan=\"3\" valign=\"middle\" align=\"left\">Add Report Group</td>\n");
print("			</tr>\n");
 if ($sessionObj->param("userMessage") ne "") {
print("			<tr>\n");
my $formula1=$sessionObj->param("userMessage");print("				<td class=\"liteGray\" valign=\"top\" align=\"left\" colspan=\"3\"><span class=\"userMessage\">$formula1</span></td>\n");
print("			</tr>\n");
 $sessionObj->param("userMessage", "");
 }
print("			<tr>\n");
print("				<th nowrap=\"nowrap\" valign=\"middle\" align=\"left\">Report Group Name</th>\n");
print("				<th nowrap=\"nowrap\" valign=\"middle\" align=\"left\">Description</th>\n");
print("				<th nowrap=\"nowrap\">Actions</th>\n");
print("			</tr>\n");
print("			<tr>\n");
print("				<form name=\"insertItem\" action=\"index.pl\" method=\"get\">\n");
print("				<input type=\"hidden\" name=\"action\" value=\"insertItem\">\n");
my $formula1=$adminName;print("				<input type=\"hidden\" name=\"adminName\" value=\"$formula1\">\n");
my $formula1=$userName;print("				<input type=\"hidden\" name=\"userName\" value=\"$formula1\">\n");
my $formula1=$itemName;print("				<td class=\"liteGray\" align=\"left\" valign=\"middle\"><input type=\"text\" name=\"itemName\" value=\"$formula1\" size=\"24\"></td>\n");
my $formula1=$description;print("					<td class=\"liteGray\" nowrap=\"nowrap\" valign=\"middle\" align=\"left\"><input type=\"text\" name=\"description\" value=\"$formula1\" size=\"35\"></td>\n");
print("					<td class=\"darkGray\" align=\"center\" valign=\"middle\"><input class=\"liteButton\" type=\"submit\" value=\"ENTER\"></td>\n");
print("				</form>\n");
print("			</tr>\n");
print("		</table>\n");
} else {
 # updating, so don't display insert form, but do display update form
print("		<table cellpadding=\"2\" cellspacing=\"1\" border=\"0\" class=\"table1\">\n");
print("			<tr>\n");
print("				<td class=\"tdTop\" nowrap=\"nowrap\" colspan=\"3\" valign=\"middle\" align=\"left\">Modify Report Group</td>\n");
print("			</tr>\n");
 if ($sessionObj->param("userMessage") ne "") {
print("			<tr>\n");
my $formula1=$sessionObj->param("userMessage");print("				<td class=\"liteGray\" valign=\"top\" align=\"left\" colspan=\"3\"><span class=\"userMessage\">$formula1</span></td>\n");
print("			</tr>\n");
 $sessionObj->param("userMessage", "");
 }
print("			<tr>\n");
print("				<th nowrap=\"nowrap\" valign=\"middle\" align=\"left\">Report Group Name</th>\n");
print("				<th nowrap=\"nowrap\" valign=\"middle\" align=\"left\">Description</th>\n");
print("				<th nowrap=\"nowrap\">Actions</th>\n");
print("			</tr>\n");
print("			<tr>\n");
my $formula1=$itemID;print("				<form name=\"$formula1\" action=\"index.pl\" method=\"get\">\n");
print("				<input type=\"hidden\" name=\"action\" value=\"updateItem\">\n");
my $formula1=$adminName;print("				<input type=\"hidden\" name=\"adminName\" value=\"$formula1\">\n");
my $formula1=$userName;print("				<input type=\"hidden\" name=\"userName\" value=\"$formula1\">\n");
my $formula1=$itemID;print("				<input type=\"hidden\" name=\"itemID\" value=\"$formula1\">\n");
my $formula1=$itemName;print("				<td class=\"liteGray\" align=\"left\" valign=\"top\"><input type=\"text\" name=\"itemName\" value=\"$formula1\" size=\"24\"></td>\n");
my $formula1=$description;print("					<td class=\"liteGray\" nowrap=\"nowrap\" valign=\"top\" align=\"left\"><input type=\"text\" name=\"description\" value=\"$formula1\" size=\"35\"></td>\n");
print("					<td class=\"darkGray\" align=\"center\" valign=\"middle\">\n");
print("						<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\">\n");
print("							<tr>\n");
print("								<td nowrap=\"nowrap\"><input class=\"liteButton\" type=\"submit\" name=\"submit\" value=\"ENTER\"></td>\n");
print("								<td nowrap=\"nowrap\"><input class=\"liteButton\" type=\"submit\" name=\"submit\" value=\"CLEAR\"></td>\n");
print("							</tr>\n");
print("						</table>\n");
print("					</td>\n");
print("				</form>\n");
print("			</tr>\n");
print("		</table>\n");
} 
 if ($reportGroupHashLen != 0) {		
print("		<table cellpadding=\"2\" cellspacing=\"1\" border=\"0\" class=\"table1\" width=\"100%\">\n");
print("			<tr>\n");
print("				<td class=\"tdTop\" nowrap=\"nowrap\" valign=\"middle\" align=\"left\" colspan=\"3\">Manage Host Groups</td>\n");
print("			</tr>\n");
print("			<tr>\n");
print("				<th nowrap=\"nowrap\" valign=\"middle\" align=\"left\" width=\"10\">Actions</th>\n");
print("				<th nowrap=\"nowrap\" valign=\"middle\" align=\"left\">Report Group Name</th>\n");
print("				<th nowrap=\"nowrap\" valign=\"middle\" align=\"left\">Description</th>\n");
print("			</tr>\n");
 foreach my $reportGroupKey (sort(keys(%$reportGroupHash))) {
my $tempName = $reportGroupKey;
my $tempID = $reportGroupHash->{$reportGroupKey}->[0];
my $tempDescription = $reportGroupHash->{$reportGroupKey}->[1];
print("			<tr>\n");
print("				<td class=\"liteGray\" align=\"left\" valign=\"top\" width=\"10\">\n");
print("					<table cellpadding=\"1\" cellspacing=\"1\" border=\"0\" class=\"table2\">\n");
print("						<tr>\n");
$queryString = "&adminName=$adminName&userName=$userName&itemID=$tempID&itemName=" . $tempName . "&description=" . $tempDescription;
my $formula1=$queryString;print("								<th nowrap=\"nowrap\"><a href=\"index.pl?action=displayUpdateItem$formula1\">Modify</th>\n");
my $formula1=$adminName;my $formula2=$userName;my $formula3=$tempID;my $formula4=$tempName;print("								<th nowrap=\"nowrap\"><a href=\"../level2/index.pl?adminName=$formula1&userName=$formula2&itemID=$formula3&itemName=$formula4\">Config</a></th>\n");
my $formula1=$adminName;my $formula2=$userName;my $formula3=$tempID;my $formula4=$tempName;print("								<th nowrap=\"nowrap\"><a href=\"index.pl?action=deleteItem&adminName=$formula1&userName=$formula2&itemID=$formula3\" onclick=\"return warnOnClickAnchor('Are you sure you want to delete $formula4');\">Delete</a></th>\n");
print("						</tr>\n");
print("					</table>\n");
print("				</td>\n");
my $formula1=$tempName;print("				<td class=\"liteGray\" align=\"left\" valign=\"top\"><span class=\"table1Text1\"><span class=\"table1Text1\">$formula1</span></td>\n");
my $formula1=$tempDescription;print("				<td class=\"liteGray\" nowrap=\"nowrap\" valign=\"top\" align=\"left\"><span class=\"table1Text2\">$formula1</span></td>\n");
print("			</tr>\n");
}
print("		</table>\n");
} else {
print("			<table cellpadding=\"2\" cellspacing=\"1\" border=\"0\" class=\"table1\" width=\"100%\">\n");
print("			<tr>\n");
print("				<td class=\"tdTop\" nowrap=\"nowrap\" valign=\"middle\" align=\"left\" colspan=\"2\">Manage Host Groups</td>\n");
print("			</tr>\n");
print("			<tr>\n");
print("				<th nowrap=\"nowrap\" valign=\"middle\" align=\"left\">Report Group Name</th>\n");
print("				<th nowrap=\"nowrap\" valign=\"middle\" align=\"left\">Description</th>\n");
print("			</tr>\n");
print("			<tr>\n");
print("				<td class=\"liteGray\" align=\"left\" valign=\"top\"><span class=\"table1Text1\"><span class=\"table1Text1\">&nbsp;</span></td>\n");
print("				<td class=\"liteGray\" nowrap=\"nowrap\" valign=\"top\" align=\"left\"><span class=\"table1Text2\">&nbsp</span></td>\n");
print("			</tr>\n");
print("		</table>\n");
}
print("	</body>\n");
print("</html>\n");
