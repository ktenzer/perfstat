#!/usr/bin/perl -w
use strict;

BEGIN
{
	unshift(@INC, "../../..");
	require("app_globals.pl");
}

use vars qw($action $adminName $userName $itemID $item2ID $itemName $reportHashLen $reportGroupMemberHash $reportGroupMemberHashLen $selectName $queryString);

$request = new CGI;
$action = "";
$action = $request->param('action');

if ($action eq "insertItem")
{
	require("act_insertItem.pl");
	metaRedirect(0, "index.pl?$queryString");
}
elsif ($action eq "deleteItem")
{
	require("act_deleteItem.pl");
	metaRedirect(0, "index.pl?$queryString");
}
else #default action is display frame
{
	if ($doParse) {PerfStatCGI::Parser->html2Perl("dsp_level2.html");}
	require("act_initLevel2.pl");
	require("dsp_level2.pl");
}