use strict;
package main;
print("<html>\n");
print("<head>\n");
print("	<meta http-equiv=\"content-type\" content=\"text/html;charset=iso-8859-1\">\n");
print("	<title>PerfStat Tool: Status And Performance Monitoring</title>\n");
print("	<link rel=\"stylesheet\" type=\"text/css\" href=\"../../../perfStatResources/styleSheets/contentFrame.css\" media=\"screen\">\n");
print("	<link rel=\"stylesheet\" type=\"text/css\" href=\"../../../perfStatResources/styleSheets/forms.css\" media=\"screen\">\n");
print("	<script language=\"javascript\" src=\"../../../perfStatResources/javaScripts/contentFrame.js\"></script>\n");
print("</head>\n");

print("<body>\n");
print("	<div class=\"navHeader\">\n");
my $formula1=$adminName;my $formula2=$itemName;print("		<a href=\"../level1/index.pl?adminName=$formula1\">Manage Hosts</a>: $formula2\n");
print("	</div>\n");
print("	<table width=\"100%\" cellpadding=\"2\" cellspacing=\"1\" border=\"0\" class=\"table1\">\n");
print("			<tr>\n");
print("			<td class=\"tdTop\" nowrap=\"nowrap\" valign=\"middle\" align=\"left\">Config Services</td>\n");
print("		</tr>\n");
print("			<tr>\n");
print("			<td class=\"darkGray\" align=\"left\" valign=\"top\">\n");
print("				<table border=\"0\" cellpadding=\"2\" cellspacing=\"2\">\n");
print("					<tr>	\n");
 foreach my $serviceHashKey (sort(keys(%$serviceHash))) {
 my $tempServiceHash = $serviceHash->{$serviceHashKey};				
 if ($tempServiceHash->{'hasSubService'} != 1) {
print("							<td width=\"40\" valign=\"top\" align=\"center\">	\n");
print("								<table cellpadding=\"1\" cellspacing=\"1\" border=\"0\" class=\"table2\" height=\"0%\" width=\"100%\">\n");
print("									<tr>\n");
my $formula1=$adminName;my $formula2=$itemName;my $formula3=$serviceHashKey;my $formula4=$serviceHashKey;print("										<th nowrap=\"nowrap\"><a href=\"index.pl?action=selectMetricConfig&adminName=$formula1&itemName=$formula2&serviceName=$formula3\">$formula4</a></th>\n");
print("									</tr>\n");
print("								</table>\n");
print("							</td>\n");
 } else {
 my $tempSubServiceHash = $tempServiceHash->{'subServiceHash'};
print("							<td width=\"40\" valign=\"top\" align=\"center\">	\n");
my $formula1=$serviceHashKey;print("								<div id=\"$formula1-off\" style=\"display:block;\">\n");
print("								<table cellpadding=\"1\" cellspacing=\"1\" border=\"0\" class=\"table2\" width=\"100%\">\n");
print("									<tr>\n");
my $formula1=$serviceHashKey;my $formula2=$serviceHashKey;my $formula3=$serviceHashKey;my $formula4=$serviceHashKey;print("										<th nowrap=\"nowrap\">$formula1&nbsp;<a href=\"javascript:toggle('$formula2-off', '$formula3-on');\"><img id=\"x$formula4-off\" src=\"../../../perfStatResources/images/navigation/icon_plusNavBar.gif\" width=\"9\" height=\"9\" border=\"0\"></a></th>\n");
print("									</tr>\n");
print("								</table>\n");
print("								</div>\n");
my $formula1=$serviceHashKey;print("								<div id=\"$formula1-on\" style=\"display:none;\">\n");
print("								<table cellpadding=\"1\" cellspacing=\"1\" border=\"0\" class=\"table2\" width=\"100%\">\n");
print("									<tr>\n");
my $formula1=$serviceHashKey;my $formula2=$serviceHashKey;my $formula3=$serviceHashKey;my $formula4=$serviceHashKey;print("										<th nowrap=\"nowrap\">$formula1&nbsp;<a href=\"javascript:toggle('$formula2-off', '$formula3-on');\"><img id=\"x$formula4-on\" src=\"../../../perfStatResources/images/navigation/icon_minusNavBar.gif\" width=\"9\" height=\"9\" border=\"0\"></a></th>\n");
print("									</tr>\n");
print("									<tr>\n");
print("										<td valign=\"top\" align=\"center\">\n");
print("											<table border=\"0\" cellpadding=\"1\" cellspacing=\"1\" class=\"table2\">\n");
 foreach my $tempSubServiceHashKey (sort(keys(%$tempSubServiceHash))) {
print("												<tr>\n");
my $formula1=$adminName;my $formula2=$itemName;my $formula3=$serviceHashKey;my $formula4=$tempSubServiceHashKey;my $formula5=$tempSubServiceHashKey;print("													<td style=\"text-align:right;\"><a href=\"index.pl?action=selectMetricConfig&adminName=$formula1&itemName=$formula2&serviceName=$formula3.$formula4\">$formula5</a></td>\n");
print("												</tr>\n");
 }
print("											</table>\n");
print("										</td>\n");
print("									</tr>\n");
print("								</table>\n");
print("								</div>\n");
print("							</td>\n");
 }	
 }
print("					</tr>\n");
print("				</table>\n");
print("			</td>\n");
print("		</tr>\n");
print("		</table>\n");
 if (length($serviceName) != 0) {
print("			<div align=\"center\">\n");
print("				<form name=\"configMetrics\" action=\"index.pl\" method=\"get\">\n");
print("					<input type=\"hidden\" name=\"action\" value=\"setMetricThresholds\">\n");
my $formula1=$adminName;print("					<input type=\"hidden\" name=\"adminName\" value=\"$formula1\">\n");
my $formula1=$itemName;print("					<input type=\"hidden\" name=\"itemName\" value=\"$formula1\">\n");
my $formula1=$serviceName;print("					<input type=\"hidden\" name=\"serviceName\" value=\"$formula1\">\n");
print("					<table cellpadding=\"2\" cellspacing=\"1\" border=\"0\" class=\"table1\">\n");
print("						<tr>\n");
my $formula1=$serviceName;print("							<td class=\"tdTop\" nowrap=\"nowrap\" colspan=\"5\" valign=\"middle\" align=\"left\">$formula1</td>\n");
print("						</tr>\n");
 if ($sessionObj->param("userMessage") ne "") {
print("						<tr>\n");
my $formula1=$sessionObj->param("userMessage");print("							<td class=\"liteGray\" valign=\"top\" align=\"left\" colspan=\"5\"><span class=\"userMessage\">$formula1</span></td>\n");
print("							</tr>\n");
 $sessionObj->param("userMessage", "");
 }
 if (exists($eventHash->{$serviceName})) {
print("						<tr>\n");
print("							<th nowrap=\"nowrap\" valign=\"middle\" align=\"left\">Metric</th>\n");
print("							<th nowrap=\"nowrap\" valign=\"middle\" align=\"left\">Warn</th>\n");
print("							<th nowrap=\"nowrap\" valign=\"middle\" align=\"left\">Crit</th>\n");
print("							<th nowrap=\"nowrap\" valign=\"middle\" align=\"left\">Unit</th>\n");
print("							<th nowrap=\"nowrap\" valign=\"middle\" align=\"left\">Events</th>\n");
print("						</tr>\n");
print("\n");
 for (my $count = 0; $count < $serviceMetricArrayLen; $count++) {
 my $metricObject = $serviceMetricArray->[$count];
 my $hasEvents = $metricObject->getHasEvents();
 #my $hasEvents = 0;
 if ($hasEvents == 1) {
 my $friendlyName = $metricObject->getFriendlyName();
 my $warnThreshold = $metricObject->getWarnThreshold();
 my $critThreshold = $metricObject->getCritThreshold();
 my $thresholdUnit = $metricObject->getThresholdUnit();
print("								<tr>\n");
my $formula1=$friendlyName;print("									<td class=\"liteGray\" nowrap=\"nowrap\" valign=\"top\" align=\"left\"><span class=\"table1Text2\">$formula1</td>\n");
my $formula1=$count;my $formula2=$warnThreshold;print("									<td class=\"liteGray\" valign=\"top\" align=\"left\"><input type=\"text\" name=\"warnThreshold_$formula1\" size=\"10\" value=\"$formula2\"></td>\n");
my $formula1=$count;my $formula2=$critThreshold;print("									<td class=\"liteGray\" valign=\"top\" align=\"left\"><input type=\"text\" name=\"critThreshold_$formula1\" size=\"10\" value=\"$formula2\"></td>\n");
my $formula1=$count;my $formula2=$thresholdUnit;print("									<td class=\"liteGray\" valign=\"top\" align=\"left\"><input type=\"text\" name=\"thresholdUnit_$formula1\" size=\"10\" value=\"$formula2\"></td>\n");
my $formula1=$count;print("									<td class=\"liteGray\" valign=\"top\" align=\"middle\"><input type=\"checkbox\" name=\"hasEvents_$formula1\" size=\"10\" CHECKED></td>\n");
#<td class="liteGray" valign="top" align="middle"><input type="checkbox" name="hasEvents_<%$count%>" size="10" value="<%$hasEvents%>" CHECKED></td>
print("								</tr>\n");
 } elsif ($hasEvents == 0) {
 my $friendlyName = $metricObject->getFriendlyName();
 my $warnThreshold = $metricObject->getWarnThreshold();
 my $critThreshold = $metricObject->getCritThreshold();
 my $thresholdUnit = $metricObject->getThresholdUnit();
print("\n");
print("								<tr>\n");
my $formula1=$friendlyName;print("									<td class=\"liteGray\" nowrap=\"nowrap\" valign=\"top\" align=\"left\"><span class=\"table1Text2\">$formula1</td>\n");
my $formula1=$warnThreshold;print("									<td class=\"liteGray\" nowrap=\"nowrap\" valign=\"top\" align=\"left\"><span class=\"table1Text2\">$formula1</td>\n");
my $formula1=$critThreshold;print("									<td class=\"liteGray\" nowrap=\"nowrap\" valign=\"top\" align=\"left\"><span class=\"table1Text2\">$formula1</td>\n");
my $formula1=$thresholdUnit;print("									<td class=\"liteGray\" nowrap=\"nowrap\" valign=\"top\" align=\"left\"><span class=\"table1Text2\">$formula1</td>\n");
my $formula1=$count;print("									<td class=\"liteGray\" valign=\"top\" align=\"middle\"><input type=\"checkbox\" name=\"hasEvents_$formula1\" size=\"10\"></td>\n");
#<td class="liteGray" valign="top" align="middle"><input type="checkbox" name="hasEvents_<%$count%>" size="10" value="<%$hasEvents%>"></td>
print("								</tr>\n");
}
 }
print("						\n");
print("						<tr>\n");
print("							<td class=\"liteGray\" valign=\"top\" align=\"right\" colspan=\"5\"><input class=\"liteButton\" type=\"submit\" name=\"Update\" value=\"update\"></td>\n");
print("						</tr>\n");
print("					\n");
 } else {
print("						<tr>\n");
#<th nowrap="nowrap" valign="middle" align="left"><font color="red">No configurable metrics found</font></th>
print("						<td class=\"liteGray\" valign=\"top\" align=\"left\"><span class=\"userMessage\"></span>No configurable metrics found</td>\n");
print("					</tr>\n");
print("	\n");
 }
print("\n");
print("				</table>\n");
print("			</form>\n");
print("		</div>\n");
 }
print("	</body>\n");
print("</html>\n");
