use strict;
package main;
print("<html>\n");
print("	<head>\n");
print("		<meta http-equiv=\"content-type\" content=\"text/html;charset=iso-8859-1\">\n");
print("		<title>PerfStat Tool: Perfomance Monitoring & Status Notification</title>\n");
print("		<link rel=\"stylesheet\" type=\"text/css\" href=\"../../../perfStatResources/styleSheets/contentFrame.css\" media=\"screen\">\n");
print("		<link rel=\"stylesheet\" type=\"text/css\" href=\"../../../perfStatResources/styleSheets/forms.css\" media=\"screen\">\n");
print("		<script language=\"javascript\" src=\"../../../perfStatResources/javaScripts/contentFrame.js\"></script>\n");
print("	</head>\n");

print("	<body>\n");
 if ($sessionObj->param("creator") eq "perfstat") {
print("		<table cellpadding=\"2\" cellspacing=\"1\" border=\"0\" class=\"table1\">\n");
print("			<tr>\n");
print("				<form action=\"index.pl\" method=\"post\">\n");
print("				<td nowrap=\"nowrap\" valign=\"middle\" align=\"right\"><span class=\"table1Text1\">Admin:</span></td>\n");
print("				<td nowrap=\"nowrap\" valign=\"middle\" align=\"left\">\n");
print("					<select name=\"adminName\" size=\"1\" onChange=\"submit();\">\n");
 foreach my $adminNameTemp (sort (keys(%$adminList))) {
my $formula0=$adminNameTemp;my $formula1=$adminNameTemp eq $adminName ? "selected" : "";;my $formula2=$adminNameTemp;print("						<option value=\"$formula0\" $formula1>$formula2</option>\n");
 }
print("					</select>\n");
print("				</td>\n");
print("				</form>\n");
print("			</tr>\n");
print("		</table>\n");
}
 if ($sessionObj->param("role") eq "admin") {
 if ($action ne "displayUpdateItem") {
 # Admin is not updating, so display insert form 
print("		<table cellpadding=\"2\" cellspacing=\"1\" border=\"0\" class=\"table1\">\n");
print("			<tr>\n");
print("				<td class=\"tdTop\" nowrap=\"nowrap\" colspan=\"4\" valign=\"middle\" align=\"left\">Add Host</td>\n");
print("			</tr>\n");
 if ($sessionObj->param("userMessage") ne "") {
print("			<tr>\n");
my $formula3=$sessionObj->param("userMessage");print("				<td class=\"liteGray\" valign=\"top\" align=\"left\" colspan=\"4\"><span class=\"userMessage\">$formula3</span></td>\n");
print("			</tr>\n");
 $sessionObj->param("userMessage", "");
 }
print("			<tr>\n");
print("				<th nowrap=\"nowrap\" valign=\"middle\" align=\"left\">Host Name</th>\n");
print("				<th nowrap=\"nowrap\" valign=\"middle\" align=\"left\">IP</th>\n");
print("				<th nowrap=\"nowrap\" valign=\"top\" align=\"left\">OS</th>\n");
print("				<th nowrap=\"nowrap\">Actions</th>\n");
print("			</tr>\n");
print("			<tr>\n");
print("				<form name=\"insertItem\" action=\"index.pl\" method=\"get\">\n");
print("				<input type=\"hidden\" name=\"action\" value=\"insertItem\">\n");
my $formula4=$adminName;print("				<input type=\"hidden\" name=\"adminName\" value=\"$formula4\">\n");
my $formula5=$itemName;print("				<td class=\"liteGray\" align=\"left\" valign=\"middle\"><input type=\"text\" name=\"itemName\" value=\"$formula5\" size=\"24\"></td>\n");
my $formula6=$ipAddress;print("				<td class=\"liteGray\" nowrap=\"nowrap\" valign=\"middle\" align=\"left\"><input type=\"text\" name=\"ipAddress\" value=\"$formula6\" size=\"24\"></td>\n");
print("				<td class=\"liteGray\" align=\"left\" valign=\"middle\">\n");
print("					<select name=\"osName\" size=\"1\">\n");
 foreach my $osNameTemp (sort( @$osList)) {
my $formula7=$osNameTemp;my $formula8=$osNameTemp eq $osName ? "selected" : "";;my $formula9=$osNameTemp;print("							<option value=\"$formula7\" $formula8>$formula9</option>\n");
}
print("					</select>\n");
print("				</td>\n");
print("				<td class=\"darkGray\" align=\"center\" valign=\"middle\"><input class=\"liteButton\" type=\"submit\" value=\"ENTER\"></td>\n");
print("				</form>\n");
print("			</tr>\n");
print("		</table>\n");
} else {
 # Admin is updating, so don't display insert form, but do display update form
print("		<table cellpadding=\"2\" cellspacing=\"1\" border=\"0\" class=\"table1\">\n");
print("			<tr>\n");
print("				<td class=\"tdTop\" nowrap=\"nowrap\" colspan=\"4\" valign=\"middle\" align=\"left\">Modify Host</td>\n");
print("			</tr>\n");
 if ($sessionObj->param("userMessage") ne "") {
print("			<tr>\n");
my $formula10=$sessionObj->param("userMessage");print("				<td class=\"liteGray\" valign=\"top\" align=\"left\" colspan=\"4\"><span class=\"userMessage\">$formula10</span></td>\n");
print("			</tr>\n");
 $sessionObj->param("userMessage", "");
 }
print("			<tr>\n");
print("				<th nowrap=\"nowrap\" valign=\"middle\" align=\"left\">Host Name</th>\n");
print("				<th nowrap=\"nowrap\" valign=\"middle\" align=\"left\">IP</th>\n");
print("				<th nowrap=\"nowrap\" valign=\"top\" align=\"left\">OS</th>\n");
print("				<th nowrap=\"nowrap\">Actions</th>\n");
print("			</tr>\n");
print("			<tr>\n");
my $formula11=$itemID;print("				<form name=\"$formula11\" action=\"index.pl\" method=\"get\">\n");
print("				<input type=\"hidden\" name=\"action\" value=\"updateItem\">\n");
my $formula12=$adminName;print("				<input type=\"hidden\" name=\"adminName\" value=\"$formula12\">\n");
my $formula13=$itemID;print("				<input type=\"hidden\" name=\"itemID\" value=\"$formula13\">\n");
my $formula14=$itemName;print("				<td class=\"liteGray\" align=\"left\" valign=\"top\"><input type=\"text\" name=\"itemName\" value=\"$formula14\" size=\"24\"></td>\n");
my $formula15=$ipAddress;print("				<td class=\"liteGray\" nowrap=\"nowrap\" valign=\"top\" align=\"left\"><input type=\"text\" name=\"ipAddress\" value=\"$formula15\" size=\"24\"></td>\n");
print("					<td class=\"liteGray\" align=\"left\" valign=\"middle\">\n");
print("						<select name=\"osName\" size=\"1\">\n");
 foreach my $osNameTemp (sort( @$osList)) {
my $formula16=$osNameTemp;my $formula17=$osNameTemp eq $osName ? "selected" : "";;my $formula18=$osNameTemp;print("							<option value=\"$formula16\" $formula17>$formula18</option>\n");
}
print("					</select>\n");
print("					</td>\n");
print("					<td class=\"darkGray\" align=\"center\" valign=\"middle\">\n");
print("						<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" >\n");
print("							<tr>\n");
print("								<td nowrap=\"nowrap\"><input class=\"liteButton\" type=\"submit\" name=\"submit\" value=\"ENTER\"></td>\n");
print("								<td nowrap=\"nowrap\"><input class=\"liteButton\" type=\"submit\" name=\"submit\" value=\"CLEAR\"></td>\n");
print("							</tr>\n");
print("						</table>\n");
print("					</td>\n");
print("				</form>\n");
print("			</tr>\n");
print("		</table>\n");
}
}
 if ($sessionObj->param("role") eq "admin" && $lenHostArray > 0) {
print("		<table cellpadding=\"2\" cellspacing=\"1\" border=\"0\" class=\"table1\" width=\"100%\">\n");
print("			<tr>\n");
my $formula19=$sessionObj->param("role") eq "admin" ? "Manage" : "View";print("				<td class=\"tdTop\" nowrap=\"nowrap\" valign=\"middle\" align=\"left\" colspan=\"4\">$formula19 Hosts</td>\n");
print("			</tr>\n");
print("			<tr>\n");
print("				<th nowrap=\"nowrap\" valign=\"middle\" align=\"left\" width=\"10\">Actions</th>\n");
print("				<th nowrap=\"nowrap\" valign=\"middle\" align=\"left\">Host Name</th>\n");
print("				<th nowrap=\"nowrap\" valign=\"middle\" align=\"left\">IP</th>\n");
print("				<th nowrap=\"nowrap\" valign=\"middle\" align=\"left\">OS</th>\n");
print("			</tr>\n");
 foreach my $tempArray (@$hostArray) {
print("			<tr>\n");
print("				<td class=\"liteGray\" align=\"left\" valign=\"top\" width=\"10\">\n");
print("					<table cellpadding=\"1\" cellspacing=\"1\" border=\"0\" class=\"table2\">\n");
print("						<tr>\n");
$queryString = "&adminName=$adminName&itemID=$tempArray->[0]&itemName=$tempArray->[0]&ipAddress=$tempArray->[1]&osName=$tempArray->[2]";
my $formula20=$queryString;print("								<th nowrap=\"nowrap\"><a href=\"index.pl?action=displayUpdateItem$formula20\">Modify</th>\n");
my $formula21=$adminName;my $formula22=$tempArray->[0];print("								<th nowrap=\"nowrap\"><a href=\"../level2/index.pl?adminName=$formula21&itemName=$formula22\">Config</a></th>\n");
my $formula23=$adminName;my $formula24=$tempArray->[0];my $formula25=$tempArray->[0];print("								<th nowrap=\"nowrap\"><a href=\"index.pl?action=deleteItem&adminName=$formula23&itemName=$formula24\" onclick=\"return warnOnClickAnchor('Are you sure you want to delete $formula25');\">Delete</a></th>\n");
print("						</tr>\n");
print("					</table>\n");
print("				</td>\n");
my $formula26=$tempArray->[0];print("				<td class=\"liteGray\" align=\"left\" valign=\"top\"><span class=\"table1Text1\"><span class=\"table1Text1\">$formula26</span></td>\n");
my $formula27=$tempArray->[1];print("				<td class=\"liteGray\" nowrap=\"nowrap\" valign=\"top\" align=\"left\"><span class=\"table1Text2\">$formula27</span></td>\n");
my $formula28=$tempArray->[2];print("				<td class=\"liteGray\" align=\"left\" valign=\"middle\"><span class=\"table1Text2\">$formula28</span></td>\n");
print("			</tr>\n");
}
print("		</table>\n");
} else {
print("			<table cellpadding=\"2\" cellspacing=\"1\" border=\"0\" class=\"table1\" width=\"100%\">\n");
print("			<tr>\n");
my $formula29=$sessionObj->param("role") eq "admin" ? "Manage" : "View";print("				<td class=\"tdTop\" nowrap=\"nowrap\" valign=\"middle\" align=\"left\" colspan=\"4\">$formula29 Hosts</td>\n");
print("			</tr>\n");
print("			<tr>\n");
print("				<th nowrap=\"nowrap\" valign=\"middle\" align=\"left\">Host Name</th>\n");
print("				<th nowrap=\"nowrap\" valign=\"middle\" align=\"left\">IP</th>\n");
print("				<th nowrap=\"nowrap\" valign=\"middle\" align=\"left\">OS</th>\n");
print("			</tr>\n");
 foreach my $tempArray (@$hostArray) {
print("			<tr>\n");
my $formula30=$tempArray->[0];print("				<td class=\"liteGray\" align=\"left\" valign=\"top\"><span class=\"table1Text1\"><span class=\"table1Text1\">$formula30</span></td>\n");
my $formula31=$tempArray->[1];print("				<td class=\"liteGray\" nowrap=\"nowrap\" valign=\"top\" align=\"left\"><span class=\"table1Text2\">$formula31</span></td>\n");
my $formula32=$tempArray->[2];print("				<td class=\"liteGray\" align=\"left\" valign=\"middle\"><span class=\"table1Text2\">$formula32</span></td>\n");
print("			</tr>\n");
}
print("		</table>\n");
}
print("	</body>\n");
print("</html>\n");
