use strict;
package main;
require("lib_inputCheck.pl");

# init message variables
$sessionObj->param("userMessage", "");
my $errorMessage = "";

if ($sessionObj->param("userName") eq "perfstat") {
	# Login is perfstat admin
	$adminName = $request->param('adminName');
	checkAdminName($adminName);
	$itemName = $request->param('itemName');
	securityCheckItemName($adminName, $itemName);

	deleteItem($adminName, $itemName);
	$queryString =	"action=clearItem" .	
						"&adminName=". URLEncode($adminName) .
						"&itemName=" . URLEncode($itemName);

} elsif ($sessionObj->param("role") eq "admin") {
	# Login is group admin
	$adminName = $sessionObj->param("userName");
	checkAdminName($adminName);
	$itemName = $request->param('itemName');
	securityCheckItemName($adminName, $itemName);

	deleteItem($adminName, $itemName);
	$queryString = 	"action=clearItem" .	
						"&adminName=". URLEncode($adminName) .
						"&itemName=" . URLEncode($itemName);
	
} else {
	# Login is user
	die('ERROR: invalid value for $sessionObj->param("role")')
}

################################################### SUBROUTINES
#DELETE HOST
sub deleteItem {
	my ($adminName, $hostName) = @_;
	
	# ADD PERSISTENT MEMORY
	# List of directories that need to be removed
	my @dirs=qw(rrd var/db/hosts var/status var/events tmp/events);

	foreach my $dir (@dirs) {

		next if (! -d "$perfhome/$dir/$hostName");

		# Unlink all files under host dir
		opendir(DIR, "$perfhome/$dir/$hostName")
			or die("ERROR: Couldn't open dir $perfhome/$dir/$hostName: $!\n");

		while (my $fileName = readdir(DIR)) {
			next if ($fileName =~ m/^\.|^\.\./);
			unlink "$perfhome/$dir/$hostName/$fileName"
				or die "Couldn't remove file $perfhome/$dir/$hostName/$fileName!\n";
		}

		closedir(DIR);

		# Remove State Dir if it exists
		if ( -d "$perfhome/$dir/$hostName" ) {
			rmdir "$perfhome/$dir/$hostName" or die "WARNING: Cannot rmdir $perfhome/$dir/$hostName: $!\n";
		}
	}

	# DELETE SHARED MEMORY (If Appropriate)
	if ($perfdIsUp) {
		# Thaw/Freeze hostObject to Shared Memory
	}
}

1;