#  input check functions
sub checkAdminName {
	my ($adminName) = @_;
	if (length($adminName) == 0) {die('Error: missing required value for $adminName');}
	if(!(-d "$perfhome/var/db/users/$adminName")) {die('Error: invalid value for $adminName: no user directory');}
	if(!(-e "$perfhome/var/db/users/$adminName/$adminName.ser")) {die('Error: invalid value for $adminName: no user file');}
	if (!(exists( $userIndex->{$adminName}->{$adminName}))) {die('Error: invalid value for $adminName');}
}

sub checkOSName {
	my ($osName) = @_;
	my $osListLen = @$osList;
	my $osFound = 0;
	for ($osCount = 0; $osFound == 0 && $osCount < $osListLen; $osCount++) {
		if ($osList->[$osCount] eq $osName) {
			$osFound = 1;
		}
	} 
	if ($osFound == 0) { die('Error: invalid value for $osName'); }
}

sub securityCheckItemID {
	my ($adminName, $itemID) = @_;
	if (length($itemID) == 0) {die('Error: missing required value for $itemID');}
	if(!(-d "$perfhome/var/db/hosts/$itemID")) {die('Error: invalid value for $itemID: no host directory');}
	if(!(-e "$perfhome/var/db/hosts/$itemID/$itemID.ser")) {die('Error: invalid value for $itemID: no host file');}
	if (!(exists( $hostIndex->{$itemID}))) {die('Error: invalid value for $itemID');}
	if ($adminName ne "perfstat") {
		if ($hostIndex->{$itemID}->getOwner() ne $adminName)  {die('ERROR invalid permissions for $adminName');}
	}
}

sub checkItemName {
	my ($itemName) = @_;
	if (length($itemName) == 0) {return("Please enter a host name");}
	if(-d "$perfhome/var/db/hosts/$itemName") {return("Host Name is already taken");}
}

sub securityCheckItemName {
	my ($adminName, $itemName) = @_;
	if (length($itemName) == 0) {die('Error: missing required value for $itemName');}
	if(!(-d "$perfhome/var/db/hosts/$itemName")) {die('Error: invalid value for $itemName: no host directory');}
	if(!(-e "$perfhome/var/db/hosts/$itemName/$itemName.ser")) {die('Error: invalid value for $itemName: no host file');}
	if (!(exists( $hostIndex->{$itemName}))) {die('Error: invalid value for $itemName');}
	if ($adminName ne "perfstat") {
		if ($hostIndex->{$itemName}->getOwner() ne $adminName)  {die('ERROR invalid permissions for $adminName');}
	}
}

sub checkIPAddress {
	my ($ipAddress) = @_;
	if ($ipAddress !~ /(\d+)(\.\d+){3}/) { return("Please enter a valid IP Address"); } 
   	if ($ipAddress !~ /^([\d]+)\.([\d]+)\.([\d]+)\.([\d]+)$/) { return("Please enter a valid IP Address"); } 
	foreach $s (($1, $2, $3, $4)) { 
		if (0 > $s || $s > 255) { return("Please enter a valid IP Address");} 
  	}
}

1;