use strict;
package main;
require("lib_inputCheck.pl");
# -----------------------------------------------------------------------------------------MAIN
# init message variables
$sessionObj->param("userMessage", "");
my $errorMessage = "";

if ($sessionObj->param("userName") eq "perfstat") { 
# Login is root admin
	$adminName = $request->param('adminName');
	checkAdminName($adminName);
	$osName = $request->param('osName');
	checkOSName($osName);
	$itemID = $request->param('itemID');
	$itemName = $request->param('itemName');
	$ipAddress = trim($request->param('ipAddress'));
	securityCheckItemID($adminName, $itemID);
	if ($itemName ne $itemID) {
		$errorMessage = checkItemName($itemName);
	}
	if (length($errorMessage) eq 0) {
		$errorMessage = checkIPAddress($ipAddress);
	}
	if (length($errorMessage) eq 0) {
		if(	$itemID eq $itemName &
			$ipAddress eq $hostIndex->{$itemID}->getIP() &
			$osName eq $hostIndex->{$itemID}->getOS() ) {

			$errorMessage = "Please update a host field";
		}
	}
	if (length($errorMessage) ne 0) {
		$sessionObj->param("userMessage", $errorMessage);
		$queryString = "action=displayUpdateItem" .
						"&adminName=". URLEncode($adminName) .
						"&itemID=" . URLEncode($itemID) .
						"&itemName=" . URLEncode($itemName) .
						"&ipAddress=" . URLEncode($ipAddress) .
						"&osName=$osName";
	} else {
		updateItem($adminName, $itemID, $itemName, $ipAddress, $osName);
		$sessionObj->param("userMessage", "$itemName Updated");
		$queryString = "action=displayUpdateItem" .
						"&adminName=". URLEncode($adminName) .
						"&itemID=" . URLEncode($itemID) .
						"&itemName=" . URLEncode($itemName) .
						"&ipAddress=" . URLEncode($ipAddress) .
						"&osName=$osName";
	}
	
} elsif ($sessionObj->param("role") eq "admin") { 
# Login is group admin
	$adminName = $sessionObj->param("userName");
	checkAdminName($adminName);
	$osName = $request->param('osName');
	checkOSName($osName);
	$itemID = $request->param('itemID');
	$itemName = $request->param('itemName');
	$ipAddress = trim($request->param('ipAddress'));
	securityCheckItemID($adminName, $itemID);
	if ($itemName ne $itemID) {
		$errorMessage = checkItemName($itemName);
	}
	if (length($errorMessage) eq 0) {
		$errorMessage = checkIPAddress($ipAddress);
	}
	if (length($errorMessage) eq 0) {
		if(	$itemID eq $itemName &
			$ipAddress eq $hostIndex->{$itemID}->getIP() &
			$osName eq $hostIndex->{$itemID}->getOS() ) {

			$errorMessage = "Please update a host field";
		}
	}
	if (length($errorMessage) ne 0) {
		$sessionObj->param("userMessage", $errorMessage);
		$queryString = "action=displayUpdateItem" .
						"&adminName=". URLEncode($adminName) .
						"&itemID=" . URLEncode($itemID) .
						"&itemName=" . URLEncode($itemName) .
						"&ipAddress=" . URLEncode($ipAddress) .
						"&osName=$osName";
	} else {
		updateItem($adminName, $itemID, $itemName, $ipAddress, $osName);
		$sessionObj->param("userMessage", "$itemName Updated");
		$queryString = "action=displayUpdateItem" .
						"&adminName=". URLEncode($adminName) .
						"&itemID=" . URLEncode($itemID) .
						"&itemName=" . URLEncode($itemName) .
						"&ipAddress=" . URLEncode($ipAddress) .
						"&osName=$osName";
	}	
} else { # Login is user
	die('ERROR: invalid value for $sessionObj->param("role")');
}

# -----------------------------------------------------------------------------------------SUBROUTINES
sub updateItem() {
	my ($adminName, $hostID, $hostName, $ipAddress, $osName) = @_;

	$hostIndex->{$hostID}->setIP($ipAddress);
	$hostIndex->{$hostID}->setOS($osName);

	if ($hostID ne $hostName) {
		changeHostName($hostID, $hostName)
	}

	$hostIndex->{$hostID}->lock_store("$perfhome/var/db/hosts/$hostName/$hostName.ser") or die "ERROR: Can't store $perfhome/var/db/hosts/$hostName/$hostName.ser\n";
}


sub changeHostName() {
	my ($hostID, $hostName) = @_;
	
	# List of directories that need to be renamed
	my @dirs=qw(rrd var/db/hosts var/status var/events tmp/events);

	foreach my $dir (@dirs) {
		next if (! -d "$perfhome/$dir/$hostID");
		opendir(DIR, "$perfhome/$dir/$hostID") or die("ERROR: Couldn't open dir $perfhome/$dir/$hostID: $!\n");
			# Rename/Remove host files
			while (my $fileName = readdir(DIR)) {
				next if ($fileName =~ m/^\.|^\.\./);

				if ($dir =~ m/rrd/) {
					$fileName =~ m/$hostID\.(\S+)\.rrd/;
					my $service="$1"; 
					rename("$perfhome/$dir/$hostID/$fileName","$perfhome/$dir/$hostID/$hostName.$service.rrd") or die "WARNING: Couldn't rename $fileName: $!\n";
				} elsif ($dir =~ m/var\/db\/hosts/) {
					next if ($fileName !~ m/$hostID/);
					rename("$perfhome/$dir/$hostID/$fileName","$perfhome/$dir/$hostID/$hostName.ser") or die "WARNING: Couldn't rename $fileName: $!\n";
				} else {
					unlink "$perfhome/$dir/$hostID/$fileName" or die "Couldn't remove file $perfhome/$dir/$hostID/$fileName!\n";
				}
		}
		closedir(DIR);

		# Rename all host directories
		rename("$perfhome/$dir/$hostID","$perfhome/$dir/$hostName") or die "ERROR: Couldn't rename $perfhome/$dir/$hostID: $!\n";
	}

	# UPDATE SHARED MEMORY (If Appropriate)
	if ($perfdIsUp) {
		# Thaw/Freeze hostObject to Shared Memory
	}
}

1;