use strict;
package main;
if ($sessionObj->param("userName") eq "perfstat") {
# Login is perfstat admin
	#define adminName for dropdown
	if (defined($request->param('adminName'))) {
		$adminName = $request->param("adminName");
	} else {
		$adminName = "perfstat";
	}
	
	#define hash of admin to list
	$adminList = $userIndex;

	# Define itemID for updates
	if (defined($request->param('itemID'))) {
		$itemID = $request->param("itemID");
	} else {
		$itemID = "";
	}

	# Define itemName for updates
	if (defined($request->param('itemName'))) {
		$itemName = $request->param("itemName");
	} else {
		$itemName = "";
	}

	# Define ipAddress
	if (defined($request->param('ipAddress'))) {
		$ipAddress = $request->param("ipAddress");
	} else {
		$ipAddress = "";
	}

	# Define osName
	if (defined($request->param('osName'))) {
		$osName = $request->param("osName");
	} else {
		$osName = "";
	}
	#define array of hosts to list
	$hostArray = [];
	my $count = 0;
	foreach my $host (sort(keys(%$hostIndex))) {
		my $hostObject = $hostIndex->{$host};
		my $owner = $hostObject->getOwner();
		if ($owner eq $adminName) {
			my $tempArray = [];
			$tempArray->[0] = $host;
			$tempArray->[1] = $hostObject->getIP();
			$tempArray->[2] = $hostObject->getOS();
			$hostArray->[$count] = $tempArray;
			$count++;
		}
	}
	$lenHostArray = @$hostArray;

} elsif ($sessionObj->param("role") eq "admin") {
# Login is group admin
	# Define adminName
	$adminName = $sessionObj->param("userName");

	# Define itemID for updates
	if (defined($request->param('itemID'))) {
		$itemID = $request->param("itemID");
	} else {
		$itemID = "";
	}

	# Define itemName for updates
	if (defined($request->param('itemName'))) {
		$itemName = $request->param("itemName");
	} else {
		$itemName = "";
	}

	# Define ipAddress
	if (defined($request->param('ipAddress'))) {
		$ipAddress = $request->param("ipAddress");
	} else {
		$ipAddress = "";
	}

	# Define osName
	if (defined($request->param('osName'))) {
		$osName = $request->param("osName");
	} else {
		$osName = "";
	}

	#define array of hosts to list
	$hostArray = [];
	my $count = 0;
	foreach my $host (sort(keys(%$hostIndex))) {
		my $hostObject = $hostIndex->{$host};
		my $owner = $hostObject->getOwner();
		if ($owner eq $adminName) {
			my $tempArray = [];
			$tempArray->[0] = $host;
			$tempArray->[1] = $hostObject->getIP();
			$tempArray->[2] = $hostObject->getOS();
			$hostArray->[$count] = $tempArray;
			$count++;
		}
	}
	$lenHostArray = @$hostArray;
} else {
# Login is user
	# Define adminName
	$adminName = $sessionObj->param("creator");
	$hostArray = [];
	my $count = 0;
	foreach my $host (sort(keys(%$hostIndex))) {
		my $hostObject = $hostIndex->{$host};
		my $owner = $hostObject->getOwner();
		if ($owner eq $adminName) {
			my $tempArray = [];
			$tempArray->[0] = $host;
			$tempArray->[1] = $hostObject->getIP();
			$tempArray->[2] = $hostObject->getOS();
			$hostArray->[$count] = $tempArray;
			$count++;
		}
	}
}

1;