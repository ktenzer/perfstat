use strict;
package main;
if ($sessionObj->param("userName") eq "perfstat") {
# Login is perfstat admin

	#define list of admin
	$adminList = $userIndex;
	#define adminName for dropdown (perfstat is default)
	if (defined($request->param('adminName'))) {
		$adminName = $request->param("adminName");
	} else {
		$adminName = "perfstat";
	}
	
	#define list of users
	$userList = $adminList->{$adminName};
	#define userName for dropdown (perfstat is default)
	if (defined($request->param('userName'))) {
		$userName = $request->param("userName");
	} else {
		$userName = $adminName;
	}

	# Define itemID for updates
	if (defined($request->param('itemID'))) {
		$itemID = $request->param("itemID");
	} else {
		$itemID = "";
	}

	# Define itemName for updates
	if (defined($request->param('itemName'))) {
		$itemName = $request->param("itemName");
	} else {
		$itemName = "";
	}

	# Define description
	if (defined($request->param('description'))) {
		$description = $request->param("description");
	} else {
		$description = "";
	}

	#define array of host Groups to list
	my $hostGroupArray = $userIndex->{$adminName}->{$userName}->{hostGroups};
	my $hostGroupArrayLen = @$hostGroupArray;

	#create hostGroupHash
	$hostGroupHash = {};
	for (my $count = 0; $count < $hostGroupArrayLen; $count++) {
		my $tempObject = $hostGroupArray->[$count];
		my $tempArray = [];
		my $tempName = $tempObject->getName();
		$tempArray->[0] = $count;
		$tempArray->[1] = $tempObject->getDescription();
		$hostGroupHash->{$tempName} = $tempArray;
	}
	$hostGroupHashLen = %$hostGroupHash;

} elsif ($sessionObj->param("role") eq "admin") {
# Login is group admin
	# Define adminName
	$adminName = $sessionObj->param("userName");

	#define list of users
	$userList = $userIndex->{$adminName};
	#define userName for dropdown (perfstat is default)
	if (defined($request->param('userName'))) {
		$userName = $request->param("userName");
	} else {
		$userName = $adminName;
	}

	# Define itemID for updates
	if (defined($request->param('itemID'))) {
		$itemID = $request->param("itemID");
	} else {
		$itemID = "";
	}

	# Define itemName for updates
	if (defined($request->param('itemName'))) {
		$itemName = $request->param("itemName");
	} else {
		$itemName = "";
	}

	# Define description
	if (defined($request->param('description'))) {
		$description = $request->param("description");
	} else {
		$description = "";
	}

	#define array of host Groups to list
	my $hostGroupArray = $userIndex->{$adminName}->{$userName}->{hostGroups};
	my $hostGroupArrayLen = @$hostGroupArray;

	#create hostGroupHash
	$hostGroupHash = {};
	for (my $count = 0; $count < $hostGroupArrayLen; $count++) {
		my $tempObject = $hostGroupArray->[$count];
		my $tempArray = [];
		my $tempName = $tempObject->getName();
		$tempArray->[0] = $count;
		$tempArray->[1] = $tempObject->getDescription();
		$hostGroupHash->{$tempName} = $tempArray;
	}
	$hostGroupHashLen = %$hostGroupHash;

} else {
# Login is user
	# Define adminName
	$adminName = $sessionObj->param("creator");
	$userName = $sessionObj->param("userName");

	# Define itemID for updates
	if (defined($request->param('itemID'))) {
		$itemID = $request->param("itemID");
	} else {
		$itemID = "";
	}

	# Define itemName for updates
	if (defined($request->param('itemName'))) {
		$itemName = $request->param("itemName");
	} else {
		$itemName = "";
	}

	# Define description
	if (defined($request->param('description'))) {
		$description = $request->param("description");
	} else {
		$description = "";
	}
	
	#define array of host Groups to list
	my $hostGroupArray = $userIndex->{$adminName}->{$userName}->{hostGroups};
	my $hostGroupArrayLen = @$hostGroupArray;

	#create hostGroupHash
	$hostGroupHash = {};
	for (my $count = 0; $count < $hostGroupArrayLen; $count++) {
		my $tempObject = $hostGroupArray->[$count];
		my $tempArray = [];
		my $tempName = $tempObject->getName();
		$tempArray->[0] = $count;
		$tempArray->[1] = $tempObject->getDescription();
		$hostGroupHash->{$tempName} = $tempArray;
	}
	$hostGroupHashLen = %$hostGroupHash;
}

1;