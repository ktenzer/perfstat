sub checkAdminName {
	my ($adminName) = @_;
	if (length($adminName) == 0) {die('Error: missing required value for $adminName');}
	if(!(-d "$perfhome/var/db/users/$adminName")) {die('Error: invalid value for $adminName: no user directory');}
	if(!(-e "$perfhome/var/db/users/$adminName/$adminName.ser")) {die('Error: invalid value for $adminName: no user file');}
	if (!(exists( $userIndex->{$adminName}->{$adminName}))) {die('Error: invalid value for $adminName');}
}

sub checkUserName {
	my ($userName) = @_;
	if (length($userName) == 0) {die('Error: missing required value for $userName');}
	if(!(-d "$perfhome/var/db/users/$userName")) {die('Error: invalid value for $userName: no user directory');}
	if(!(-e "$perfhome/var/db/users/$userName/$userName.ser")) {die('Error: invalid value for $userName: no user file');}
	if (!(exists( $userIndex->{$adminName}->{$userName}))) {die('Error: invalid value for $userName');}
}

sub checkSelectName {
	my ($adminName, $selectName) = @_;
	if (length($selectName) == 0) {die('Error: missing required value for $selectName');}
	if(!(-d "$perfhome/var/db/hosts/$selectName")) {die('Error: invalid value for $selectName: no host directory');}
	if(!(-e "$perfhome/var/db/hosts/$selectName/$selectName.ser")) {die('Error: invalid value for $selectName: no host file');}
	if (!(exists( $hostIndex->{$selectName}))) {die('Error: invalid value for $selectName');}
	if ($adminName ne "perfstat") {
		if ($hostIndex->{$selectName}->getOwner() ne $adminName)  {die('ERROR invalid permissions for $adminName');}
	}
}


1;