use strict;
package main;
require("lib_inputCheck.pl");
if ($sessionObj->param("userName") eq "perfstat") {
# Login is perfstat admin
	$adminName = $request->param('adminName');
	checkAdminName($adminName);
	$userName = $request->param('userName');
	checkUserName($adminName);
	$itemID = $request->param('itemID');
	$itemName = $request->param('itemName');

	#define array of hosts to list in add host dropdown
	$hostHash = {};

	foreach my $host (keys(%$hostIndex)) {
		my $hostObject = $hostIndex->{$host};
		my $owner = $hostObject->getOwner();
		if ($owner eq $adminName) {
			my $IP = $hostObject->getIP();
			$hostHash->{$host} = $IP;
		}
	}

	#find array of hosts already in hostGroup member array
	my $hostGroupMemberArray = $userIndex->{$adminName}->{$userName}->{hostGroups}->[$itemID]->{memberArray};
	my $hostGroupMemberArrayLen = @$hostGroupMemberArray;

	$hostGroupMemberHash = {};
	# create hash of hostGroupMembers
	for (my $count = 0; $count < $hostGroupMemberArrayLen; $count++) {
		my $hostName = $hostGroupMemberArray->[$count];
		my $tempArray = [];
		$tempArray->[0] = $count;
		$tempArray->[1] = $hostHash->{$hostName};
		$hostGroupMemberHash->{$hostName} = $tempArray;
		delete($hostHash->{$hostName});
	}
	
	$hostHashLen = %$hostHash;
	$hostGroupMemberHashLen = %$hostGroupMemberHash;

} elsif ($sessionObj->param("role") eq "admin") {
# Login is group admin
	$adminName = $sessionObj->param("userName");
	checkAdminName($adminName);
	$userName = $request->param('userName');
	checkUserName($adminName);
	$itemID = $request->param('itemID');
	$itemName = $request->param('itemName');

	#define array of hosts to list in add host dropdown
	$hostHash = {};

	foreach my $host (keys(%$hostIndex)) {
		my $hostObject = $hostIndex->{$host};
		my $owner = $hostObject->getOwner();
		if ($owner eq $adminName) {
			my $IP = $hostObject->getIP();
			$hostHash->{$host} = $IP;
		}
	}

	#find array of hosts already in hostGroup member array
	my $hostGroupMemberArray = $userIndex->{$adminName}->{$userName}->{hostGroups}->[$itemID]->{memberArray};
	my $hostGroupMemberArrayLen = @$hostGroupMemberArray;

	$hostGroupMemberHash = {};
	# create hash of hostGroupMembers
	for (my $count = 0; $count < $hostGroupMemberArrayLen; $count++) {
		my $hostName = $hostGroupMemberArray->[$count];
		my $tempArray = [];
		$tempArray->[0] = $count;
		$tempArray->[1] = $hostHash->{$hostName};
		$hostGroupMemberHash->{$hostName} = $tempArray;
		delete($hostHash->{$hostName});
	}
	
	$hostHashLen = %$hostHash;
	$hostGroupMemberHashLen = %$hostGroupMemberHash;

} else {
# Login is user
	# Login is user
	$adminName = $sessionObj->param("creator");
	checkAdminName($adminName);
	$userName = $sessionObj->param("userName");
	checkUserName($adminName);
	$itemID = $request->param('itemID');
	$itemName = $request->param('itemName');
	#define array of hosts to list in add host dropdown
	$hostHash = {};

	foreach my $host (keys(%$hostIndex)) {
		my $hostObject = $hostIndex->{$host};
		my $owner = $hostObject->getOwner();
		if ($owner eq $adminName) {
			my $IP = $hostObject->getIP();
			$hostHash->{$host} = $IP;
		}
	}

	#find array of hosts already in hostGroup member array
	my $hostGroupMemberArray = $userIndex->{$adminName}->{$userName}->{hostGroups}->[$itemID]->{memberArray};
	my $hostGroupMemberArrayLen = @$hostGroupMemberArray;

	$hostGroupMemberHash = {};
	# create hash of hostGroupMembers
	for (my $count = 0; $count < $hostGroupMemberArrayLen; $count++) {
		my $hostName = $hostGroupMemberArray->[$count];
		my $tempArray = [];
		$tempArray->[0] = $count;
		$tempArray->[1] = $hostHash->{$hostName};
		$hostGroupMemberHash->{$hostName} = $tempArray;
		delete($hostHash->{$hostName});
	}
	
	$hostHashLen = %$hostHash;
	$hostGroupMemberHashLen = %$hostGroupMemberHash;
}

1;