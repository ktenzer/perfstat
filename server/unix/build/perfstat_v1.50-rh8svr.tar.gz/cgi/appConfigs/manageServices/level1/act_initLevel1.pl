use strict;
package main;

if ($sessionObj->param("userName") eq "perfstat") {
# Login is perfstat admin
	#define adminName for dropdown
	if (defined($request->param('adminName'))) {
		$adminName = $request->param("adminName");
	} else {
		$adminName = "perfstat";
	}
	
	#define hash of admin to list
	$adminList = $userIndex;

	# Define itemID for updates
	if (defined($request->param('itemID'))) {
		$itemID = $request->param("itemID");
	} else {
		$itemID = "";
	}

	# Define itemName for updates
	if (defined($request->param('itemName'))) {
		$itemName = $request->param("itemName");
	} else {
		$itemName = "";
	}

	# Create Service Hash
	$serviceHash = {};
	makeServiceHash($serviceHash);

} elsif ($sessionObj->param("role") eq "admin") {
# Login is group admin
	# Define adminName
	$adminName = $sessionObj->param("userName");

	# Define itemID for updates
	if (defined($request->param('itemID'))) {
		$itemID = $request->param("itemID");
	} else {
		$itemID = "";
	}

	# Define itemName for updates
	if (defined($request->param('itemName'))) {
		$itemName = $request->param("itemName");
	} else {
		$itemName = "";
	}

} else {
# Login is user
	# Define adminName
	$adminName = $sessionObj->param("creator");
}

# Create Service Hash
#$serviceHash = {};
#makeServiceHash($serviceHash);

#foreach my $key (sort(keys(%$serviceHash))) {
#	my $services = $serviceHash->{$key};
#	print ("os: $key  services:  @$services<br>");
#}

sub makeServiceHash {

	my ($tempServiceHash) = @_;	
 
	foreach my $os (sort(@$osList)) {
		my $serviceList = [];
		opendir(STATEDIR, "$perfhome/etc/configs/$os") or die("ERROR: Couldn't open dir $perfhome/etc/configs/$os: $!\n");
		while (my $serviceName = readdir(STATEDIR)) {
			if ($serviceName ne "." && $serviceName ne "..") {
				$serviceName =~ s/\.ser//;
				push (@$serviceList, $serviceName);
			}
		}
		$tempServiceHash->{$os} = $serviceList;
		closedir(STATEDIR);
	}
}

1;