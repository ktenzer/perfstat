use strict;
package main;

if (defined($request->param('navBarWidth'))) {
	$navBarWidth = $request->param("navBarWidth");
} else {
	$navBarWidth = $sessionObj->param("navBarWidth");
}

if (defined($request->param('navBarTextLength'))) {
	$navBarTextLength = $request->param("navBarTextLength");
} else {
	$navBarTextLength = $sessionObj->param("navBarTextLength");
}

if (defined($request->param('timeoutInterval'))) {
	$timeoutInterval = $request->param("timeoutInterval");
} else {
	$timeoutInterval = $sessionObj->param("timeoutInterval");
}

if (defined($request->param('statusRefreshInterval'))) {
	$statusRefreshInterval = $request->param("statusRefreshInterval");
} else {
	$statusRefreshInterval = $sessionObj->param("statusRefreshInterval");
}

1;