use strict;
package main;

if ($sessionObj->param("userName") eq "perfstat") {
  # Login is perfstat admin
	#define adminName for dropdown
	if (defined($request->param('adminName'))) {
		$adminName = $request->param("adminName");
	} else {
		$adminName = "perfstat";
	}

	#define userRole if user is being updated
	if (defined($request->param('userRole'))) {
		$userRole = $request->param("userRole");
	} else {
		$userRole = "user";
	}
	
	#define hash of admin to list
	$adminList = $userIndex;
	#define list of users
	$userList = $adminList->{$adminName};
	# Define userName
	if (defined($request->param('userName'))) {
		$userName = $request->param("userName");
	} else {
		$userName = "";
	}

} elsif ($sessionObj->param("role") eq "admin") {
# Login is group admin
	#define hash of users to list
	$userList = $userIndex->{$sessionObj->param("userName")};
	# Define adminName
	$adminName = $sessionObj->param("userName");
	# Define userName
	if (defined($request->param('userName'))) {
		$userName = $request->param("userName");
	} else {
		$userName = "";
	}
} else {
# Login is user
	# Define adminName
	$adminName = $sessionObj->param("creator");
	# Define userName
	$userName = $sessionObj->param("userName");
}

1;