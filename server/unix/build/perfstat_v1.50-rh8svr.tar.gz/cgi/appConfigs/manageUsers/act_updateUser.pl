use strict;
package main;
require("lib_inputCheck.pl");
# -----------------------------------------------------------------------------------------MAIN
# init message variables
$sessionObj->param("userMessage", "");
my $errorMessage = "";

if ($sessionObj->param("userName") eq "perfstat") {
	# Login is root admin
	$adminName = $request->param('adminName');
	checkAdminName("update", $adminName);
	$userName = trim($request->param('userName'));
	checkUserName2($userName, $perfhome);
	$password = trim($request->param('password'));
	$errorMessage = checkPassword($password);
	if (length($errorMessage) eq 0) {
		$confirmPassword = trim($request->param('confirmPassword'));
		$errorMessage = checkConfirmPassword($password, $confirmPassword);
	}
	if (length($errorMessage) ne 0) {
		$sessionObj->param("userMessage", $errorMessage);
		$queryString = "action=displayUpdateUser&adminName=$adminName&userName=$userName";
	} else {
		updatePassword($userName, $password,  $perfhome);
		$sessionObj->param("userMessage", "Password Updated for $userName");
		$queryString = "action=displayUpdateUser&adminName=$adminName&userName=$userName";
	}
	
} elsif ($sessionObj->param("role") eq "admin") {
	# Login is group admin
	$adminName = $sessionObj->param("userName");
	checkAdminName("update", $adminName);
	$userName = trim($request->param('userName'));
	checkUserName2($userName, $perfhome);
	$password = trim($request->param('password'));
	$errorMessage = checkPassword($password);
	if (length($errorMessage) eq 0) {
		$confirmPassword = trim($request->param('confirmPassword'));
		$errorMessage = checkConfirmPassword($password, $confirmPassword);
	}
	if (length($errorMessage) ne 0) {
		$sessionObj->param("userMessage", $errorMessage);
		$queryString = "action=displayUpdateUser&userName=$userName";
	} else {
		updatePassword($userName, $password,  $perfhome);
		$sessionObj->param("userMessage", "Password Updated for $userName");
		$queryString = "action=displayUpdateUser&userName=$userName";
	}
	
} else {
	# Login is user
	$userName = $sessionObj->param("userName");
	$password = trim($request->param('password'));
	$errorMessage = checkPassword($password);
	if (length($errorMessage) eq 0) {
		$confirmPassword = trim($request->param('confirmPassword'));
		$errorMessage = checkConfirmPassword($password, $confirmPassword);
	}
	if (length($errorMessage) ne 0) {
		$sessionObj->param("userMessage", $errorMessage);
	} else {
		updatePassword($userName, $password,  $perfhome);
		$sessionObj->param("userMessage", "Password Updated");
	}
	$queryString = "action=displayUpdateUser&userName=$userName";
}

# -----------------------------------------------------------------------------------------SUBROUTINES
sub updatePassword {
	my ($userName, $password, $perfhome) = @_;
	my $directoryName = "$perfhome/var/db/users/$userName";
	my $fileName = "$directoryName/$userName.ser";
	my $userObj = lock_retrieve($fileName) || die("ERROR: Can't retrieve userObj from $fileName\n");
	die("ERROR: can't define userObj from $fileName\n") unless defined($userObj);
	$userObj->setPassword($password);
	lock_store($userObj, "$fileName") || die("ERROR: can't store userObj in $fileName\n");
}

1;