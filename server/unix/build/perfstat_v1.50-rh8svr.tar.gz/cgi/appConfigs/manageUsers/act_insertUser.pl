use strict;
package main;
require("lib_inputCheck.pl");

# init message variables
$sessionObj->param("userMessage", "");
my $errorMessage = "";

if ($sessionObj->param("userName") eq "perfstat") {
	# Login is perfstat admin
	$adminName = $request->param('adminName');
	checkAdminName("insert", $adminName);
	$userRole = $request->param('userRole');
	checkUserRole($userRole);
	$userName = trim($request->param('userName'));
	$errorMessage = checkUserName1($userName);
	if (length($errorMessage) eq 0) {
		$password = trim($request->param('password'));
		$errorMessage = checkPassword($password);
	}
	if (length($errorMessage) eq 0) {
		$confirmPassword = trim($request->param('confirmPassword'));
		$errorMessage = checkConfirmPassword($password, $confirmPassword);
	}
	if (length($errorMessage) ne 0) {
		$sessionObj->param("userMessage", $errorMessage);
		$queryString = "adminName=$adminName&userName=$userName&userRole=$userRole";
	} else {
		if ($userRole eq "user") {
			insertUser($userName, $password, $adminName, $userRole, $perfhome);
			$queryString = "&adminName=$adminName";
		} else {
			insertUser($userName, $password, $userName, $userRole, $perfhome);
			$queryString = "&adminName=$userName";
		}
	}

} elsif ($sessionObj->param("role") eq "admin") {
	# Login is group admin
	$adminName = $sessionObj->param("userName");
	checkAdminName("insert", $adminName);
	$userName = trim($request->param('userName'));
	$userRole = "user";
	$errorMessage = checkUserName1($userName);
	if (length($errorMessage) eq 0) {
		$password = trim($request->param('password'));
		$errorMessage = checkPassword($password);
	}
	if (length($errorMessage) eq 0) {
		$confirmPassword = trim($request->param('confirmPassword'));
		$errorMessage = checkConfirmPassword($password, $confirmPassword);
	}
	if (length($errorMessage) ne 0) {
		$sessionObj->param("userMessage", $errorMessage);
		$queryString = "userName=$userName";
	} else {
		insertUser($userName, $password, $adminName, $userRole, $perfhome);
		$queryString = "";
	}
	
} else {
	# Login is user
	die('ERROR: invalid value for $sessionObj->param("role")')
}
################################################### SUBROUTINES
sub insertUser {
	my ($userName, $password, $adminName, $userRole, $perfhome) = @_;
	# Create user object
	my $userObject = User->new(	name		=> $userName,
										password 	=> $password,
										creator		=> $adminName,
										role			=> $userRole);
	# Create user directorys
	mkdir("$perfhome/var/db/users/$userName", 0770) || die("could not create directory $perfhome/var/db/users/$userName\n");

	# Store new user object
	lock_store($userObject, "$perfhome/var/db/users/$userName/$userName.ser") || die("can't store userObject in $perfhome/var/db/users/$userName/$userName.ser\n");

	# update userIndex
	if ($userRole eq "admin") {
		$userIndex->{$userName} = {};
		$userIndex->{$userName}->{$userName} = $userObject;
	} else { # role eq user
		$userIndex->{$adminName}->{$userName} = $userObject;
	}
}

1;