function drawGraphTable() {
	// Clear the current graphTable
	var graphTable = document.getElementById("graphTable");
	var tBody = graphTable.tBodies[0];
	var tBodyChildren = tBody.childNodes;
  	var tBodyChildrenLen = tBodyChildren.length;
  	for (var count = 0; count < tBodyChildrenLen; count++)
  	{
		tBody.removeChild(tBody.firstChild);
	}

	// Draw graphTable based on graphHolderArray
	if (top.topFrame.graphHolderArray.length == 0) {
		var graphTable = document.getElementById('graphTable');
		var newRow = document.createElement('TR');
		var newCell = document.createElement('TD');
		newCell.innerHTML =  '<b>No Graphs Currently Selected</b>';
		newCell.setAttribute("colSpan", 8);
		newCell.setAttribute("style", "text-align: center");
		newRow.appendChild(newCell);
		graphTable.tBodies[0].appendChild(newRow);
	} else {
		for (var count = 0; count < top.topFrame.graphHolderArray.length; count++) {
			graphArray = top.topFrame.graphHolderArray[count];
			createGraphRow(count, graphArray);
		}
	}
}

function insertGraph(hostName, serviceName, graphName) {
	var graphAlreadyInTable = 0; 
	for (var count = 0; count < top.topFrame.graphHolderArray.length; count++) {
		graphArray = top.topFrame.graphHolderArray[count];
		if (hostName == graphArray[0] && serviceName == graphArray[1] && graphName == graphArray[2]) {
			graphAlreadyInTable = 1;
			break;
		}
	}
	
	if (graphAlreadyInTable) {
		alert("Error: This graph is already selected");
	} else {
		var graphArray = new Array();
		graphArray[0] = hostName;
		graphArray[1] = serviceName;
		graphArray[2] = graphName;
		graphArray[3] = 1;
		graphArray[4] = 0;
		graphArray[5] = 0;
		graphArray[6] = 0;
		top.topFrame.graphHolderArray.push(graphArray);
		drawGraphTable();
	}
}

function createGraphRow(count, graphArray) {
	var graphTable = document.getElementById('graphTable');
	//new row
	var newRow = document.createElement('TR');
	//navCell
	var navCell = document.createElement('TD');
	var cellContent = createAnchor(count);
	navCell.appendChild(cellContent);
	newRow.appendChild(navCell);
	//cell0
	var cell0 = document.createElement('TD');
	var cellContent = document.createTextNode(graphArray[0]);
	cell0.appendChild(cellContent);
	newRow.appendChild(cell0);
	//cell1
	var cell1 = document.createElement('TD');
	var cellContent = document.createTextNode(graphArray[1]);
	cell1.appendChild(cellContent);
	newRow.appendChild(cell1);
	//cell2
	var cell2 = document.createElement('TD');
	var cellContent = document.createTextNode(graphArray[2]);
	cell2.appendChild(cellContent);
	newRow.appendChild(cell2);
	//cell3
	var cell3 = document.createElement('TD');
	var cellContent = '<input type="checkbox"' + ((graphArray[3] == 1) ? 'checked' : '')  + ' onClick="toggleCheckBox(' + count + ', 3);">';
	cell3.innerHTML = cellContent;
	newRow.appendChild(cell3);
	//cell4
	var cell4 = document.createElement('TD');
	var cellContent = '<input type="checkbox"' + ((graphArray[4] == 1) ? 'checked' : '')  + ' onClick="toggleCheckBox(' + count + ', 4);">';
	cell4.innerHTML = cellContent;
	newRow.appendChild(cell4);
	//cell5
	var cell5 = document.createElement('TD');
	var cellContent = '<input type="checkbox"' + ((graphArray[5] == 1) ? 'checked' : '')  + ' onClick="toggleCheckBox(' + count + ', 5);">';
	cell5.innerHTML = cellContent;
	newRow.appendChild(cell5);
	//cell6
	var cell6 = document.createElement('TD');
	var cellContent = '<input type="checkbox"' + ((graphArray[6] == 1) ? 'checked' : '')  + ' onClick="toggleCheckBox(' + count + ', 6);">';
	cell6.innerHTML = cellContent;
	newRow.appendChild(cell6);

	graphTable.tBodies[0].appendChild(newRow);
}

function deleteGraphRow(rowID) {
	top.topFrame.graphHolderArray.splice(rowID, 1);
	drawGraphTable();
}

function createAnchor(graphID) {
	var newAnchor = document.createElement('A');
	var textNode = document.createTextNode('del');
	newAnchor.appendChild(textNode);
	var href = "javascript: deleteGraphRow('" + graphID + "');";
	newAnchor.setAttribute('href' , href);
	return newAnchor;
}

//function createCheckBox(graphID, intervalID, state) {
//	var newCheckBox = document.createElement('INPUT');
//	newCheckBox.setAttribute('type' , 'checkbox');
//	newCheckBox.setAttribute('onChange' , 'toggleCheckBox(' + graphID + ', ' + intervalID + ');');
//	if (state == 1) {
//		newCheckBox.setAttribute("checked", "checked"); 
//	}
//	return newCheckBox;
//}

function toggleCheckBox(graphID, intervalID) {
	if (top.topFrame.graphHolderArray[graphID][intervalID] == 0) {
		top.topFrame.graphHolderArray[graphID][intervalID] = 1;
	} else {
		top.topFrame.graphHolderArray[graphID][intervalID] = 0;
	}
}

function serializeGraphHolderArray() {
	var serializedGraphHolderArray = "";
	for (var count1 = 0; count1 < top.topFrame.graphHolderArray.length; count1++) {
		var graphArray = top.topFrame.graphHolderArray[count1];
		var serializedGraphArray = "";
		for (var count2 = 0; count2 < graphArray.length; count2++) {
			var graphElement = graphArray[count2];
			serializedGraphArray = serializedGraphArray + graphElement + "^";
		}
		serializedGraphArray = serializedGraphArray + ";";
		serializedGraphHolderArray = serializedGraphHolderArray + serializedGraphArray;
	}
	return serializedGraphHolderArray;
}

function selectAll() {
	var insertHrefArray = getElementbyClass("insertHREF");
	for (i=0; i < insertHrefArray.length; i++) {
		var ID = insertHrefArray[i].id;
		var idComponentsArray = ID.split("^");
		
		var graphAlreadyInTable = 0;
		for (var count = 0; count < top.topFrame.graphHolderArray.length; count++) {
			graphArray = top.topFrame.graphHolderArray[count];
			if (	idComponentsArray[0] == top.topFrame.graphHolderArray[count][0] && 
				idComponentsArray[1] ==  top.topFrame.graphHolderArray[count][1] && 
				idComponentsArray[2] ==  top.topFrame.graphHolderArray[count][2]) {
				// graph is already in table
				top.topFrame.graphHolderArray[count][3] = 1;
				top.topFrame.graphHolderArray[count][4] = 1;
				top.topFrame.graphHolderArray[count][5] = 1;
				top.topFrame.graphHolderArray[count][6] = 1;
				break;
				graphAlreadyInTable = 1;
			}
		}
		if (graphAlreadyInTable) {
			// don't do anything it's been updated above
		} else {
			var graphArray = new Array();
			graphArray[0] = idComponentsArray[0];
			graphArray[1] = idComponentsArray[1];
			graphArray[2] = idComponentsArray[2];
			graphArray[3] = 1;
			graphArray[4] = 1;
			graphArray[5] = 1;
			graphArray[6] = 1;
			top.topFrame.graphHolderArray.push(graphArray);
		}
	}
	drawGraphTable();
}

function removeAll() {
	top.topFrame.graphHolderArray = new Array();
	drawGraphTable();
}

function selectColumn(interval) {
	var intervalIndex = -1;
	if (interval == 'hourly')
		intervalIndex = 3;
	else if (interval == 'daily')
		intervalIndex = 4;
	else if (interval == 'weekly')
		intervalIndex = 5;
	else if (interval == 'monthly')
		intervalIndex = 6;

	for (var count = 0; count < top.topFrame.graphHolderArray.length; count++) {
		top.topFrame.graphHolderArray[count][intervalIndex] = 1;
	}
	drawGraphTable();
}

function deSelectColumn(interval) {
	var intervalIndex = -1;
	if (interval == 'hourly')
		intervalIndex = 3;
	else if (interval == 'daily')
		intervalIndex = 4;
	else if (interval == 'weekly')
		intervalIndex = 5;
	else if (interval == 'monthly')
		intervalIndex = 6;

	for (var count = 0; count < top.topFrame.graphHolderArray.length; count++) {
		top.topFrame.graphHolderArray[count][intervalIndex] = 0;
	}
	drawGraphTable();
}

function getElementbyClass(className) {
	var selectedClassArray = new Array();
	var inc=0
	var allPageTagsArray = document.getElementsByTagName("*");
	for (i=0; i < allPageTagsArray.length; i++) {
		if (allPageTagsArray[i].className == className) {
			selectedClassArray[inc++] = allPageTagsArray[i];
		}
	}
	return  selectedClassArray;
}