function popWindow(sourcePath, windowTarget, windowParams)
{
	newWindow = window.open(sourcePath, windowTarget, 'width=800, height=400, status, resizable, scrollbars');
	setTimeout('newWindow.focus();',250);
}

function warnOnClickAnchor( message ) {
	return window.confirm(message);
}

function toggle(item1, item2) {
	//toggle item1
	obj = document.getElementById(item1);
	visible = (obj.style.display != "none");
	key = "x" + item1;
	if (visible) {
		obj.style.display = "none";
		document.images[key].src =  "../../../perfStatResources/images/navigation/icon_minusNavBar.gif";
	} else {
		obj.style.display = "block";
		document.images[key].src = "../../../perfStatResources/images/navigation/icon_plusNavBar.gif";		
	}

	//toggle item2
	obj = document.getElementById(item2);
	visible = (obj.style.display != "none");
	if (visible) {
		obj.style.display = "none";
	} else {
		obj.style.display = "block";
	}
}

function statusLevel3InitialToggle(serviceName) {
	var prefix = serviceName.substring(0, serviceName.indexOf("."));
	if (prefix.length != 0) {
		var off = prefix + "-off";
		var on = prefix + "-on";
		toggle(off, on);
	}
}

function openAll() {
	divs = document.getElementsByTagName("DIV");
	onPattern = /-on$/;
	for (i=0; i < divs.length; i++) {
		var item = divs[i].id;
		if(onPattern.test(item)) {
			divs[i].style.display ="block";
			key = "x" + item;
			document.images[key].src =  "../../../perfStatResources/images/navigation/icon_minusNavBar.gif";
		} else {
			divs[i].style.display ="none";
			key = "x" + item;
			document.images[key].src =  "../../../perfStatResources/images/navigation/icon_plusNavBar.gif";
		}
	}
}

function closeAll() {
	divs = document.getElementsByTagName("DIV");
	offPattern = /-off$/;
	for (i=0; i < divs.length; i++) {
		var item = divs[i].id;
		if(offPattern.test(divs[i].id)){
			divs[i].style.display ="block";
			key = "x" + item;
			document.images[key].src =  "../../../perfStatResources/images/navigation/icon_plusNavBar.gif";
		} else {
			divs[i].style.display ="none";
			key = "x" + item;
			document.images[key].src =  "../../../perfStatResources/images/navigation/icon_plusNavBar.gif";
		}
	}
}

function displayGraphs() {
	// strip out graphs that have no intervals selected 
	var errorMessage = "";
	if (top.topFrame.graphHolderArray.length == 0) {
		errorMessage = "Error: no graphs selected";
	}

	if (errorMessage.length == 0) {
		for (var count = 0; count < top.topFrame.graphHolderArray.length; count++) {
			var graphArray = top.topFrame.graphHolderArray[count];
			if (graphArray[3] == 0 && graphArray[4] == 0 && graphArray[5] == 0 && graphArray[6] == 0) {
				errorMessage = "Error: no interval selected for" + graphArray[0] + ": " + graphArray[1] + ": " + graphArray[2];
				break;
			}
		}
	}

	if (errorMessage.length != 0) {
		alert(errorMessage);
	} else {
		document.forms.outputGraphs.graphHolderArray.value = serializeGraphHolderArray();
		document.forms.outputGraphs.submit();
	}
}

function serializeGraphHolderArray() {
	var serializedGraphHolderArray = "";
	for (var count1 = 0; count1 < top.topFrame.graphHolderArray.length; count1++) {
		var graphArray = top.topFrame.graphHolderArray[count1];
		var serializedGraphArray = "";
		for (var count2 = 0; count2 < graphArray.length; count2++) {
			var graphElement = graphArray[count2];
			serializedGraphArray = serializedGraphArray + graphElement + "^";
		}
		serializedGraphArray = serializedGraphArray + ";";
		serializedGraphHolderArray = serializedGraphHolderArray + serializedGraphArray;
	}
	return serializedGraphHolderArray;
}