function onBodyLoad(headerNavChosen)
{
	top.topFrame.setLinkChosen(headerNavChosen);
	if (headerNavChosen == "status") {
		parent.content.location = "../content/level1/index.pl";
	} else if (headerNavChosen == "performance") {
		parent.content.location = "../content/level1/index.pl";
	}
}

function Toggle(item)
{
   obj = document.getElementById(item);
   visible = (obj.style.display != "none");
   key = "x" + item;
   if (visible) {
      obj.style.display ="none";
      document.images[key].src = "../../perfStatResources/images/navigation/icon_plusNavBar.gif";
   } else {
      obj.style.display ="block";
      document.images[key].src =  "../../perfStatResources/images/navigation/icon_minusNavBar.gif";
   }
}


function openAll() {
	divs = document.getElementsByTagName("DIV");
	for (i=0; i < divs.length; i++) {
		var item = divs[i].id;
		if (item != "navContainer")
		{
			divs[i].style.display ="block";
			key = "x" + item;
			document.images[key].src =  "../../perfStatResources/images/navigation/icon_minusNavBar.gif";
		}
	}
}

function closeAll() {
	divs = document.getElementsByTagName("DIV");
	for (i=0; i < divs.length; i++) {
		var item = divs[i].id;
		if (item != "navContainer") {
			divs[i].style.display ="none";
			key = "x" + item;
			document.images[key].src =  "../../perfStatResources/images/navigation/icon_plusNavBar.gif";
		}
	}
}