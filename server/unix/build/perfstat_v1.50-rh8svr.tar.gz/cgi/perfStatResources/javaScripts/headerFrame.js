var graphHolderArray = new Array();

function setLinkChosen(linkID)
{
	anchors = document.getElementsByTagName("A");
	for(i=0; i<anchors.length; i++)
	{
		if(anchors[i].id != linkID)
		{
			
			anchors[i].style.color = "";
		}
		else
		{
			anchors[i].style.color = "#D86E12"; //orange
		}
	}
}
