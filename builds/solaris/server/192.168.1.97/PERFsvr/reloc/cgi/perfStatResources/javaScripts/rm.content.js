//update Nav
function updateNavigation() {
		var myURL = "../../navigation/index.pl?stopOnBodyLoad=1";
		parent.navigation.location = myURL;
}
