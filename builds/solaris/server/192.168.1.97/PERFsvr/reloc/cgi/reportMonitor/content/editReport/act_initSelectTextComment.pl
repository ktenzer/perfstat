# which report
$reportNameID = $request->param('reportNameID');

1;