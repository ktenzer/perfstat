# Gather Disk Metrics

use CGI::Carp qw(carpout);
use POSIX qw(uname);
use Fcntl qw(:flock);

# Slurp in path to Perfhome
my $perfhome=&PATH;
$perfhome =~ s/\/bin//;

# Slurp in Configuration
my %conf       = ();
&GetConfiguration(\%conf);

# Set Environment Variables from %conf
foreach $key (keys %conf) {
        $ENV{$key}="$conf{$key}";
}

# Log all alerts and warnings to the below logfile
my $logfile = "$perfhome/var/logs/perfctl.log";
open(LOGFILE, ">> $logfile")
        or die "ERROR: Unable to append to $logfile: $!\n";
carpout(*LOGFILE);

# Setup Variables
my $service="io";
my $os = (uname)[0];

# Run subroutines
&IOSTAT;

# Collect io statistics
sub IOSTAT {
        my $iostat_out="$perfhome/tmp/iostat.out";

        if (! -f $iostat_out) {
                exit (1);
        }

        # Slurp in vmstat data for parsing
        open(IOSTAT_OUT,"$iostat_out")
                or die "Couldn't open file $vmstat_out: $!\n";

        my @data=<IOSTAT_OUT>;
        close (IOSTAT_OUT);

        my $i=0;

        # Parse the second count only
        foreach $line (@data) {

                if ($line =~ m/^\s*cpu/) {
                        $line_num="$i";
                        $i++;
                        next;
                }

                if ($line_num eq "1") {
			if ($line =~ m/c\d+t\d+d\d+/) {
				next if ($line =~ m/c\d+t\d+d\d+s\d+/);
        			$line =~ m/\s+\S+\s+\S+\s+(\S+)\s+(\S+)\s+\S+\s+\S+\s+(\S+)\s+\S+\s+\S+\s+(\S+)\s+\S+\s+\S+\s+\S+\s+\S+\s+(\S+)/;
				my $ioReadKB=$1; my $ioWriteKB=$2; my $aWait=$3; my $ioUtilPct=$4; my $device=$5;
				my $ioIdlePct=100 - $ioUtilPct;
				$io_h{$device}="$ioReadKB $ioWriteKB $aWait $ioUtilPct $ioIdlePct";
			}
		}
	}
}

# Get configuration dynamically from perf-conf
sub GetConfiguration {

        my $configfile="$perfhome/etc/perf-conf";
        my $hashref = shift;

        open(FILE, $configfile)
                or die "Couldn't open FileHandle for $configfile: $!\n";

        my @data=<FILE>;
        foreach $line (@data) {

                # Skip line if commented out
                next if ($line =~ m/^#/);
		next if ($line =~ m/^\s+/);
                $line =~ m/(\w+)=(.+)/;

                my $key=$1;
                my $value=$2;

                $hashref->{$key}=$value;
        }
        close(FILE);
}

# Get path to perfctl executable
sub PATH {
  my $path = PerlApp::exe();
	$path =~ s/\/\w*$//;
        return $path;
}

# Send Data to Perf Server
my $totalReadKB=0;
my $totalWriteKB=0;
my $totalWait=0;
my $totalUtilPct=0;
my $totalIdlePct=0;
my $ioCount=0;

foreach my $device (sort keys %io_h) {
	$perf_out="$os data $service $device $io_h{$device}";

        # Calculate Total
        my $ioData=$io_h{$device};
        $ioData =~ /(\S*)\s+(\S*)\s+(\S*)\s+(\S*)\s+(\S*)/;
        $totalReadKB=$1 + $totalReadKB;
        $totalWriteKB=$2 + $totalWriteKB;
        $totalWait=$3 + $totalWait;
        $totalUtilPct=$4 + $totalUtilPct;
        $totalIdlePct=$5 + $totalIdlePct;

	open(PERFOUT, ">> $perfhome/tmp/perf.out")
        	or die "WARNING: Couldn't open file handle for $perfhome/tmp/perf.out: $!\n";

	flock(PERFOUT, LOCK_EX)
        	or die "WARNING: Couldn't obtain exclusive lock on $perfhome/tmp/perf.out: $!\n";

	print PERFOUT "$perf_out\n";

        flock(PERFOUT, LOCK_UN)
                or die "WARNING: Couldn't release lock on $perfhome/tmp/perf.out: $!\n";

        close(PERFOUT);

        $ioCount ++;
}

# Send IO Totals
if ("$totalReadKB" !~ m/^0/) {
        $totalReadKB=$totalReadKB / $ioCount;
}
if ("$totalWriteKB" !~ m/^0/) {
        $totalWriteKB=$totalWriteKB / $ioCount;
}
if ("$totalWait" !~ m/^0/) {
        $totalWait=$totalWait / $ioCount;
}
if ("$totalUtilPct" !~ m/^0/) {
        $totalUtilPct=$totalUtilPct / $ioCount;
}
if ("$totalIdlePct" !~ m/^0/) {
        $totalIdlePct=$totalIdlePct / $ioCount;
}

my $perf_out="$os data io Total $totalReadKB $totalWriteKB $totalWait $totalUtilPct $totalIdlePct";

open(PERFOUT, ">> $perfhome/tmp/perf.out")
        or die "WARNING: Couldn't open file handle for $perfhome/tmp/perf.out: $!\n";

flock(PERFOUT, LOCK_EX)
        or die "WARNING: Couldn't obtain exclusive lock on $perfhome/tmp/perf.out: $!\n";

print PERFOUT "$perf_out\n";

flock(PERFOUT, LOCK_UN)
        or die "WARNING: Couldn't release lock on $perfhome/tmp/perf.out: $!\n";

close(PERFOUT);
