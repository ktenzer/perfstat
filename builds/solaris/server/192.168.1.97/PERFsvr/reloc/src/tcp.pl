# Gather TCP Metrics

use CGI::Carp qw(carpout);
use POSIX qw(uname);
use Fcntl qw(:flock);

# Slurp in path to Perfhome
my $perfhome=&PATH;
$perfhome =~ s/\/bin//;

$perf="$perfhome/bin/perf";

# Slurp in Configuration
my %conf       = ();
&GetConfiguration(\%conf);

# Set Environment Variables from %conf
foreach $key (keys %conf) {
        $ENV{$key}="$conf{$key}";
}

# Log all alerts and warnings to the below logfile
my $logfile = "$perfhome/var/logs/perfctl.log";
open(LOGFILE, ">> $logfile")
        or die "ERROR: Unable to append to $logfile: $!\n";
carpout(*LOGFILE);

# Setup Variables
my $service="tcp";
my $os = (uname)[0];

# Run subroutines
&INTERFACE;
&TRAFFIC;

# Get interface information
sub INTERFACE {

	open(IFCONFIG,"$ENV{'IFCONFIG_CMD'} -a|")
		or die "Couldn't open $ENV{'IFCONFIG_CMD'}: $!\n";

	my @data=<IFCONFIG>;

	close(IFCONFIG);

	foreach my $line (@data) {
		next if (! $line =~ m/^\S+:/);
		next if ($line =~ m/^lo/);
		next if ($line =~ m/^\S+:\S+:/);
		if ($line =~ m/^\S+:/) {
			$line =~ m /^(\S+):/;
			$device=$1;
			 $tcp_h{$device}=();
		}
	}
}

# Collect TCP bytes in/out
sub TRAFFIC {

	foreach $device (keys %tcp_h) {
		open(KSTAT,"$ENV{'KSTAT_CMD'} -n $device|")
			or die "Couldn't open $ENV{'KSTAT_CMD'} -n $device: $!\n";

		my @data=<KSTAT>;

		close(KSTAT);

		foreach my $line (@data) {
			if ($line =~ m/obytes64/) {
				$line =~ m/\s+\S+\s+(\d+)/;
				$tcpBytesOut=$1;
			}
			if ($line =~ m/rbytes64/) {
				$line =~ m/\s+\S+\s+(\d+)/;
				$tcpBytesIn=$1;
			}
		}
		
		&COUNTERS;
		$tcp_h{$device}="$tcpBytesIn $tcpBytesOut";

	}
}

# Get actual value from counter
sub COUNTERS {

        @counters=qw(tcpBytesIn tcpBytesOut);
        my $counterDir="$perfhome/tmp/counters";

        foreach $counter (@counters) {
                if (! -f "$counterDir/$counter") {
                        open(COUNTER, ">$counterDir/$counter")
                                or die "WARNING: Couldn't open counter for $counter: $!\n";
                        print COUNTER "${$counter}";

                        close (COUNTER);

                        # Set to 0 since we don't know the last value
                        ${$counter}="0";
                } else {
                        # Open for read
                        open(COUNTER, "< $counterDir/$counter")
                                or die "WARNING: Couldn't open counter for $counter: $!\n";

                        $data=<COUNTER>;
                        close (COUNTER);

                        # Open for write
                        open(COUNTER, "> $counterDir/$counter")
                                or die "WARNING: Couldn't open counter for $counter: $!\n";

                        print COUNTER "${$counter}";

                        close (COUNTER);

                        ${$counter}=${$counter} - $data;

                        # Calculate average over run interval
                        my $intervalSec=$ENV{'RUN_INTERVAL'} * 60;
                        ${$counter}=${$counter} / $intervalSec;
                }
        }
}

# Get configuration dynamically from perf-conf
sub GetConfiguration {

        my $configfile="$perfhome/etc/perf-conf";
        my $hashref = shift;

        open(FILE, $configfile)
                or die "Couldn't open FileHandle for $configfile: $!\n";

        my @data=<FILE>;
        foreach $line (@data) {

                # Skip line if commented out
                next if ($line =~ m/^#/);
		next if ($line =~ m/^\s+/);
                $line =~ m/(\w+)=(.+)/;

                my $key=$1;
                my $value=$2;

                $hashref->{$key}=$value;
        }
        close(FILE);
}

# Get path to perfctl executable
sub PATH {
  my $path = PerlApp::exe();
	$path =~ s/\/\w*$//;
        return $path;
}

# Send TCP Data to Perf Server
my $totalBytesIn=0;
my $totalBytesOut=0;
my $tcpCount=0;

# Send TCP Data to Perf Server
foreach $key (sort keys %tcp_h) {
	$perf_out="$os data $service $key $tcp_h{$key}";

        # Calucalate Total
        $tcpData=$tcp_h{$key};
        $tcpData =~ m/(\S*)\s+(\S*)/;
        $totalBytesIn=$1 + $totalBytesIn;
        $totalBytesOut=$2 + $totalBytesOut;

	open(PERFOUT, ">> $perfhome/tmp/perf.out")
        	or die "WARNING: Couldn't open file handle for $perfhome/tmp/perf.out: $!\n";

	flock(PERFOUT, LOCK_EX)
        	or die "WARNING: Couldn't obtain exclusive lock on $perfhome/tmp/perf.out: $!\n";

	print PERFOUT "$perf_out\n";

        flock(PERFOUT, LOCK_UN)
                or die "WARNING: Couldn't release lock on $perfhome/tmp/perf.out: $!\n";

        close(PERFOUT);

        $tcpCount ++;
}

# Send tcp Totals
if ("$totalBytesIn" !~ m/^0/) {
        $totalBytesIn=$totalBytesIn / $tcpCount;
}
if ("$totalBytesOut" !~ m/^0/) {
        $totalBytesOut=$totalBytesOut / $tcpCount;
}

my $perf_out="$os data tcp Total $totalBytesIn $totalBytesOut";

open(PERFOUT, ">> $perfhome/tmp/perf.out")
        or die "WARNING: Couldn't open file handle for $perfhome/tmp/perf.out: $!\n";

flock(PERFOUT, LOCK_EX)
        or die "WARNING: Couldn't obtain exclusive lock on $perfhome/tmp/perf.out: $!\n";

print PERFOUT "$perf_out\n";

flock(PERFOUT, LOCK_UN)
        or die "WARNING: Couldn't release lock on $perfhome/tmp/perf.out: $!\n";

close(PERFOUT);
