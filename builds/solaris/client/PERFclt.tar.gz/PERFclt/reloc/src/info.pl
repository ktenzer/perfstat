# Gather Host Info

use CGI::Carp qw(carpout);
use POSIX qw(uname);
use Fcntl qw(:flock);

# Slurp in path to Perfhome
my $perfhome=&PATH;
$perfhome =~ s/\/bin//;

# Slurp in Configuration
my %conf       = ();
&GetConfiguration(\%conf);

# Set Environment Variables from %conf
foreach $key (keys %conf) {
        $ENV{$key}="$conf{$key}";
}

# Log all alerts and warnings to the below logfile
my $logfile = "$perfhome/var/logs/perfctl.log";
open(LOGFILE, ">> $logfile")
        or die "ERROR: Unable to append to $logfile: $!\n";
carpout(*LOGFILE);

# Setup Variables
my $service="info";
my $os = (uname)[0];

# Location of OS info
my $memInfo="/proc/meminfo";
my $osInfo="/proc/version";

# Define variables
my $cpuNum=();
my $cpuModel=();
my $cpuSpeed=();
my $cpuHash=();
my $memTotal=();
my $swapTotal=();
my $osVersion=();
my $kernelVersion=();
my $patches=();

&PRTDIAG;
#&SWAPINFO;
&OSINFO;
&PatchINFO;

# Gather cpu info
sub PRTDIAG {

        open(PRTDIAG, "$ENV{'PRTDIAG_CMD'}|")
	        or die "Couldn't open $prtdiag: $!\n";

        my @data=<PRTDIAG>;

        close(PRTDIAG);

	$cpuNum=0;
	foreach my $line (@data) {

		$line =~ s/^\s+//;

		next if ($line =~ m/^-/);

		if ($line =~ m/^System\s+Configuration:/) {
			$line =~ m/\s+\((\S*)\s+/;
			$cpuModel=$1;
		}
		if ($line =~ m/^Memory\s+size:/) {
			$line =~ m/\S+\s+\S+\s+(\S*)/;
			$memTotal=$1;
		}
		if ($line =~ m/Brd\s+CPU\s+Module/) {
			$cpuFlag="1";
			next;
		}

		if (defined $cpuFlag) {
			if ($line =~ m/^=/) {
				undef $cpuFlag;
			} else {
				next if ($line !~ m/^\S+/);
				$line =~ m/\S+\s+\S+\s+\S+\s+(\S*)/;
				$cpuNum++;
				$cpuSpeed=$1;
			}
		}
	}
}

sub SWAPINFO {

        open(SWAP,"$ENV{'SWAP_CMD'} -s|")
                or die "Couldn't open $ENV{'SWAP_CMD'} -s: $!\n";

        my $line=<SWAP>;

        close(SWAP);

        # Parse Swap statistics
        $line =~ m/(\d+)k\s+\S+\s+(\d+)k\s+\S+$/;
        $swapUsedKB=$1; $swapAvailKB=$2;

        # Calculate Swap percent utilization
        $swapUsedMB=$swapUsedKB / 1024;
        $swapAvailMB=$swapAvailKB / 1024;
        $swapTotal=int($swapUsedMB + $swapAvailMB);
}

# Gather OS Info
sub OSINFO {

	open (UNAME,"$ENV{'UNAME_CMD'} -a|")
		or die "ERROR: couldn't open $ENV{'UNAME_CMD'}: $!\n";

	my $data=<UNAME>;
	close(UNAME);

	$data =~ m/\S+\s+\S+\s+(\S+)\s+(\S+)/;

	$osVersion="$1";
	$kernelVersion="$2";
}

sub PatchINFO {

	my $patchDir="/var/sadm/patch";

        opendir(PATCHDIR, "$patchDir")
                or die("ERROR: Couldn't open dir $patchDir: $!\n");

                while ($patchName = readdir(PATCHDIR)) {
                        if ($patchName ne "." && $ptachName ne "..") {
				next if ($patchName =~ m/^\./);
				push(@patchesArray, $patchName);
                        }
                }
        closedir(PATCHDIR);

	$patches=join(",", @patchesArray);
}

# Get configuration dynamically from perf-conf
sub GetConfiguration {

        my $configfile="$perfhome/etc/perf-conf";
        my $hashref = shift;

        open(FILE, $configfile)
                or die "ERROR: Couldn't open FileHandle for $configfile: $!\n";

        my @data=<FILE>;
        foreach $line (@data) {

                # Skip line if commented out
                next if ($line =~ m/^#/);
		next if ($line =~ m/^\s+/);
                $line =~ m/(\w+)=(.+)/;

                my $key=$1;
                my $value=$2;

                $hashref->{$key}=$value;
        }
        close(FILE);
}

# Get path to perfctl executable
sub PATH {
  my $path = PerlApp::exe();
	$path =~ s/\/\w*$//;
        return $path;
}

# Send Data to Perf Server
$perf_out="$os info $cpuNum $cpuModel $cpuSpeed $memTotal $osVersion $kernelVersion $patches";

#print "test: $perf_out\n";

open(PERFOUT, ">> $perfhome/tmp/perf.out")
	or die "WARNING: Couldn't open file handle for $perfhome/tmp/perf.out: $!\n";

flock(PERFOUT, LOCK_EX)
	or die "WARNING: Couldn't obtain exclusive lock on $perfhome/tmp/perf.out: $!\n";

print PERFOUT "$perf_out\n";

close (PERFOUT);
