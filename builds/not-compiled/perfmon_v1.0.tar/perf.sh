#!/bin/sh

# Start script for perfmon
#set -x

PATH="/bin:/sbin:/usr/bin:/usr/local/bin:/usr/local/sbin:/usr/sbin:/usr/ucb"
PERFHOME="/path/to/perfhome"
PERFOUT="$PERFHOME/perfd.log"
SERVER="1"
VER="1.0"

CAT=`which cat`
AWK=`which awk`
PS=`which ps`
GREP=`which grep`
KILL=`which kill`
RM=`which rm`

# Ensure Perfmon will not run as root
if [ $UID -eq 0 ];then
        echo "Perfmon Cannot Be Run as root!"
        exit 1
fi

case "$1" in
'stop')
	echo "Stoping Permon $VER"
	if [ $SERVER -eq 1 ]; then
        	PERFD_PID=`$CAT $PERFHOME/tmp/perfd.pid`
        	PERFCTL_PID=`$CAT $PERFHOME/tmp/perfctl.pid`
	else
        	PERFCTL_PID=`$CAT $PERFHOME/tmp/perfctl.pid`
	fi

	if [ $SERVER -eq 1 ]; then
               	echo -n "Stoping Perfd..."
               	$KILL $PERFD_PID
		sleep 1
               	if [ $? -eq 0 ]; then
                       	echo "Done!"
                       	RUNNING=0
		fi
                echo -n "Stoping Perfctl..."
                $KILL $PERFCTL_PID
		sleep 1
                if [ $? -eq 0 ]; then
              		echo "Done!"
                       	RUNNING=0
		fi
	else
		if [ $PS |$GREP PERFCTL_PID ]; then
                	echo -n "Stoping Perfctl..."
                	$KILL $PERFCTL_PID
			sleep 1
                	if [ $? -eq 0 ]; then
                        	echo "Done!"
                        	RUNNING=0
                	fi
		fi
		if [ $RUNNING ne 0 ]; then
			echo "Perfmon did not exir gracefully..There may still be rogue processes running"
		fi
	fi
        ;;
'start')
	echo "Starting Perfmon $VER"
	# Clean up temporary Sar files before starting
	$RM -f $PERFHOME/tmp/sar.out.*
	if [ $SERVER -eq 1 ]; then  
        	if [ -x $PERFHOME/bin/perfd.pl ]; then
                	echo -n "PerfMon Daemon Starting..."
                	$PERFHOME/bin/perfd.pl &
			sleep 1
			if [ $? -eq 0 ]; then
				echo "Done!"
			else
				echo "Problem Starting Perfd!"
			fi

        	fi
        	if [ -x $PERFHOME/bin/perfctl.pl ]; then
                	echo -n "Perfmon Client Starting..."
                	$PERFHOME/bin/perfctl.pl &
			sleep 1
			if [ $? -eq 0 ]; then
				echo "Done!"
			else
				echo "Problem Starting Perfctl!"	
			fi
		fi
	else

        if [ -x $PERFHOME/bin/perfctl.pl ]; then
                echo -n "Perfmon Client Starting..."
                $PERFHOME/bin/perfctl.pl &
                if [ $? -eq 0 ]; then
                        echo "Done!"
                else
                        echo "Problem Starting Perfctl!"       
                fi
        fi
fi
        ;;

*)
        echo "Usage: $0 ( start | stop )"
        exit 1
        ;;
esac

exit 0


