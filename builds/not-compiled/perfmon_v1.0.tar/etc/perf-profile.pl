#!/usr/bin/perl

$perfhome="/path/to/perfhome";
$perf="$perfhome/bin/perf.pl";
$perfserver="192.168.1.5";
$sar_last_pid="$perfhome/tmp/sar_last.pid";
$sar_cmd="/usr/bin/sar $sar_flag -f";

$uptime_cmd="/usr/bin/uptime";
$inode_cmd="df -i";
$fs_cmd="df -k";
