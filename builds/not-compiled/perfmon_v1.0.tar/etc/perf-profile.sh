# Profile for Perfmon
PERF="/work/projects/perfmon/bin/perf.pl"
PERFSERVER="192.168.1.9"

# Generic (Multi-OS) Unix Commands
UNAME="/usr/bin/uname"
AWK="/usr/bin/awk"
EXPR="/usr/bin/expr"
CAT="/bin/cat"
SED="/usr/bin/sed"
RM="/usr/bin/rm"
TAIL="/usr/bin/tail"
HEAD="/usr/bin/head"
GREP="/usr/bin/grep"
TOP="/usr/local/bin/top"
VMSTAT="/usr/bin/vmstat"
NETSTAT="/usr/bin/netstat"
UPTIME="/usr/bin/uptime"
PS="/bin/ps"
KILL="/usr/bin/kill"
MPSTAT="/usr/bin/mpstat"
KSTAT="/usr/bin/kstat"

# OS Specific

# Solaris
PSRINFO="/usr/sbin/psrinfo"

