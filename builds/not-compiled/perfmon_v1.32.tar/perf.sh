#!/bin/sh

# Start script for perfmon
#set -x

PATH="/bin:/sbin:/usr/bin:/usr/local/bin:/usr/local/sbin:/usr/sbin:/usr/ucb"
PERFHOME="/path/to/perfhome"
PERFOUT="$PERFHOME/perfd.log"
SERVER="1"
VER="1.32"

# Define path to required programs
CAT=`which cat`
AWK=`which awk`
PS=`which ps`
GREP=`which grep`
KILL=`which kill`
RM=`which rm`

# Ensure Perfmon will not run as root
if [ $UID -eq 0 ];then
        echo "ERROR: PerfMon Cannot Be Run as root!"
        exit 1
fi

case $1 in
stop | restart)
	echo ""
	echo "Stopping PerfMon $VER"
	echo "`date '+[%a %b %d %H:%M:%S %Y]'` Stopping PerfMon $VER" >>$PERFHOME/var/perfd.log

	#Server Shutdown
	if [ $SERVER -eq 1 ]; then
        	PERFD_PID=`$CAT $PERFHOME/tmp/perfd.pid`
        	PERFCTL_PGID=`$CAT $PERFHOME/tmp/perfctl.pgid`
	else
        	PERFCTL_PGID=`$CAT $PERFHOME/tmp/perfctl.pgid`
	fi

	if [ $SERVER -eq 1 ]; then
               	echo -n "Stopping Perfd..."
               	$KILL -9 $PERFD_PID
		sleep 1
               	if [ $? -eq 0 ]; then
                       	echo "Done!"
                       	RUNNING=0
		fi
                echo -n "Stopping Perfctl..."
                $KILL -9 -$PERFCTL_PGID
		sleep 1
                if [ $? -eq 0 ]; then
              		echo "Done!"
                       	RUNNING=0
		fi
	else
		# Client Shutdown
                echo -n "Stopping Perfctl..."
                $KILL -9 -$PERFCTL_PGID
		sleep 1
                if [ $? -eq 0 ]; then
                       	echo "Done!"
                       	RUNNING=0
		fi
		if [ $RUNNING -ne 0 ]; then
			echo "WARNING: PerfMon did not exit gracefully..There may still be rogue processes running"
		fi
	fi

	if [ $1 = stop ]; then
		exit 0
	fi

	echo "`date '+[%a %b %d %H:%M:%S %Y]'` Restarting PerfMon $VER" >>$PERFHOME/var/perfd.log

        ;;
start)
	echo "`date '+[%a %b %d %H:%M:%S %Y]'` Starting PerfMon $VER" >>$PERFHOME/var/perfd.log
        # Determine if PerfMon is already running
	PROCS=0
	if [ -f $PERFHOME/tmp/perfd.pid -a -f $PERFHOME/tmp/perfctl.pgid ]; then
		PERFD_PID=`$CAT $PERFHOME/tmp/perfd.pid`
		PERFCTL_PID=`$CAT $PERFHOME/tmp/perfctl.pgid`

		$PS |$GREP $PERFD_PID 1>/dev/null
		if [ $? -eq 0 ]; then
			PROCS=1
		fi
		$PS |$GREP $PERFCTL_PID 1>/dev/null
		if [ $? -eq 0 ]; then
			PROCS=1
		fi

		if [ $PROCS -eq 1 ]; then
			echo "WARINING: PerfMon processes exist! Start Aborted"
			exit 1
		fi
	fi

        ;;

*)
        echo "Usage: $0 ( start|restart|stop )"
        exit 1
        ;;
esac

# PerfMon startup
echo ""
echo "Starting PerfMon $VER"

# Clean up temporary Sar files before starting
$RM -f $PERFHOME/tmp/sar.out.*

# Server startup
if [ $SERVER -eq 1 ]; then  
       	if [ -x $PERFHOME/bin/perfd.pl ]; then
               	echo -n "PerfMon Daemon Starting..."
               	$PERFHOME/bin/perfd.pl &
		sleep 1
		if [ $? -eq 0 ]; then
			echo "Done!"
		else
			echo "ERROR: Problem Starting Perfd!"
		fi

       	fi
       	if [ -x $PERFHOME/bin/perfctl.pl ]; then
               	echo -n "PerfMon Client Starting..."
               	$PERFHOME/bin/perfctl.pl &
		sleep 1
		if [ $? -eq 0 ]; then
			echo "Done!"
		else
			echo "ERROR: Problem Starting Perfctl!"	
		fi
	fi
else

# Client Startup
if [ -x $PERFHOME/bin/perfctl.pl ]; then
	echo -n "PerfMon Client Starting..."
	$PERFHOME/bin/perfctl.pl &
	if [ $? -eq 0 ]; then
		echo "Done!"
		else
		echo "ERROR: Problem Starting Perfctl!"       
	fi
fi
fi
exit 0
