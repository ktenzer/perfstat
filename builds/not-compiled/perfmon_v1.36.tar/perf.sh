#!/bin/sh

# Start script for perfmon
#set -x

PATH="/bin:/sbin:/usr/bin:/usr/local/bin:/usr/local/sbin:/usr/sbin:/usr/ucb"
PERFHOME=/path/to/perfhome
PERFOUT="$PERFHOME/perfd.log"
VER="1.35"

# Define path to required programs
CAT=`which cat`
AWK=`which awk`
PS=`which ps`
GREP=`which grep`
SED=`which sed`
KILL=`which kill`
RM=`which rm`
ID=`which id`
UNAME=`which uname`

# Figure out is this is a PerfStat Server
SERVER=`$GREP ^SERVER= $PERFHOME/etc/perf-conf |$SED 's/SERVER=//'` 

# Get Metrics list
METRICS=`$GREP METRICS= $PERFHOME/etc/perf-conf |$SED 's/METRICS=//'`

# Determine OS
OS=`$UNAME -s`

# Setup echo statements
if [ $OS = "SunOS" ];then
	
	# Set Sun speficif variables
	SETPGRP=`which setpgrp`

	# PerfMon echo statements
        ECHO_START_PERFD="PerfMon Daemon Starting...\c"
        ECHO_START_PERFCTL="PerfMon Client Starting...\c"

        ECHO_STOP_PERFD="Stopping PerfMon Daemon...\c"
        ECHO_STOP_PERFCTL="Stopping PerfMon Client...\c"

	# PerfMon startup commands
	PERFD_CMD="$SETPGRP $PERFHOME/bin/perfd.pl"
	PERFCTL_CMD="$SETPGRP $PERFHOME/bin/perfctl.pl"

elif [ $OS = "Linux" ];then

	# PerfMon echo statements
        ECHO_START_PERFD="-n PerfMon Daemon Starting..."
        ECHO_START_PERFCTL="-n PerfMon Client Starting..."

        ECHO_STOP_PERFD="-n Stopping PerfMon Daemon..."
        ECHO_STOP_PERFCTL="-n Stopping PerfMon Client..."

	# PerfMon startup commands
	PERFD_CMD="$PERFHOME/bin/perfd.pl"
	PERFCTL_CMD="$PERFHOME/bin/perfctl.pl"
fi

# Ensure Perfmon will not run as root
USERID=`$ID |sed 's/[()=]/ /g' |$AWK '{print $2}'`

if [ $USERID -eq 0 ];then
        echo "ERROR: PerfMon Cannot Be Run as root!"
        exit 1
fi


case $1 in
stop | restart)

        # Determine if PerfMon is running
        PROCS=0

	if [ -f $PERFHOME/tmp/perfd.pid ]; then
                PERFD_PID=`$CAT $PERFHOME/tmp/perfd.pid`
                $PS -ef |$GREP $PERFD_PID |$GREP -v grep 1>/dev/null
                if [ $? -eq 0 ]; then
                        PROCS=1
                fi
	fi

	if [ -f $PERFHOME/tmp/perfctl.pgid ]; then
                PERFCTL_PID=`$CAT $PERFHOME/tmp/perfctl.pgid`
                $PS -efj |$GREP $PERFCTL_PID |$GREP -v grep 1>/dev/null
                if [ $? -eq 0 ]; then
                        PROCS=1
                fi
	fi

	if [ $PROCS -eq 0 ]; then
		echo "WARNING: Perfmon is not currently runnig! Shutdown Aborted"
		exit 1
        fi

        echo ""
        echo "Stopping PerfMon $VER"
        echo "`date '+[%a %b %d %H:%M:%S %Y]'` Stopping PerfMon $VER" >>$PERFHOME/var/perfd.log

	#Server Shutdown
	if [ "$SERVER" = "y" -o "$SERVER" = "Y" ]; then
        	PERFD_PID=`$CAT $PERFHOME/tmp/perfd.pid`
        	PERFCTL_PGID=`$CAT $PERFHOME/tmp/perfctl.pgid`
	else
        	PERFCTL_PGID=`$CAT $PERFHOME/tmp/perfctl.pgid`
	fi

	if [ "$SERVER" = "y" -o "$SERVER" = "Y" ]; then
               	echo $ECHO_STOP_PERFD
               	$KILL -9 $PERFD_PID
		sleep 1
               	if [ $? -eq 0 ]; then
                       	echo "Done!"
                       	RUNNING=0
		fi
                echo $ECHO_STOP_PERFCTL
                $KILL -9 -$PERFCTL_PGID
		sleep 1
                if [ $? -eq 0 ]; then
              		echo "Done!"
                       	RUNNING=0
		fi
	else
		# Client Shutdown
                echo $ECHO_STOP_PERFCTL
                $KILL -9 -$PERFCTL_PGID
		sleep 1
                if [ $? -eq 0 ]; then
                       	echo "Done!"
                       	RUNNING=0
		fi
		if [ $RUNNING -ne 0 ]; then
			echo "WARNING: PerfMon did not exit gracefully..There may still be rogue processes running"
		fi
	fi

	if [ $1 = stop ]; then
		exit 0
	fi

	echo "`date '+[%a %b %d %H:%M:%S %Y]'` Restarting PerfMon $VER" >>$PERFHOME/var/perfd.log

        ;;
start)

        # Determine if PerfMon is running
	PROCS=0

	if [ -f $PERFHOME/tmp/perfd.pid ]; then
                PERFD_PID=`$CAT $PERFHOME/tmp/perfd.pid`
                $PS -ef |$GREP $PERFD_PID |$GREP -v grep 1>/dev/null
                if [ $? -eq 0 ]; then
                        PROCS=1
                fi
	fi

	if [ -f $PERFHOME/tmp/perfctl.pgid ]; then
                PERFCTL_PID=`$CAT $PERFHOME/tmp/perfctl.pgid`
                $PS -efj |$GREP $PERFCTL_PID |$GREP -v grep 1>/dev/null
                if [ $? -eq 0 ]; then
                        PROCS=1
                fi
	fi

	if [ $PROCS -ne 0 ]; then
		echo "WARNING: Perfmon processes are running! Startup Aborted"
		exit 1
        fi

	echo "`date '+[%a %b %d %H:%M:%S %Y]'` Starting PerfMon $VER" >>$PERFHOME/var/perfd.log

        ;;

*)
        echo "Usage: $0 ( start|restart|stop )"
        exit 1
        ;;
esac

# PerfMon startup
echo ""
echo "Starting PerfMon $VER"

# Clean up temporary Sar files before starting
$RM -f $PERFHOME/tmp/sar.out.*

# Server startup
if [ "$SERVER" = "y" -o "$SERVER" = "Y" ]; then
       	if [ -x $PERFHOME/bin/perfd.pl ]; then
               	echo $ECHO_START_PERFD
		$PERFD_CMD &
		sleep 1
		if [ $? -eq 0 ]; then
			echo "Done!"
		else
			echo "ERROR: Problem Starting Perfd!"
		fi

       	fi
       	if [ -x $PERFHOME/bin/perfctl.pl ]; then
               	echo $ECHO_START_PERFCTL
               	$PERFCTL_CMD &
		sleep 1
		if [ $? -eq 0 ]; then
			echo "Done!"
			echo "Collecting data for: $METRICS"
		else
			echo "ERROR: Problem Starting Perfctl!"	
		fi
	fi
else

# Client Startup
if [ -x $PERFHOME/bin/perfctl.pl ]; then
	echo $ECHO_START_PERFCTL
	$PERFCTL_CMD &
	sleep 1
	if [ $? -eq 0 ]; then
		echo "Done!"
	else
		echo "ERROR: Problem Starting Perfctl!"       
	fi
fi
fi
exit 0
