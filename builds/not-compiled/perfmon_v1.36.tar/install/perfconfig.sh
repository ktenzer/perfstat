#!/bin/bash

PATH=/bin:/usr/bin:/sbin:/usr/sbin:/usr/local/sbin:/usr/local/bin
export PATH

VERSION=1.36

### Find path to needed commands ###
UNAME=`which uname`
CAT=`which cat`
GREP=`which grep`
AWK=`which awk`
SED=`which sed`
MV=`which mv`
RM=`which rm`
CP=`which cp`
MKDIR=`which mkdir`
GUNZIP=`which gunzip`
TAR=`which tar`
PWD=`which pwd`
CLEAR=`which clear`

# Main sub
MAIN() {

### Get path to perfhome prompted by user ###
GetPerfhome

$CLEAR

echo "PerfStat $VERSION"
echo ""
echo "Choose Default or Custom PerfStat Configuration:" 

select myselection in Default Custom Exit       

do                                                            
	case $myselection in                                          
		Default)                                                      
			DEFAULT	
			;;                                                    
		Custom)                                                     
			CUSTOM	
			;;                                                    
		Exit)
			exit
			;;
	esac                                                          
done 
}

### Get Hostname, IP, and OS ###
HOSTNAME=`$UNAME -n`
IP=`$GREP $HOSTNAME /etc/hosts |$AWK '{print $1}'`
IP=`echo $IP |$SED 's/127.0.0.1 //'`
OS=`$UNAME -a |awk '{print $1}'`

# Install PerfServer sub
InstallPerfServer() {

	### Start PerfStat Server Install ###
	echo ""
	echo -n "You are about to Configure The PerfStat Server. Enter [y/n] to continue: " 

	read ANS

	if [ "$ANS" = "y" -o "$ANS" = "Y" ];then
		:
	else
		exit
	fi

	### Get Current Settings ###
	GetServer

	### Set Server On ###
	SERVER="Y"

	### Get Hostname ###
	$CLEAR
	echo ""
	echo -n "Enter hostname or use default [$HOSTNAME]: "

	read ANS

	if [ "$ANS" = "" ];then
		:
	else
		HOSTNAME=$ANS
	fi

	### Get IP ###
	$CLEAR
	echo ""
	echo -n "Enter IP or use default [$IP]: "

	read ANS

	if [ "$ANS" = "" ];then
		:
	else
		IP=$ANS
	fi

	### Configure Events ###
	$CLEAR
	echo ""
	echo -n "Would you like to enable Event Logging [Y/N]? Current value [$EVENTLOG]: "

	read ANS

	if [ "$ANS" = "y" -o "$ANS" = "Y" ];then
		EVENTLOG=Y
	elif [ "$ANS" = "" ];then
		:
	else
		EMAIL="N"
		EMAIL_ALL="N"
		EMAIL_CRIT="N"
		EMAIL_WARN="N"
		SMTP_SERVER="IP"
		EMAIL_TO="myname@mydomain.com"
		EMAIL_FROM="myname@mydomain.com"
		EMAIL_SUBJECT="PerfStat Alert"	
		EVENTLOG="N"
		LOGSIZE="100"
	fi

	if [ $EVENTLOG = "Y" ];then

		### Configure Log Size ###
		$CLEAR
		echo ""
		echo -n "Enter EventLog file size in lines? Current value [$LOGSIZE]: "

		read ANS

		if [ "$ANS" = "" ];then
			LOGSIZE=100	
		elif [ "$ANS" = "" ];then
			:
		else
			LOGSIZE=$ANS
		fi
	
	fi

	### Configure Email (optional) ###
	$CLEAR
	if [ "$EVENTLOG" = "Y" ];then
		echo ""
		echo -n "Would you like to enable EMAIL notification [Y/N]? Current value [$EMAIL]: "

		read ANS

		if [ "$ANS" = "y" -o "$ANS" = "Y" ];then
			EMAIL="Y"
		elif [ "$ANS" = "" ];then
			:
		else
			EMAIL="N"
			EMAIL_ALL="N"
			EMAIL_CRIT="N"
			EMAIL_WARN="N"
			SMTP_SERVER="IP"
			EMAIL_TO="myname@mydomain.com"
			EMAIL_FROM="myname@mydomain.com"
			EMAIL_SUBJECT="PerfStat Alert"	
		fi

		### Configure EMAIL Alerting ###
		$CLEAR
		if [ "$EMAIL" = "Y" ];then
			echo ""
			echo "Choose when alerts should be sent.  Alerts can"
			echo "be sent when a status changes to OK, WARN, or CRIT."
			echo ""
			echo "all - Sends alert whenever status changes"
			echo "warn - Sends alert only when status changes to WARN"
			echo "crit -  Sends alert only when status changes to CRIT"
			echo "both - Sends alert when status changes to CRIT or WARN (recommended)"
			echo ""
			echo -n "Choose [all/warn/crit/both]: "

			read ANS

			if [ "$ANS" = "all" ];then
				EMAIL_ALL=Y
				EMAIL_WARN=Y
				EMAIL_CRIT=Y
			elif [ "$ANS" = "warn" ];then
				EMAIL_ALL=N
				EMAIL_WARN=Y
				EMAIL_CRIT=N
			elif [ "$ANS" = "crit" ];then
				EMAIL_ALL=N
				EMAIL_WARN=N
				EMAIL_CRIT=Y
			elif [ "$ANS" = "both" ];then
				EMAIL_ALL=N
				EMAIL_WARN=Y
				EMAIL_CRIT=Y
			else
				echo "Incorrect selection, you must choose [all/warn/crit/both]! Exiting"
				exit
			fi

			### Configure SMTP Server ###
			$CLEAR
			echo ""
			echo -n "Enter the IP of your SMTP Server? Current Value [$SMTP_SERVER]: "

			read ANS

			if [ "$ANS" = "" ];then
				:
			else
				SMTP_SERVER=$ANS
			fi


			### Configure EMAIL TO ###
			$CLEAR
			echo ""
			echo -n "Enter EMAIL (TO) address for alerts (Must Be Valid)? Current value [$EMAIL_TO]: "

			read ANS

			if [ "$ANS" = "" ];then
				:
			else
				EMAIL_TO="$ANS"
			fi

			### Configure EMAIL FROM ###
			$CLEAR
			echo ""
			echo -n "Enter EMAIL (FROM) address for alerts (Must Be Valid)? Current value [$EMAIL_FROM]: "

			read ANS

			if [ "$ANS" = "" ];then
				:
			else
				EMAIL_FROM="$ANS"
			fi

			### Configure EMAIL SUBJECT ###
			$CLEAR
			echo ""
			echo -n "Enter EMAIL (SUBJECT) for alerts? Current value [$EMAIL_SUBJECT]: "

			read ANS

			if [ "$ANS" = "" ];then
				:
			else
				EMAIL_SUBJECT="$ANS"
			fi

		fi
	fi

	### Show user Settings ###
	$CLEAR
	echo ""
	echo "You have selected the following settings:"
	echo "PERFHOME=$PERFHOME"
	echo "HOSTNAME=$HOSTNAME"
	echo "IP=$IP"
	echo "EVENTLOG=$EVENTLOG"
	echo "LOGSIZE=$LOGSIZE"
	echo "EMAIL=$EMAIL"
	echo "EMAIL_ALL=$EMAIL_ALL"
	echo "EMAIL_WARN=$EMAIL_WARN"
	echo "EMAIL_CRIT=$EMAIL_CRIT"
	echo "SMTP_SERVER=$SMTP_SERVER"
	echo "EMAIL_TO=$EMAIL_TO"
	echo "EMAIL_FROM=$EMAIL_FROM"
	echo "EMAIL_SUBJECT=$EMAIL_SUBJECT"

	echo ""
	echo -n "Are these settings correct [y/n]: "

	read ANS

	if [ "$ANS" = "y" -o "$ANS" = "Y" ];then
		# If all settings are correct update perf-conf
		UpdateServer
	else
		echo ""
		echo "PerfServer settings have not been saved!"
	fi

}

# Install PerfClient sub
InstallPerfClient() {

	###Set Metrics ###
	METRICS="cpu.pl fs.pl io.pl memory.pl procs.pl tcp.pl"

	### Get current settings ###
	GetClient

	### Set Client On ###
	CLIENT="Y"

	### Start PerfStat Client Install ###
	$CLEAR
	echo ""
	echo -n "You are about to Configure The PerfStat Client. Enter [y/n] to continue: " 

	read ANS

	if [ "$ANS" = "y" -o "$ANS" = "Y" ];then
		:
	else
		exit
	fi

	### Determine OS ###
	$CLEAR
	echo ""
	echo -n "PerfStat has detected your OS to be [$OS].  Is that correct [y/n]: "

	read ANS

	if [ "$ANS" = "y" -o "$ANS" = "Y" ];then
		:
	else
		echo ""
		echo -n "PerfStat supports the following Unix OS's (Solaris/Linux).  Please Enter [s] Solaris [l] Linux or [n] to exit: " 

		read ANS

		if [ "$ANS" = "s" -o "$ANS" = "S" ];then
			OS="SunOS"
		elif [ "$ANS" = "l" -o "$ANS" = "L" ];then
			OS="Linux"
		else
			exit
		fi
	fi

	### Get PerfServer IP ###
	$CLEAR
	echo ""
	echo -n "Enter the IP of the PerfServer? Current value [$PERFSERVER]: "

	read ANS

	if [ "$ANS" = "" ];then
		:
	else
		PERFSERVER="$ANS"
	fi

	### Find path to SAR ###
	SAR_CMD=`which sar`

	if [ $? != 0 ];then
		$CLEAR
		echo ""
		echo -n "Could not find path to sar.  Enter path to sar or [n] to exit: "

		read ANS

		if [ "$ANS" = "n" -o "$ANS" = "N" ];then
			echo ""
			echo "PerfClient install aborted!"
			echo -n "Sar is required for installing PerfClient!"

		else
			SAR_CMD="$ANS"
		fi	
	fi	

	### Find path to uptime command ###
	UPTIME_CMD=`which uptime`

	if [ $? != 0 ];then
		$CLEAR
		echo ""
		echo -n "Could not find path to uptime command.  Enter path to uptime command or [n] to disable cpu metrics: "

		read ANS

		if [ "$ANS" = "n" -o "$ANS" = "N" ];then
			echo "Metrics for cpu will be disabled"
			CPU_DISABLED="1"
		fi
	fi

	### Find path to df command ###
	DF_CMD=`which df`

	if [ $? != 0 ];then
		$CLEAR
		echo ""
		echo -n "Could not find path to df command.  Enter path to df command or [n] to disable file system  metrics: "

		read ANS
 
		if [ "$ANS" = "n" -o "$ANS" = "N" ];then
			echo "Metrics for file system will be disabled"
			FS_DISABLED="1"
		fi
	fi

	### Determine Metrics ###
	if [ "$CPU_DISABLED" = "1" ];then
		METRICS=`echo "$METRICS" |$SED 's/cpu.pl //'`
	elif [ "$FS_DISABLED" = "1" ];then
		METRICS=`echo "$METRICS" |$SED 's/fs.pl //'`
	fi

	### Set OS specific settings ###
	OSSettings

	### Show User Settings ###
	$CLEAR
	echo ""
	echo "You have selected the following settings:"
	echo "PERFHOME=$PERFHOME"
	echo "OS=$OS"
	echo "PERFSERVER=$PERFSERVER"
	echo "SAR_CMD=$SAR_CMD"
	echo "UPTIME_CMD=$UPTIME_CMD"
	echo "INODE_CMD=$INODE_CMD"
	echo "FS_CMD=$FS_CMD"
	echo "METRICS=$METRICS"

	echo ""
	echo -n "Are these settings correct [y/n]: "

	read ANS

	if [ "$ANS" = "y" -o "$ANS" = "Y" ];then
		# If all settings are correct update perf-conf
		UpdateClient
	else
		echo ""
		echo "PerfClient settings have not been saved!"
	fi

}

### Install sub ###
DEFAULT () {
	$CLEAR

	DEFAULT="1"

	### Configure PerfServer ###
	InstallPerfServer	

	### Configure PerfCLient ###
	InstallPerfClient	

	### Install Sar ###
	InstallSar

	### Install RRDTool
	InstallRRD
}

### Modify sub ###
CUSTOM() {
	$CLEAR

	echo ""
	echo "Choose one of the following Components to Configure:"

	select myselection in PerfServer PerfClient Sar RRDTOOL Management Back Exit
	do
		case $myselection in
			PerfServer)
				InstallPerfServer	
				;;
			PerfClient)
				InstallPerfClient	
				;;
			Sar)
				InstallSar	
				;;
			RRDTOOL)
				InstallRRD
				;;
			Management)
				MANAGEMENT
				;;
			Back)
				MAIN
				;;
			Exit)
				exit
				;;
		esac
	done
}

### OS Specific stuff ###

OSSettings () {
	case $OS in
		Linux)
			INODE_CMD="$DF_CMD -i"
			FS_CMD="$DF_CMD -k"
			;;
		SunOS)
			INODE_CMD="$DF_CMD -i"
			FS_CMD="$DF_CMD -k"
			;;
	esac
}

### Install Sar Program ###
InstallSar () {

	if [ "$DEFAULT" = "1" ];then

		ERROR="0"

		echo ""
		echo -n "Installing Sar..."

		if [ ! -d ../misc/sar ];then

			if [ ! -d $PERFHOME/misc ];then
				$MKDIR $PERFHOME/misc
			fi

			$MKDIR $PERFHOME/misc/sar > 2&>1
			if [ $? != 0 ];then
				echo -n "The mkdir command failed, Ensure directory PERFHOME/misc exists!"
				exit
			fi
		fi

		$CP sar/sar.gz $PERFHOME/misc/sar/ > 2&>1
		if [ $? != 0 ];then
			echo -n "Failed.  The cp command failed, check permissions!"
			ERROR=1
		fi

		$GUNZIP -f $PERFHOME/misc/sar/sar.gz > 2&>1
		if [ $? != 0 ];then
			echo -n "Failed.  The gunzip command failed, check permissions!"
			ERROR=1
		fi

		if [ "$ERROR" != "1" ];then
			echo -n "Done!"
			echo""
		fi
		echo ""
	else
		echo ""
		echo -n "Enter Install dir for Sar: "

		read ANS

		PATH="$ANS"

		if [ ! -d $PATH ];then
			echo "The directory $PATH doesn't exist.  Please create and retry!"
			exit
		fi

		echo  ""
		echo -n "Installing Sar in $PATH..."

		$CP sar/sar.gz $PATH > 2&>1
		if [ $? != 0 ];then
			echo -n "Failed.  The cp command failed, check permissions!"
			ERROR=1
		fi

		$GUNZIP -f $PATH/sar.gz > 2&>1
		if [ $? != 0 ];then
			echo -n "Failed.  The gunzip command failed, check permissions!"
			ERROR=1
		fi

		if [ "$ERROR" != "1" ];then
			echo -n "Done!"
			echo ""
		fi
		echo ""
	fi
}

### Install RRDTOOL Program ###
InstallRRD () {

	if [ "$DEFAULT" = "1" ];then

		ERROR="0"
		
		echo ""
		echo -n "Installing RRDTool..."

		if [ ! -d $PERFHOME/misc/rrdtool ];then

			if [ ! -d $PERFHOME/misc ];then
				$MKDIR $PERFHOME/misc
			fi

			$MKDIR $PERFHOME/misc/rrdtool > 2&>1
			if [ $? != 0 ];then
				echo -n "The mkdir command failed, Ensure directory PERFHOME/misc exists!"
				exit
			fi
		fi

		$CP rrdtool/rrdtool.tar.gz $PERFHOME/misc/rrdtool/ > 2&>1
		if [ $? != 0 ];then
			echo -n "Failed.  The cp command failed, check permissions!"
			ERROR=1
		fi

		$GUNZIP -f $PERFHOME/misc/rrdtool/rrdtool.tar.gz > 2&>1
		if [ $? != 0 ];then
			echo -n "Failed.  The gunzip command failed, check permissions!"
			ERROR=1
		fi

		$TAR xvf $PERFHOME/misc/rrdtool/rrdtool.tar -C $PERFHOME/misc/rrdtool/ > 2&>1 
		if [ $? != 0 ];then
			echo -n "Failed.  The tar command failed, check permissions!"
			ERROR=1
		fi

		$RM $PERFHOME/misc/rrdtool/rrdtool.tar > 2&>1
		if [ $? != 0 ];then
			echo -n "Failed.  The rm command failed, check permissions!"
			ERROR=1
		fi

		if [ "$ERROR" != "1" ];then
			echo -n "Done!"
			echo ""
		fi
		echo ""
	else
		echo ""
		echo -n "Enter Install dir for RRDTool: "

		read ANS

		PATH="$ANS"

		if [ ! -d $PATH ];then
			echo "The directory $PATH doesn't exist.  Please create and retry!"
			exit
		fi

		echo ""
		echo -n "Installing RRDTool in $PATH..."

		$CP rrdtool/rrdtool.tar.gz $PATH > 2&>1
		if [ $? != 0 ];then
			echo -n "Failed.  The cp command failed, check permissions!"
			ERROR=1
		fi

		$GUNZIP -f $PATH/rrdtool.tar.gz > 2&>1
		if [ $? != 0 ];then
			echo -n "Failed.  The gunzip command failed, check permissions!"
			ERROR=1
		fi

		$TAR xvf $PATH/rrdtool.tar -C $PATH > 2&>1
		if [ $? != 0 ];then
			echo -n "Failed.  The tar command failed, check permissions!"
			ERROR=1
		fi

		$RM $PATH/rrdtool.tar > 2&>1
		if [ $? != 0 ];then
			echo -n "Failed.  The rm command failed, check permissions!"
			ERROR=1
		fi

		if [ "$ERROR" != "1" ];then
			echo -n "Done!"
			echo ""
		fi
		echo ""
	fi
}

MANAGEMENT () {
	$CLEAR

	echo ""
	echo "Choose one of the following Management Options:"

	select myselection in "Create Client TarBall" "Add New Client" Back Exit
	do
		case $myselection in
			"Create Client TarBall")
				;;
			"Add New Client")
				AddNewClient
				;;
			Back)
				CUSTOM
				;;
			Exit)
				exit
				;;
		esac
	done

}

### Add New Client ###
AddNewClient () {

	$CLEAR

	echo ""
	echo -n "You are about to add a new client to PerfStat.  Enter [y/n] to continue: "

	read ANS

	if [ "$ANS" = "y" -o "$ANS" = "Y" ];then
		:
	else
		exit
	fi

	### Get hostname of new client ###
	$CLEAR

	echo ""
	echo -n "Enter the HOSTNAME (FQDN Recommended) of the client: "

	read ANS

	CLIENTHOSTNAME="$ANS"

	### Get IP of new client ###
	$CLEAR

	echo ""
	echo -n "Enter the IP of $CLIENTHOSTNAME: "

	read ANS

	CLIENTIP="$ANS"

	### Show user selections and update PerfServer ###
	$CLEAR

	echo ""
	echo "You have selected the following settings:"
	echo "HOSTNAME=$CLIENTHOSTNAME"
	echo "IP=$CLIENTIP"
	echo ""
	echo -n "Are these settings correct [y/n]: "

	read ANS

	if [ "$ANS" = "y" -o "$ANS" = "Y" ];then
		echo -n "Updating PerfServer config"
		echo -n "."
		sleep 1
		echo -n "."

		### Check if IP is already in perf-hosts ###
		$GREP $CLIENTHOSTNAME $PERFHOME/etc/perf-hosts > 2&>1
		if [ $? != 0 ];then
			echo -e "$CLIENTIP\t\t\t$CLIENTHOSTNAME" >> $PERFHOME/etc/perf-hosts
			echo -n "."
			echo -n "Done!"
			echo ""
		else
			echo -n "."
			echo -n "Failed!  $CLIENTHOSTNAME already exists in perf-hosts"
			echo ""
			exit
		fi
		echo ""
	else
		echo ""
		echo "PerfServer settings have not been saved!"
	fi
	
}

### Update PerfServer Config ###
UpdateServer () {

	echo ""
	echo -n "Updating PerfServer config"

	$CAT $CONFFILE |$SED 's/PERFHOME=[A-Za-z0-9\/-]*/PERFHOME='"$PERFHOME_ESCAPE"'/' > $TMPCONFFILE
	$MV $TMPCONFFILE $CONFFILE
	echo -n "."

	$CAT $CONFFILE |$SED 's/EMAIL=[A-Za-z0-9.\/]*/EMAIL='$EMAIL'/' > $TMPCONFFILE
	$MV $TMPCONFFILE $CONFFILE
	echo -n "."

	$CAT $CONFFILE |$SED 's/EMAIL_ALL=[A-Za-z0-9.\/]*/EMAIL_ALL='$EMAIL_ALL'/' > $TMPCONFFILE
	$MV $TMPCONFFILE $CONFFILE
	echo -n "."

	$CAT $CONFFILE |$SED 's/EMAIL_WARN=[A-Za-z0-9.\/]*/EMAIL_WARN='$EMAIL_WARN'/' > $TMPCONFFILE
	$MV $TMPCONFFILE $CONFFILE
	echo -n "."

	$CAT $CONFFILE |$SED 's/EMAIL_CRIT=[A-Za-z0-9.\/]*/EMAIL_CRIT='$EMAIL_CRIT'/' > $TMPCONFFILE
	$MV $TMPCONFFILE $CONFFILE
	echo -n "."

	$CAT $CONFFILE |$SED 's/SMTP_SERVER=[A-Za-z0-9.\/]*/SMTP_SERVER='$SMTP_SERVER'/' > $TMPCONFFILE
	$MV $TMPCONFFILE $CONFFILE
	echo -n "."

	$CAT $CONFFILE |$SED 's/EMAIL_TO=[A-Za-z0-9.\/]*[@A-Za-z0-9.\/]*/EMAIL_TO='$EMAIL_TO'/' > $TMPCONFFILE
	$MV $TMPCONFFILE $CONFFILE
	echo -n "."

	$CAT $CONFFILE |$SED 's/EMAIL_FROM=[A-Za-z0-9.\/]*[@A-Za-z0-9.\/]*/EMAIL_FROM='$EMAIL_FROM'/' > $TMPCONFFILE
	$MV $TMPCONFFILE $CONFFILE
	echo -n "."

	$CAT $CONFFILE |$SED 's/EMAIL_SUBJECT=[A-Za-z0-9.\/ ]*/EMAIL_SUBJECT='"$EMAIL_SUBJECT"'/' > $TMPCONFFILE
	$MV $TMPCONFFILE $CONFFILE
	echo -n "."

	$CAT $CONFFILE |$SED 's/EVENTLOG=[A-Za-z0-9.\/]*/EVENTLOG='$EVENTLOG'/' > $TMPCONFFILE
	$MV $TMPCONFFILE $CONFFILE
	echo -n "."

	$CAT $CONFFILE |$SED 's/LOGSIZE=[A-Za-z0-9.\/]*/LOGSIZE='$LOGSIZE'/' > $TMPCONFFILE
	$MV $TMPCONFFILE $CONFFILE
	echo -n "."

	$CAT $CONFFILE |$SED 's/^SERVER=[A-Za-z0-9.\/]*/SERVER='$SERVER'/' > $TMPCONFFILE
	$MV $TMPCONFFILE $CONFFILE
	echo -n "."

	### Update PERFHOME in perf.sh ###
	$CAT $PERFHOME/perf.sh |$SED 's/PERFHOME=[A-Za-z0-9\/-]*/PERFHOME='$PERFHOME_ESCAPE'/' > $TMPPERFFILE
	$MV $TMPPERFFILE $PERFFILE
	echo -n "."

	### Add PerfServer IP to perf-hosts ###
	$GREP $IP $PERFHOME/etc/perf-hosts > 2&>1

	if [ $? = 0 ];then
		:
	else
		echo -e "$IP\t\t\t$HOSTNAME\t# PerfStat Server" >> $PERFHOME/etc/perf-hosts
	fi

	echo -n "Done!"
	echo ""
	echo ""

	sleep 2
	
}

### Update PerfClient Config ###
UpdateClient () {

	### Escape vars ###
	SAR_CMD=`echo $SAR_CMD |$SED 's/\//\\\\\\//g'`	
	UPTIME_CMD=`echo $UPTIME_CMD |$SED 's/\//\\\\\\//g'`	
	INODE_CMD=`echo $INODE_CMD |$SED 's/\//\\\\\\//g'`	
	FS_CMD=`echo $FS_CMD |$SED 's/\//\\\\\\//g'`	

	echo ""
	echo -n "Updating PerfCLient config"

	$CAT $CONFFILE |$SED 's/PERFHOME=[A-Za-z0-9\/\-]*/PERFHOME='"$PERFHOME_ESCAPE"'/' > $TMPCONFFILE
	$MV $TMPCONFFILE $CONFFILE
	echo -n "."


	$CAT $CONFFILE |$SED 's/PERFSERVER=[A-Za-z0-9.\/]*/PERFSERVER='$PERFSERVER'/' > $TMPCONFFILE
	$MV $TMPCONFFILE $CONFFILE
	echo -n "."

	$CAT $CONFFILE |$SED 's/METRICS=[A-Za-z0-9.\/ ]*/METRICS='"$METRICS"'/' > $TMPCONFFILE
	$MV $TMPCONFFILE $CONFFILE
	echo -n "."

	$CAT $CONFFILE |$SED 's/SAR_CMD=[A-Za-z0-9.\/]* [A-Za-z0-9.\/-]*/SAR_CMD='"$SAR_CMD"'/' > $TMPCONFFILE
	$MV $TMPCONFFILE $CONFFILE
	echo -n "."

	$CAT $CONFFILE |$SED 's/UPTIME_CMD=[A-Za-z0-9.\/]* [A-Za-z0-9.\/-]*/UPTIME_CMD='"$UPTIME_CMD"'/' > $TMPCONFFILE
	$MV $TMPCONFFILE $CONFFILE
	echo -n "."

	$CAT $CONFFILE |$SED 's/INODE_CMD=[A-Za-z0-9.\/]* [A-Za-z0-9.\/-]*/INODE_CMD='"$INODE_CMD"'/' > $TMPCONFFILE
	$MV $TMPCONFFILE $CONFFILE
	echo -n "."

	$CAT $CONFFILE |$SED 's/FS_CMD=[A-Za-z0-9.\/]* [A-Za-z0-9.\/-]*/FS_CMD='"$FS_CMD"'/' > $TMPCONFFILE
	$MV $TMPCONFFILE $CONFFILE
	echo -n "."

	$CAT $CONFFILE |$SED 's/CLIENT=[A-Za-z0-9.\/]*/CLIENT='$CLIENT'/' > $TMPCONFFILE
	$MV $TMPCONFFILE $CONFFILE
	echo -n "."

	### Update PERFHOME in perf.sh ###
	$CAT $PERFHOME/perf.sh |$SED 's/PERFHOME=[A-Za-z0-9\/-]*/PERFHOME='$PERFHOME_ESCAPE'/' > $TMPPERFFILE
	$MV $TMPPERFFILE $PERFFILE
	echo -n "."

	echo -n "Done!"
	echo ""
	echo ""

	sleep 2

}

### Get PerfServer Settings ###
GetServer () {

	### Get email settings ###
	EMAIL=`$GREP EMAIL= $CONFFILE |$SED 's/EMAIL=//'`
	EMAIL_ALL=`$GREP EMAIL_ALL= $CONFFILE |$SED 's/EMAIL_ALL=//'`
	EMAIL_CRIT=`$GREP EMAIL_CRIT= $CONFFILE |$SED 's/EMAIL_CRIT=//'`
	EMAIL_WARN=`$GREP EMAIL_WARN= $CONFFILE |$SED 's/EMAIL_WARN=//'`
	SMTP_SERVER=`$GREP SMTP_SERVER= $CONFFILE |$SED 's/SMTP_SERVER=//'`
	EMAIL_TO=`$GREP EMAIL_TO= $CONFFILE |$SED 's/EMAIL_TO=//'`
	EMAIL_FROM=`$GREP EMAIL_FROM= $CONFFILE |$SED 's/EMAIL_FROM=//'`
	EMAIL_SUBJECT=`$GREP EMAIL_SUBJECT= $CONFFILE |$SED 's/EMAIL_SUBJECT=//'`

	### Get eventlog settings ###
	EVENTLOG=`$GREP EVENTLOG= $CONFFILE |$SED 's/EVENTLOG=//'`
	LOGSIZE=`$GREP LOGSIZE= $CONFFILE |$SED 's/LOGSIZE=//'`

}

### Get PerfClient Settings ###
GetClient () {

	### Get CLient Settings ###
	PERFHOME=`$GREP PERFHOME= $CONFFILE |$SED 's/PERFHOME=//'`
	PERFSERVER=`$GREP PERFSERVER= $CONFFILE |$SED 's/PERFSERVER=//'`
	SAR_CMD=`$GREP SAR_CMD= $CONFFILE |$SED 's/SAR_CMD=//'`
	UPTIME_CMD=`$GREP UPTIME_CMD= $CONFFILE |$SED 's/UPTIME_CMD=//'`
	INODE_CMD=`$GREP INODE_CMD= $CONFFILE |$SED 's/INODE_CMD=//'`
	FS_CMD=`$GREP FS_CMD= $CONFFILE |$SED 's/FS_CMD=//'`
}

### Get PERFHOME ###
GetPerfhome () {
	$CLEAR
	echo ""
	echo "Welcome to the PerfStat $VERSION Configuration Program"
	echo ""
	echo -n "Enter path to PERFHOME: "

	read ANS

	if [ "$ANS" = "" ];then
		echo ""
		echo "You must Enter path to PERFHOME [ie: /usr/local/perfhome]"
		exit
	else
		PERFHOME="$ANS"
	fi

	### Escape forward slash ###
	PERFHOME_ESCAPE=`echo $PERFHOME |$SED 's/\//\\\\\\//g'`	

	### Set PERFHOME related vars ###
	CONFFILE="$PERFHOME/etc/perf-conf"
	CONFDIR="$PERFHOME/etc"
	TMPCONFFILE="$PERFHOME/tmp/perf-conf.tmp"
	PERFFILE="$PERFHOME/perf.sh"
	TMPPERFFILE="$PERFHOME/tmp/perf.sh.tmp"
}

### Main Menu ###
MAIN
