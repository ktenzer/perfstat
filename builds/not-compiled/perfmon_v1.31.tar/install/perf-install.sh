#!/bin/sh

#set -x
# Find path to needed bin's
SED=`which sed`
MV=`which mv`
USERADD=`which useradd`
USERMOD=`which usermod`
GROUPADD=`which groupadd`
GREP=`which grep`
CUT=`which cut`
CHOWN=`which chown`
CHMOD=`which chmod`
EXISTS=0
# Installation Script for Perfmon
VERSION="1.0"

echo "Installing Perfmon $VERSION
"
sleep 1

# Detect OS
OS=`uname -s`

echo "Your OS has been detected as [$OS]
If this is incorrect Enter OS below
or Enter 'c' to use OS: $OS
"

read ANS

if [ $ANS = "c" -o $ANS = "C" ]; then
	:
else
	OS="$ANS"
fi

# Check to see whether OS is supported
if [ $OS != "SunOS" -a  $OS != "Linux" ]; then
	echo "OS: $OS is currently not supported!"
	exit
fi
	
# Find out whether this is a Client or Server installation
echo "Install Perfmon Client or Server:
Choose [client/server]
Enter 'c' to use default [client]
"

read INSTALL

if [ $INSTALL = "c" -o $INSTALL = "C" ]; then
	INSTALL="client"
fi

while [ $INSTALL != "client" -a $INSTALL != "server" ]; do
	echo "Incorrect choice! You muse Enter [client/server]
"

echo "Install Perfmon Client or Server:
Choose [client/server]
Enter 'c' to use default [client]
"

	read INSTALL

	if [ $INSTALL = "c" -o $INSTALL = "C" ]; then
        	INSTALL="client"
	fi
done

# Collect Path to Perfhome 
echo "Enter Path to the Perfmon Home Directory:
Enter 'c' to use default [/usr/local/perfhome]
"

read PERFHOME

if [ $PERFHOME = "c" -o $PERFHOME = "C" ]; then
	PERFHOME="/usr/local/perfhome"
fi

echo "You entered: $PERFHOME
Is this correct [y/n]
"

read ANS

if [ $ANS = 'y' -o $ANS = 'Y' ]; then
        :
else
        exit
fi

# Collect Path to Perl RRD LIBS If this is a server install
if [ $INSTALL = "server" ]; then
echo "Enter Path to the RRDTOOL Perl Libraries:
Enter 'c' to use default [/usr/local/rrdtool/lib/perl]
"

	read RRDLIBS

	if [ $RRDLIBS = "c" -o $RRDLIBS = "C" ]; then
        	RRDLIBS="/usr/local/rrdtool/lib/perl"
	fi

echo "You entered: $RRDLIBS
Is this correct [y/n]
	"

	read ANS

	if [ $ANS = 'y' -o $ANS = 'Y' ]; then
        	:
	else
        	exit
	fi
fi

# Collect username to run Perfmon
echo "Enter username for Perfmon:
Enter 'c' to use default [pmuser]
"

read PERFUSER

if [ $PERFUSER = "c" -o $PERFUSER = "C" ]; then
	PERFUSER="pmuser"
fi

# Find out Whether user/uid exists
if ( `$GREP $PERFUSER /etc/passwd >/dev/null 2>&1` ); then
        echo "User: $PERFUSER Detected!
Would You like to use that User [y/n]
"
        read OLD_USER

        if [ $OLD_USER = "y" -o $OLD_USER = "Y" ]; then
		EXISTS=1
		USER_ID=`$GREP $PERFUSER /etc/passwd |$CUT -d: -f 3`
		GROUP_ID=`$GREP $PERFUSER /etc/passwd |$CUT -d: -f 4`
		PERFGROUP=`$GREP $GROUP_ID /etc/group |$CUT -d: -f 1`
		$USERMOD -d $PERFHOME $PERFUSER
	else
                exit
                echo "Installation Aborted!"
        fi
fi

# Collect UID if needed
if [ $EXISTS -eq 1 ]; then
	:
else
	echo "Enter UID for username: $PERFUSER
"
	read USER_ID

	echo "You entered: $PERFUSER $USER_ID
Is this correct [y/n]
"

	read ANS

	if [ $ANS = 'y' -o $ANS = 'Y' ]; then
		:
	else
		exit
	fi
fi

# Collect group name to run Perfmon
if [ $EXISTS -eq 1 ]; then
	:
else
	echo "Enter group name for Perfmon User $PERFUSER:
Enter 'c' to use default [pmgroup]
"

	read PERFGROUP

	if [ $PERFGROUP = "c" -o $PERFGROUP = "C" ]; then
        	PERFGROUP="pmgroup"
	fi

	echo "Enter GID for group: $PERFGROUP
"

	read GROUP_ID

	echo "You entered: $PERFGROUP $GROUP_ID
Is this correct [y/n]
"

	read ANS

	if [ $ANS = 'y' -o $ANS = 'Y' ]; then
        	:
	else
        	exit
	fi
fi

# Update Perfmon to appropriate Path
PERFHOME_TMP=`echo $PERFHOME |$SED 's/\//\\\\\//g'`
RRDLIBS_TMP=`echo $RRDLIBS |$SED 's/\//\\\\\//g'`

FILES="perf.sh etc/perf-conf bin/perf.pl bin/perfctl.pl bin/cpu.pl bin/memory.pl bin/io.pl bin/fs.pl bin/procs.pl bin/tcp.pl"

for file in $FILES; do
	$SED -e 's/\/path\/to\/perfhome/'$PERFHOME_TMP'/' $PERFHOME/$file > $PERFHOME/$file.tmp
	$MV $PERFHOME/$file.tmp $PERFHOME/$file
done

if [ $INSTALL = "server" ]; then
	$SED -e 's/\/path\/to\/perfhome/'$PERFHOME_TMP'/g' $PERFHOME/bin/perfd.pl > $PERFHOME/bin/perfd.pl.tmp
	$MV $PERFHOME/bin/perfd.pl.tmp $PERFHOME/bin/perfd.pl
	$SED -e 's/\/path\/to\/rrdlibs/'$RRDLIBS_TMP'/' $PERFHOME/bin/perfd.pl > $PERFHOME/bin/perfd.pl.tmp
	$MV $PERFHOME/bin/perfd.pl.tmp $PERFHOME/bin/perfd.pl
	$SED -e 's/server\=\"0\"/server\=\"1\"/' $PERFHOME/bin/perfctl.pl > $PERFHOME/bin/perfctl.pl.tmp
	$MV $PERFHOME/bin/perfctl.pl.tmp $PERFHOME/bin/perfctl.pl
	$SED -e 's/SERVER\=\"0\"/SERVER\=\"1\"/' $PERFHOME/perf.sh > $PERFHOME/perf.sh.tmp
	$MV $PERFHOME/perf.sh.tmp $PERFHOME/perf.sh

fi

# OS Specific Install

case $OS in
	SunOS )

	;;

	Linux )
		# Add perfuser and perfgroup
		if [ $EXISTS -eq 1 ]; then
			echo "Using existing Perfmon User/Group
"
			:
		else
			echo "Creating Permon User/Group...
"
			$GROUPADD -g $GROUP_ID $PERFGROUP >> $PERFHOME/install/install.log 2>&1
			$USERADD -d $PERFHOME -s /bin/sh -u $USER_ID -g $GROUP_ID -c "Perfmon User" $PERFUSER >> $PERFHOME/install/install.log 2>&1
		fi
		#Assign permission to Perhome
		$CHOWN -R $PERFUSER:$PERFGROUP $PERFHOME >> $PERFHOME/install/install.log 2>&1
		$CHMOD -R 744 $PERFHOME >> $PERFHOME/install/install.log 2>&1
	;;
esac

