### Config File for building serialized data structures ###

use lib "/perfstat/build/1.52/server/lib";

use Host;

$perfhome = "/perfstat/build/1.52/server";
