### Config File for building serialized data structures ###

use lib "/perfstat/build/1.52/server/lib";

use Service;
use Metric;

$perfhome = "/perfstat/build/1.52/server";
